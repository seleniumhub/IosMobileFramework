package salido.pos.page;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import io.appium.java_client.MobileElement;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;
import salido.pos.base.PosBaseClass;
import salido.pos.logger.Logger;
import salido.pos.utils.PosUtilClass;


public class PosManageBankPage extends PosBaseClass{

	PosUtilClass posUtils=new PosUtilClass();
	public PosManageBankPage(IOSDriver<WebElement> driver) throws IOException {
		super();
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	private String button="//XCUIElementTypeButton[contains(@name,'xxxx') and @visible=\"true\"]";
	private String txtfield="//XCUIElementTypeTextField[@visible=\"true\"]";
	private String stctxt="//XCUIElementTypeStaticText[contains(@name,'xxxx')]";

	@iOSFindBy(xpath="//XCUIElementTypeButton[contains(@name,'Bank')]")
	private WebElement openrcloseBank;

	@iOSFindBy(xpath="//XCUIElementTypeStaticText[contains(@name,'Bank: $')]")
	private WebElement bankAmt;

	@iOSFindBy(id="OrderEntryModalCheckmarkButton")
	private WebElement tickMark;

	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"Printing\"]")
	private WebElement printing;

	@iOSFindBy(xpath="//XCUIElementTypeStaticText[contains(@name,'Popping')]")
	private WebElement popping;
	
	public void checkBank(float ft) throws IOException {
		PosDashBoardPage DBPage= new PosDashBoardPage((IOSDriver<WebElement>) ADR);
		DBPage.clickOnDashBoard();
		DBPage.displayBank();
		String bank= DBPage.checkMangeBank();
		if(bank.contains("pen"))
			openBank(ft);
		else {
			Logger.info("Bank already Opened");
			preserveBankAmount();
		}
	}

	public void openBank(float ft) {
		System.out.println("Strting to Open the Bank");
		// Need to be modified.
		posUtils.webElementWithDynamicXpath(button, "xxxx", "Open Bank").click();
		posUtils.enterNumber(String.valueOf((long) Math.round(ft*100)));
		//		ADR.findElement(By.id(prop.getProperty("User"))).click();
		posUtils.webElementWithDynamicXpath(button, "xxxx", "Open Bank").click();
		posUtils.waitForSec(2);
		ADR.findElement(By.id(prop.getProperty("yes"))).click();
//		posUtils.waitUntilElementDisplayed(popping, 2);
//		try {
//		if(popping.isDisplayed())
//			posUtils.waitUntilElementDisplayed((MobileElement)ADR.findElement(By.id(prop.getProperty("cancel"))), 30);
//		}catch(NoSuchElementException e) {
//			
//		}
		posUtils.waitUntilElementDisplayed(ADR.findElementByAccessibilityId("RETRY"),60);
		ADR.findElementByAccessibilityId(prop.getProperty("cancel")).click();
		//Verifying the The Bank is opened or not
		if(posUtils.webElementWithDynamicXpath(button, "xxxx", "Close Bank").isDisplayed())
			System.out.println("Bank opened successfully");	
		if(posUtils.price2float(bankAmt.getText().split("\\s")[1])> (float)0) {
			preserveBankAmount();
		}
		else {
			bankPayIn((float)200);
		}
	}

	public float getBankAmount() {
		float ft=(float) 0.0;
		ft=posUtils.price2float(bankAmt.getText().split("\\s")[1]);
		Logger.info("Bank blanace: "+ft);
		return ft;
	}
	
	private float bankbal=(float)0.0;
	
	public void closeBank(float ft) {
		posUtils.webElementWithDynamicXpath(button, "xxxx", "Close Bank").click();
		posUtils.enterNumber(String.valueOf((long) Math.round(ft*100)));
		tickMark.click();
		posUtils.waitForSec(2);
		ADR.findElement(By.id(prop.getProperty("yes"))).click();
//		posUtils.waitUntilElementDisplayed(printing, 2);
//		try {
//		if(printing.isDisplayed())
//			posUtils.waitUntilElementDisappear(printing, 35);
//		}catch(NoSuchElementException e) {
//			
//		}
		posUtils.waitForSec(2);
		ADR.findElement(By.id(prop.getProperty("cancel"))).click();
		// verifying due bal
		String duebal=posUtils.webElementWithDynamicXpath(stctxt, "xxxx", "Over/Under: ").getAttribute("value");
		float shownbal=posUtils.price2float(duebal.split("\\s")[1]);
		if(bankbal>ft) {
			shownbal=-shownbal;
		}
		Assert.assertEquals(shownbal, (ft-bankbal));
		if(shownbal == (ft-bankbal)) {
			Logger.info("Bank closing with: "+shownbal);
		}
		// Verifying the bank closed or not
		if(posUtils.webElementWithDynamicXpath(button, "xxxx", "Open Bank").isDisplayed())
			System.out.println("Bank closed  successfully");
	}

	public void preserveBankAmount() {
		bankbal=posUtils.price2float(bankAmt.getText().split("\\s")[1]);
		Logger.info("Preserving Bank balance: "+bankbal);
	}

	public void bankPayIn(float ft) {
		posUtils.webElementWithDynamicXpath(button, "xxxx", "Pay In").click();
		posUtils.enterNumber(posUtils.num2Str((int)(ft*100)));
		tickMark.click();
		posUtils.webElementWithDynamicXpath(txtfield, "", "").sendKeys("TestAutomationPayIn",Keys.ENTER);
//		tickMark.click();
		posUtils.waitForSec(2);
		ADR.findElement(By.id(prop.getProperty("yes"))).click();
//		posUtils.waitUntilElementDisplayed(printing, 2);
//		try {
//		if(printing.isDisplayed())
//			posUtils.waitUntilElementDisappear(printing, 35);
//		}catch(NoSuchElementException e) {
//			
//		}
		posUtils.waitForSec(2);
		ADR.findElement(By.id(prop.getProperty("cancel"))).click();
		//verifying the payin
		verifyPayInOut(ft);
		System.out.println("Bank PayIn  successfull");
	}

	public void verifyPayInOut(float ft) {
		if(getBankAmount()==(bankbal+ft)) {
			Logger.info("Bank Balance matched correctly");
			Assert.assertEquals(true, true);
		}
		else {
			Logger.error("Bank Balance is not matched.");
			Assert.assertEquals(true, false);
		}
	}

	public void Payout(float ft) {
		posUtils.webElementWithDynamicXpath(button, "xxxx", "Pay Out").click();
		posUtils.enterNumber(posUtils.num2Str((int)(ft*100)));
		tickMark.click();
		if(ft>bankbal) {
			posUtils.waitUntilElementDisplayed(posUtils.webElementWithDynamicXpath(stctxt, "xxxx", "Insufficient Cash"),10);
			if(posUtils.webElementWithDynamicXpath(stctxt, "xxxx", "Insufficient Cash").isDisplayed()) {
				posUtils.webElementWithDynamicXpath(button, "xxxx", "Okay").click();
				verifyPayInOut((float)0.0);
			}
		}
		else {
		posUtils.webElementWithDynamicXpath(txtfield, "", "").sendKeys("TestAutomationPayOut",Keys.ENTER);
//		tickMark.click();
		posUtils.waitForSec(2);
		ADR.findElement(By.id(prop.getProperty("yes"))).click();
//		posUtils.waitUntilElementDisplayed(printing, 2);
//		try {
//		if(printing.isDisplayed())
//			posUtils.waitUntilElementDisappear(printing, 35);
//		}catch(NoSuchElementException e) {
//			
//		}
		posUtils.waitForSec(2);
		ADR.findElement(By.id(prop.getProperty("cancel"))).click();
		//verifying the payin
		verifyPayInOut(-ft);
		}
		System.out.println("Bank PayOut  successfully");
	}
}
