package salido.pos.testcases;

import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.appium.java_client.ios.IOSDriver;

import java.io.IOException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.NewSessionPayload;

import salido.pos.base.PosBaseClass;
import salido.pos.logger.Logger;
import salido.pos.page.ManageMenuPage;
import salido.pos.page.PosChecksPage;
import salido.pos.page.PosDashBoardPage;
import salido.pos.page.PosGuestPage;
import salido.pos.page.PosLoginPage;
import salido.pos.page.PosNewChkPage;
import salido.pos.testcases.*;
import salido.pos.utils.PosUtilClass;
public class SalidoTestCheck  extends PosBaseClass{

	PosUtilClass posUtils= new PosUtilClass();
	
	public SalidoTestCheck() throws IOException {
		super();
	}

	@BeforeMethod
	public void launchLockPage() throws InterruptedException, IOException {
		ADR.launchApp();
		PosLoginPage poslogin=new PosLoginPage((IOSDriver<WebElement>)ADR);
		poslogin.unlock();
		PosDashBoardPage DBPage=new PosDashBoardPage((IOSDriver<WebElement>) ADR);
		DBPage.clickOnDashBoard();
		DBPage.checkChecksMenu();
	}
	
	@Test(enabled = true, priority =21)//, dependsOnGroups= {"login"}
	public void CheckMenu_TC01() throws IOException, InterruptedException
	{	
		PosDashBoardPage DBPage=new PosDashBoardPage((IOSDriver<WebElement>) ADR);
		DBPage.clickOnDashBoard();
		DBPage.checkChecksMenu();	
	}
	//	@Test(enabled = true, priority =22 )
	public void CheckMenu_TC02() throws IOException, InterruptedException
	{		
		//		This test is covered in Checks creation	
	}
	
	@Test(dataProvider="Employee",enabled = false, priority =22, dependsOnMethods= {"CheckMenu_TC01"})
	public void Employee_TC03(String str) throws IOException, InterruptedException
	{		
		PosChecksPage checks= new PosChecksPage((IOSDriver<WebElement>) ADR);
		checks.employee();
		try {
			String empName=checks.selectEmployee(str);
			if(checks.employeeChecks(empName)) {
				Assert.assertEquals(true, true);
			}
			else {
				Assert.assertEquals(true, false);
			}
		}
		finally {
			checks.selectEmployeeAll();
		}
	}

	@DataProvider(name="Employee")
	public Object[][] getEmployeeName(){
		return new Object[][] {
			{ "Bhavya" },
			{ "Malleswari" },
			{ "Nitesh" },
			{"Ramya"},
			{"Ravi"},
			{"Govind"}
		};
	}

	@Test(dataProvider="OrderType",enabled = false, priority =23, dependsOnMethods= {"CheckMenu_TC01"})
	public void orderType_TC04(String str) throws IOException, InterruptedException
	{		
		PosChecksPage checks= new PosChecksPage((IOSDriver<WebElement>) ADR);
		checks.clickOnOrderType();
		try {
			String orderType=checks.selectOrderType(str);
			if(checks.verifyOrderTypeChecks(orderType)) {
				Assert.assertEquals(true, true);
			}
			else
				Assert.assertEquals(true, false);
		}
		finally {

			checks.selectOrderTypeAll();
		}
	}
	@DataProvider(name="OrderType")
	public Object[][] getOrderType(){
		return new Object[][] {
			{ "Delivery" },
			{ "Dine In" },
			{ "Take Out" }
		};

	}

	@Test(dataProvider="StatusType",enabled = false, priority =24, dependsOnMethods= {"CheckMenu_TC01"})
	public void statusType_TC05(String str) throws IOException, InterruptedException
	{		
		PosChecksPage checks= new PosChecksPage((IOSDriver<WebElement>) ADR);
		checks.clickOnStatusType();
		checks.buttonList();
		try {
			checks.selectChkStatusType(str);
		}
		finally {
			checks.selectChkStatusTypeOpen();
		}
		// we can only select the check status type but we can't verify the Status of the check whether is it open/closed/scheduled 
	}
	
	@DataProvider(name="StatusType")
	public Object[][] getStatusType(){
		return new Object[][] {
			{ "Open" },
			{ "Close" },
			{ "Schedule" }
		};
	}

	@Test(dataProvider="RevenueCenter",enabled = false, priority =25, dependsOnMethods= {"CheckMenu_TC01"})
	public void RevenueCenter_TC06(String str) throws IOException, InterruptedException
	{		
		PosChecksPage checks= new PosChecksPage((IOSDriver<WebElement>) ADR);
		checks.listRevenueCenters();
		String revCntr="";
		try {
			revCntr=checks.selectRevenueCenter(str);
		}
		finally {
			if(revCntr.equalsIgnoreCase("RC4")) {}
			else {
				checks.selectRevenueCenter("RC4");
			}
		}
	}
	@Test(dataProvider="RevenueCenter",enabled = false, priority =26, dependsOnMethods= {"CheckMenu_TC01"})
	public void VerifyChksRvnuCntr_TC07(String str) throws IOException, InterruptedException
	{		
		PosChecksPage checks= new PosChecksPage((IOSDriver<WebElement>) ADR);
		checks.listRevenueCenters();
		String revCntr="";
		try {
			revCntr=checks.selectRevenueCenter(str);
			checks.verifyRCChecks(revCntr);
			//There is no provision to verify the check belongs to a particular revenue center from UI
		}
		finally {
			if(revCntr.equalsIgnoreCase("RC4")) {}
			else {
				checks.selectRevenueCenter("RC4");
			}
		}
	}
	@DataProvider(name="RevenueCenter")
	public Object[][] getRevenueCenter(){
		return new Object[][] {
			{ "Bar" },
			{ "Dining" },
			{"RC1"}, 
			{"RC2"}, 
			{"RC3"}, 
			{"RC4"}
		};
	}

	@Test(dataProvider="RevenueCenter", enabled = false, priority =27, dependsOnMethods= {"CheckMenu_TC01"})  //
	public void newChkNO_TC08(String str) throws IOException, InterruptedException
	{		
		PosNewChkPage newcheck= new PosNewChkPage((IOSDriver<WebElement>) ADR);
		newcheck.newCheck(str);
	}

	@Test(enabled = false, priority =28, dependsOnMethods= {"CheckMenu_TC01"})  
	public void chksHeader_TC09() throws IOException, InterruptedException
	{	
		PosChecksPage checks= new PosChecksPage((IOSDriver<WebElement>) ADR);
		checks.clickOnFloorPlan();
		checks.clickOnAllChecksIcon();
		ManageMenuPage MMPage=new ManageMenuPage((IOSDriver<WebElement>) ADR);
		MMPage.clickOnDashBoard();
		PosDashBoardPage DBPage=new PosDashBoardPage((IOSDriver<WebElement>) ADR);		
		DBPage.checkChecksMenu();	
		MMPage.locknunlock();
		MMPage.clickOnDashBoard();
		DBPage.checkChecksMenu();	
	}
	@Test(enabled = false, priority =29, dependsOnMethods= {"CheckMenu_TC01"}) //Still under developement
	public void editChk_TC10() throws IOException, InterruptedException
	{		
		PosDashBoardPage DBPage=new PosDashBoardPage((IOSDriver<WebElement>) ADR);
		//		PosGuestPage gStPage = new PosGuestPage((IOSDriver<WebElement>) ADR);
		//		//gStPage
		//		DBPage.clickOnDashBoard();
		//		DBPage.checkGuests();
		//		if(gStPage.VerifyGuestcreation("AutoFirstName")) {
		//			Logger.info("Guest Details Already Exist.");
		//		}
		//		else {
		//			gStPage.clickOnNewGuestIcon();
		//			gStPage.enterGuestData();
		//			gStPage.clickOnSAVE();
		//			gStPage.VerifyGuestcreation("AutoFirstName");
		//		}
		//		DBPage.clickOnDashBoard();
		//		DBPage.checkChecksMenu();
		PosNewChkPage newcheck= new PosNewChkPage((IOSDriver<WebElement>) ADR);
		PosChecksPage checks= new PosChecksPage((IOSDriver<WebElement>) ADR);
		checks.clickOncreateNewCheck();
		String chkNo=newcheck.getNewCheckNo();
		newcheck.getChkOwner();
		newcheck.addbreakfast();
		newcheck.clikOnSaveSend();
		try {
			DBPage.clickOnDashBoard();
			checks.searchAndOpenCheck(chkNo);
			newcheck.clickOnLabel();
			newcheck.editPartySize();
			//		newcheck.editLabelText(chkNo);
			newcheck.addGuest2Chek("First",2);
			newcheck.addGuest2Chek("First",1);
			newcheck.removeGuest4mcheck(2);
			newcheck.clickOnLabel();
			//		Logger.info("Edit Item test case is covered here itself");
			//		newcheck.reOrderItem();
			//		Logger.info("Delete Item test case is covered here itself");
			//		newcheck.deleteItem("86");
			checks.clickOnAllChecksIcon();
			checks.clickOnBackButton();
		}
		finally {
			checks.searchAndOpenCheck(chkNo);
			newcheck.clikOnVoidChk();
			newcheck.clickOnVoidReason("Test");
			newcheck.confirmVoid();
			checks.clickOnBackButton();
		}
	}

	@Test(enabled = false, priority =32, dependsOnMethods= {"CheckMenu_TC01"})
	public void addItems2Chk_TC13() throws IOException, InterruptedException
	{		
		//		PosDashBoardPage DBPage=new PosDashBoardPage((IOSDriver<WebElement>) ADR);
		//		DBPage.clickOnDashBoard();
		//		DBPage.checkGuests();
		PosChecksPage checks= new PosChecksPage((IOSDriver<WebElement>) ADR);
		PosNewChkPage newcheck= new PosNewChkPage((IOSDriver<WebElement>) ADR);
		checks.clickOncreateNewCheck();
		newcheck.getNewCheckNo();
		newcheck.getChkOwner();
		newcheck.addbreakfast();
		newcheck.editItemCount();
		newcheck.verifyAllItemsPrice();
		//		newcheck.clikOnSaveSend();
	}

	@Test(enabled = false, priority =31, dependsOnMethods= {"CheckMenu_TC01"})
	public void ReopenPrintChk_TC12() {	
		Logger.info("This testcase will be covered in payments module. Inorder to reopen the check, payment has to be done.");
	}

	@Test(enabled = false, priority =33, dependsOnMethods= {"CheckMenu_TC01"}) //Still under developement
	public void editItemChk_TC14() throws IOException, InterruptedException
	{		
		PosDashBoardPage DBPage=new PosDashBoardPage((IOSDriver<WebElement>) ADR);
		PosNewChkPage newcheck= new PosNewChkPage((IOSDriver<WebElement>) ADR);
		PosChecksPage checks= new PosChecksPage((IOSDriver<WebElement>) ADR);
		checks.clickOncreateNewCheck();
		String chkNo=newcheck.getNewCheckNo();
		newcheck.getChkOwner();
		newcheck.addbreakfast();
		newcheck.clikOnSaveSend();
		try {
			DBPage.clickOnDashBoard();
			checks.searchAndOpenCheck(chkNo);
			newcheck.reOrderItem();
			checks.clickOnAllChecksIcon();
			checks.clickOnBackButton();
		}
		finally {
			checks.searchAndOpenCheck(chkNo);
			newcheck.clikOnVoidChk();
			newcheck.clickOnVoidReason("Mind");
			newcheck.confirmVoid();
			checks.clickOnBackButton();
		}
	}

	@Test(enabled = false, priority =34, dependsOnMethods= {"CheckMenu_TC01"}) //Still under developement
	public void deleteItemChk_TC15() throws IOException, InterruptedException
	{		
		PosDashBoardPage DBPage=new PosDashBoardPage((IOSDriver<WebElement>) ADR);
		PosNewChkPage newcheck= new PosNewChkPage((IOSDriver<WebElement>) ADR);
		PosChecksPage checks= new PosChecksPage((IOSDriver<WebElement>) ADR);
		checks.clickOncreateNewCheck();
		String chkNo=newcheck.getNewCheckNo();
		newcheck.getChkOwner();
		newcheck.addbreakfast();
		newcheck.clikOnSaveSend();
		try {
			DBPage.clickOnDashBoard();
			checks.searchAndOpenCheck(chkNo);
			newcheck.deleteItem("86");
			checks.clickOnAllChecksIcon();
			checks.clickOnBackButton();
		}
		finally {
			checks.searchAndOpenCheck(chkNo);
			newcheck.clikOnVoidChk();
			newcheck.clickOnVoidReason("Error");
			newcheck.confirmVoid();
			checks.clickOnBackButton();
		}
	}

	@Test(enabled = false, priority =35, dependsOnMethods= {"CheckMenu_TC01"}) //Still under developement
	public void splitChk_TC17() throws IOException, InterruptedException
	{		
		PosDashBoardPage DBPage=new PosDashBoardPage((IOSDriver<WebElement>) ADR);
		PosNewChkPage newcheck= new PosNewChkPage((IOSDriver<WebElement>) ADR);
		PosChecksPage checks= new PosChecksPage((IOSDriver<WebElement>) ADR);
		String spltchkNo="";
		checks.clickOncreateNewCheck();
		String chkNo=newcheck.getNewCheckNo();
		newcheck.getChkOwner();
		newcheck.addbreakfast();
		newcheck.clikOnSaveSend();
		try {
			DBPage.clickOnDashBoard();
			checks.searchAndOpenCheck(chkNo);
			newcheck.clickOnSplit();
			spltchkNo=newcheck.getSplitChkNo();
			newcheck.splitItems();
			newcheck.clickOnSplitChk();
		}
		finally {
			//			checks.clickOnAllChecksIcon();
			//			checks.clickOnBackButton();
			//			checks.searchAndOpenCheck(chkNo);
			newcheck.clikOnVoidChk();
			newcheck.clickOnVoidReason("Reason");
			newcheck.confirmVoid();
			checks.clickOnBackButton();
			checks.searchAndOpenCheck(spltchkNo);
			newcheck.clikOnVoidChk();
			newcheck.clickOnVoidReason("Test");
			newcheck.confirmVoid();
			checks.clickOnBackButton();
		}
	}

	@Test(enabled = false, priority =36, dependsOnMethods= {"CheckMenu_TC01"}) //Still under developement
	public void mergeChk_TC18() throws IOException, InterruptedException
	{		
		PosDashBoardPage DBPage=new PosDashBoardPage((IOSDriver<WebElement>) ADR);
		PosNewChkPage newcheck= new PosNewChkPage((IOSDriver<WebElement>) ADR);
		PosChecksPage checks= new PosChecksPage((IOSDriver<WebElement>) ADR);

		checks.clickOncreateNewCheck();
		String mergchkNo=newcheck.getNewCheckNo();
		newcheck.getChkOwner();
		newcheck.addbreakfast();
		newcheck.clikOnSaveSend();
		DBPage.clickOnDashBoard();
		checks.clickOncreateNewCheck();
		String chkNo=newcheck.getNewCheckNo();
		newcheck.getChkOwner();
		newcheck.addbreakfast();
		newcheck.clikOnSaveSend();
		try {
			newcheck.clickOnMerge();
			newcheck.selectChek2Merge(mergchkNo);
			newcheck.clickOnMergeButton();
			if(mergchkNo.equals(newcheck.getNewCheckNo())) {
				Logger.info("Check merfged Successfully ");
			}
		}
		finally {
			newcheck.clikOnVoidChk();
			newcheck.clickOnVoidReason("Test");
			newcheck.confirmVoid();
			//			checks.clickOnBackButton();
		}
	}
	
	@Test(enabled = true, priority =38, dependsOnMethods= {"CheckMenu_TC01"})
	public void gratuity2Chk_TC19() throws IOException, InterruptedException
	{		
		PosChecksPage checks= new PosChecksPage((IOSDriver<WebElement>) ADR);
		PosNewChkPage newcheck= new PosNewChkPage((IOSDriver<WebElement>) ADR);
		PosDashBoardPage DBPage=new PosDashBoardPage((IOSDriver<WebElement>) ADR);
		checks.clickOncreateNewCheck();
		newcheck.getNewCheckNo();
		newcheck.getChkOwner();
		newcheck.addbreakfast();
		newcheck.clickOnGratuity();
		newcheck.enterGratuityPercentage(1.3);
		newcheck.verifyGratuity();
		newcheck.verifyGratuityAmount((float)1.3);
		newcheck.verifyTotal();
		newcheck.clickOnGratuity();
		newcheck.removeGratuity();
		newcheck.verifyTotal();
		DBPage.clickOnDashBoard();		
	}
	
	@Test(enabled = true, priority =39, dependsOnMethods= {"CheckMenu_TC01"})
	public void duiscount2Chk_TC20() throws IOException, InterruptedException
	{		
		PosChecksPage checks= new PosChecksPage((IOSDriver<WebElement>) ADR);
		PosNewChkPage newcheck= new PosNewChkPage((IOSDriver<WebElement>) ADR);
		PosDashBoardPage DBPage=new PosDashBoardPage((IOSDriver<WebElement>) ADR);
		checks.clickOncreateNewCheck();
		newcheck.getNewCheckNo();
		newcheck.getChkOwner();
		newcheck.addbreakfast();
		newcheck.clickOnDiscount();
		newcheck.applyDiscount("Comp");
		newcheck.verifyDiscount();
		newcheck.verifyTotal();
		newcheck.clickOnDiscount();
		newcheck.removeDiscount();
		newcheck.verifyTotal();
		DBPage.clickOnDashBoard();		
	}


}
