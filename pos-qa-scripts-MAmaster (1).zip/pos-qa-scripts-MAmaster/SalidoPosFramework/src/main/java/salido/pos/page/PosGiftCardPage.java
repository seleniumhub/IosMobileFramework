package salido.pos.page;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import io.appium.java_client.MobileElement;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;
import salido.pos.base.PosBaseClass;
import salido.pos.logger.Logger;
import salido.pos.utils.PosUtilClass;

public class PosGiftCardPage extends PosBaseClass{

	PosUtilClass posUtils=new PosUtilClass();
	public PosGiftCardPage(IOSDriver<WebElement> driver) throws IOException {
		super();
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	private String btnflwgbtn="//XCUIElementTypeButton[contains(@name,'xxxx')]/following::XCUIElementTypeButton[1]";
	private String stctxt="//XCUIElementTypeStaticText[contains(@name,'xxxx')]";
	private String buttons="//XCUIElementTypeButton[@name=\"xxxx\" and @visible=\"true\"]";
	private String txtfieldb4stctxt="//XCUIElementTypeStaticText[@name=\"xxxx\"]/preceding::XCUIElementTypeTextField[1]";
	private String stctxtflwngstctxt="//XCUIElementTypeStaticText[contains(@name,'xxxx')]/following::XCUIElementTypeStaticText[1]";
	private String stctxtinCell="//XCUIElementTypeCell/XCUIElementTypeStaticText[contains(@name,'xxxx')]";
	private String btnb4stctxt="//XCUIElementTypeStaticText[@name=\"xxxx\"]/preceding::XCUIElementTypeButton[1]";

	@iOSFindBy(id="GC #")
	private MobileElement GCNum; 

	@iOSFindBy(xpath="//XCUIElementTypeTextField")
	private MobileElement GCtextField;

	public void displayGCHash() {
		if(GCNum.isDisplayed()) {
			Logger.info("GC# is displayed");
		}
		else {
			Logger.info("GC# is not displayed");
		}
	}

	public void displayGCTextField() {
		if(GCtextField.isDisplayed()) {
			Logger.info("GC Text field is displayed");
		}
		else {
			Logger.info("GC Text field is not displayed");
		}
	}

	public void VerifyGCTextField(String str) throws IOException, InterruptedException {
		PosUtilClass posUtils=new PosUtilClass();
		//		String str="0123456789";
		posUtils.enterNumber(str);
		posUtils.waitForSec(1);
		String gcard=GCtextField.getAttribute("value");
		String []gcrdary=gcard.split("\\s");
		if((gcrdary[0]+gcrdary[1]+gcrdary[2]+gcrdary[3]).equals(str)) {
			Logger.info("GC text field content is matching with the entered text");
		}
		else {
			Logger.error("GC text field content is not matching with the entered text");
		}
	}

	@iOSFindBy(id="backIconBlack")
	private MobileElement gcBackButton;

	public boolean displayGCBackButton() {
		if(posUtils.isDisplayed(gcBackButton)) {
			//			Logger.info("GC Back Button is displayed");
			return true;
		}
		else {
			Logger.info("GC Back Button is not displayed");
		}
		return false;
	}

	public void clickOnGCBackButton() {
		gcBackButton.click();
	}

	public void displayNumberKeypad() {
		String str="0123456789";
		char []num=str.toCharArray();
		for(int ns=0;ns<str.length();ns++) {
			String chstr=Character.toString(num[ns]);
			if(ADR.findElement(By.xpath(prop.getProperty(chstr))).isDisplayed()) {
				Logger.info("Element "+chstr+" is displayed in Number keypad");
			}
			else {
				Logger.error("Element "+chstr+" is not displayed in Number keypad");
			}
		}
		if(ADR.findElement(By.id(prop.getProperty("eraseKey"))).isDisplayed()) {
			Logger.info("Delete key is displayed in Number keypad");
		}
		else {
			Logger.error("Delete key is not displayed in Number keypad");
		}
	}

	@iOSFindBy(xpath="//XCUIElementTypeImage[@name=\"iconGC\"]")
	private MobileElement gfImage;

	public void displayGCImage() {
		if(gfImage.isDisplayed()) {
			Logger.info("Gift Card Image is displayed");
		}
		else {
			Logger.error("Gift Card Image is not displayed");
		}
	}

	@iOSFindBy(id="LOOKUP")
	private MobileElement lookUp;

	public boolean displayGCLookUp() {
		if(lookUp.isDisplayed()) {
			Logger.info("LookUp is displayed");
			if(!lookUp.isEnabled()) {
				Logger.info("LookUp is disabled");
			}
			else {
				Logger.info("LookUp is enabled");
				return true;
			}
		}
		return false;
	}

	@iOSFindBy(id="Searching")
	private MobileElement searching;

	public void clickOnLookUP() {
		lookUp.click();
		//		posUtils.waitUntilElementDisplayed(searching,2);
		try {
			if(searching.isDisplayed())
				posUtils.waitUntilElementDisplayed(addValue, 20);
			if(addValue.isDisplayed()) {
				Logger.info("Add Value Button is displayed");
			}
		} catch(NoSuchElementException e) {
			try {
				if(posUtils.webElementWithDynamicXpath(stctxt, "xxxx", "Network Error").isDisplayed()) {
					Logger.error("Showing Network Error - Please try again. Retrying Again");
					clickOnContinue();
				}
			}
			catch(NoSuchElementException e1) {

			}
		}
	}

	@iOSFindBy(id="Gift Card Add Value Input")	
	private MobileElement addValue;

	@iOSFindBy(id="Invalid response. Please try again.")
	private MobileElement invalid;

	@iOSFindBy( id="Network Error - Please try again")
	private MobileElement network;

	@iOSFindBy(id="Error: Unable to find card.")
	private MobileElement invalidcard;

	public void clickOnAddValue() {
		preserveGiftCardAmount();
		addValue.click();
	}

	public boolean displaygcAddValue() {
		try {
			if(addValue.isDisplayed()) {
				return true;
			}
		}
		catch(NoSuchElementException e) {
			try {
				if(invalid.isDisplayed()) {
					Logger.error("showing Invalid response. Please try again. Retrying one more time");
					clickOnLookUP();
					displaygcAddValue();
				}
			}
			catch(NoSuchElementException ee) {
				try {
					if(network.isDisplayed()) {
						Logger.error("Network Error");
						return false;
					}
				}
				catch(NoSuchElementException ee2) {
					if(invalidcard.isDisplayed())
						Logger.error("Invalid CARD Number");
					return false;
				}
			}
		}
		return false;
	}

	@iOSFindBy(xpath="//XCUIElementTypeTextField[@visible=\"true\"]")
	private MobileElement amountFiled;

	public void checkSuggestedAmount() throws IOException {
		PosUtilClass posUtils=new PosUtilClass();
		String []sugdol= {"10","25","50","100"};
		for(int icnt=0;icnt<sugdol.length;icnt++) {
			posUtils.webElementWithDynamicXpath(buttons, "xxxx", "$"+sugdol[icnt]).click();
			if(amountFiled.getAttribute("value").contains(sugdol[icnt])) {
				Logger.info("Suggested amount "+sugdol[icnt]+" clicked is matching with the amount shown in AmountTextField");
			}
			clickOnBACK();
		}
	}

	public void clickOnBACK() {
		posUtils.webElementWithDynamicXpath(buttons, "xxxx", "BACK").click();
	} 

	@iOSFindBy(id="ADD")
	private MobileElement addButton;

	@iOSFindBy(id="RETRY")
	private MobileElement retryButton;
	
	public void clickOnADDbutton() {
		if(posUtils.isEnabled(addButton))
			addButton.click();
//		posUtils.waitUntilElementDisplayed(retryButton,20);
		//		if(processing.isDisplayed())
		//		posUtils.waitUntilElementDisappear(processing,10);
	}

	public void verifyEnteredAmount(float ft) {
		if(posUtils.webElementWithDynamicXpath(txtfieldb4stctxt, "xxxx", "$").getAttribute("value").equals(String.valueOf(ft))) {
			Logger.info("Entered amount is matching with the displayed value");
		}
		else {
			Logger.error("Entered amount is not matching with the displayed value");
		}
	}

	public void enterCCdetails(String CCNum,String CCExp,String CCpin) {
		posUtils.webElementWithDynamicXpath(txtfieldb4stctxt, "xxxx", "CC#").click();
		posUtils.enterNumber(CCNum);
		posUtils.webElementWithDynamicXpath(txtfieldb4stctxt, "xxxx", "CVV").click();
		posUtils.enterNumber(CCExp);
		//		posUtils.webElementWithDynamicXpath(txtfieldb4stctxt, "xxxx", "GIFT CARD").click();
		//		posUtils.enterNumber(CCpin);
	}

	public void AddAmount2GiftCard(float ft) {
		posUtils.enterNumber(posUtils.num2Str((int) Math.round(ft*100)));
	}

	@iOSFindBy(id="CONFIRM")
	private MobileElement confirm;

	@iOSFindBy(id="CONTINUE")
	private MobileElement refunded;

	@iOSFindBy(xpath="//XCUIElementTypeStaticText[contains(@name,'Loading')]")
	private MobileElement loading;

	public void cancelLastTransaction() {
		if(posUtils.webElementWithDynamicXpath(btnflwgbtn, "xxxx", "Gift Card Add Value Input").isDisplayed()) {
			Logger.info("Cancel Last Transaction Button is Displayed");
			if(posUtils.webElementWithDynamicXpath(btnflwgbtn, "xxxx", "Gift Card Add Value Input").isEnabled()) {
				Logger.info("Cancel Last Transaction Button is Enabled, clicking on it.");
				posUtils.webElementWithDynamicXpath(btnflwgbtn, "xxxx", "Gift Card Add Value Input").click();
				Logger.info("Confirming to cancel last transaction.");
				confirm.click();
				//				posUtils.waitUntilElementDisplayed(loading,2);
				try {
					if(loading.isDisplayed())
						posUtils.waitUntilElementDisplayed(refunded, 10);
				} catch(NoSuchElementException e) {

				}
				refunded.click();
				Logger.info("Amount refunded successfully from GiftCard");
			}
		}
	}
	public boolean invalidGifCardNumber() {
		if(invalid.isDisplayed()) {
			Logger.info("Invalid GiftCard is entered");
			return true;
		}
		return false;
	}

	private String gcAmount="";
	private String bankAmount="";

	public void verifyGiftCardAmountAdded(float ft) {
		String gcvalue=posUtils.webElementWithDynamicXpath(stctxtflwngstctxt, "xxxx", "VALUE").getAttribute("value");
		float preAmt=posUtils.price2float(gcAmount);
		float result=(float)0.0;
		result=(float)Math.round((preAmt*100)+(ft*100))/100;
		if(gcvalue.contains(posUtils.float2str(result))) {
			Logger.info("Gift Card Amount Matched Successfully");
		}
		else {
			Logger.error("Gift Card Amount not Matched properly");
			Assert.assertEquals(true, false);
		}
	}

	public void verifyBankAmountAdded(float ft) {
		String bankvalue=posUtils.webElementWithDynamicXpath(stctxt, "xxxx", "Bank: $").getAttribute("value");
		float preAmt=posUtils.price2float(bankAmount.split("\\s")[1]);
		float result=(float)0.0;
		result= (float)Math.round((preAmt*100)+(ft*100))/100;
		if(bankvalue.contains(posUtils.float2str(result))) {
			Logger.info("Bank Amount matched Successfully");
		}
		else {
			Logger.error("Bank Amount is not matched");
		}
	}

	public void preserveGiftCardAmount() {
		gcAmount=posUtils.webElementWithDynamicXpath(stctxtflwngstctxt, "xxxx", "VALUE").getAttribute("value");
		Logger.info("Preserving Gift Card amount: "+gcAmount);
	}

	public void preserveBankAmount() {
		bankAmount=posUtils.webElementWithDynamicXpath(stctxt, "xxxx", "Bank: $").getAttribute("value");
	}

	public boolean verifygcID(String str) {
		String gcard=posUtils.webElementWithDynamicXpath(stctxtflwngstctxt, "xxxx", "ID").getAttribute("value");
		String []gcrdary=gcard.split("-");
		if((gcrdary[0]+gcrdary[1]+gcrdary[2]+gcrdary[3]).equals(str)) {
			Logger.info("GC ID field content is matching with the entered GC Number");
			return true;
		}
		else {
			Logger.error("GC ID field content is not matching with the entered GC Number");
			Assert.assertEquals(true, false);
		}
		return false;
	}

	@iOSFindBy(id="CashIcon Grey")
	private MobileElement cash;

	public void byCash() {
		cash.click();
	}

	@iOSFindBy(id="CCIcon Grey")
	private MobileElement CC;

	public void byCredit() {
		CC.click();
	}

	@iOSFindBy(id="Processing")
	private MobileElement processing;

	public void clickOnContinue() {
		btncontinue.click();
		try {
			posUtils.waitUntilElementDisplayed(done,15);
			if(done.isDisplayed()) {
				Logger.info("Done button is displayed");
			}
		}
		catch(NoSuchElementException e) {
			try {
				if(posUtils.webElementWithDynamicXpath(stctxt, "xxxx", "Network Error").isDisplayed()) {
					Logger.error("Showing Network Error - Please try again. Retrying Again");
					clickOnContinue();
				}
			}
			catch(NoSuchElementException e1) {
				try {
					if(posUtils.webElementWithDynamicXpath(stctxt, "xxxx", "Violation").isDisplayed()) {
						Logger.error("Showing Rule Violation - Minimum/Maximum Recharge Amount Not Met");
					}
				}
				catch(NoSuchElementException e2) {

				}
			}
		}
	}

	@iOSFindBy(id="Rule Violation - Minimum Recharge Amount Not Met")
	private MobileElement minimum;

	public void check4Minimum() {
		btncontinue.click();
		try {
			posUtils.waitUntilElementDisplayed(minimum,30);
		}catch(NoSuchElementException e){

		}
		Assert.assertEquals(true, posUtils.isDisplayed(minimum));
	}

	@iOSFindBy(id="Rule Violation - Exceeds Maximum Recharge Amount")
	private MobileElement maximum;

	public void check4Maximum() {
		btncontinue.click();
		try {
			posUtils.waitUntilElementDisplayed(maximum,30);
		}catch(NoSuchElementException e){

		}
		Assert.assertEquals(true, posUtils.isDisplayed(maximum));
	}

	@iOSFindBy(id="DONE")
	private MobileElement done;

	public void clickOnDone() {
		done.click();
		Logger.info("Clicked on DONE button");
	}

	@iOSFindBy(id="CONTINUE")
	private MobileElement btncontinue;

	public boolean displayGCContinue() {
		if(btncontinue.isDisplayed()) {
			Logger.info("CONTINUE is displayed");
			if(!btncontinue.isEnabled()) {
				Logger.info("CONTINUE is disabled");
			}
			else {
				Logger.info("CONTINUE is enabled");
				return true;
			}
		}
		return false;
	}

	@iOSFindBy(id="CHARGE")
	private MobileElement charge;

	public boolean displayGCCharge() {
		if(charge.isDisplayed()) {
			Logger.info("CHARGE is displayed");
			if(!charge.isEnabled()) {
				Logger.info("CHARGE is disabled");
			}
			else {
				Logger.info("CHARGE is enabled");
				return true;
			}
		}
		return false;
	}

	public void ChargeAmount() {
		charge.click();
	}
	public void clickOnCharge() {
		ChargeAmount();
		Logger.info("Clicked On CHARGE button");
		try {
			//			posUtils.waitUntilElementDisplayed(posUtils.webElementWithDynamicXpath(stctxt, "xxxx", "PROCESSING..."),2);
			//			if(posUtils.webElementWithDynamicXpath(stctxt, "xxxx", "PROCESSING...").isDisplayed())
			posUtils.waitUntilElementDisplayed(done,30);
			if(done.isDisplayed()) {
				Logger.info("Done button is displayed");
			}
		}
		catch(NoSuchElementException e1){
			try {
				if(done.isDisplayed()) {
					Logger.info("Done button is displayed");
				}
			}
			catch(NoSuchElementException e) {
				if(posUtils.webElementWithDynamicXpath(stctxt, "xxxx", "Network Error").isDisplayed()) {
					Logger.error("Showing Network Error - Please try again. Retrying Again");
					clickOnCharge();
				}
			}
		}
	}

	@iOSFindBy(id="Gift Card")
	private MobileElement selectGiftCard;

	public void selectGiftCardPayment() {
		Logger.info("Selecting Gift Card Payment Method");
		selectGiftCard.click();
	}

	@iOSFindBy(id="AUTH")
	private MobileElement singleAuth;

	@iOSFindBy(id="iconEditFloor")
	private MobileElement editPayment;

	public void clickOnAuth() {
		singleAuth.click();
		//		posUtils.waitUntilElementDisplayed(processing,2);
		try {
			posUtils.waitUntilElementDisappear(editPayment, 10);
		} catch(NoSuchElementException e) {

		}
	}

	public boolean check4AUTH() {
		posUtils.waitUntilElementDisplayed(singleAuth, 10);
		return posUtils.isDisplayed(singleAuth);
	}

	public void verifyGCAmountShown() {
		String gcAmtshown=posUtils.webElementWithDynamicXpath(stctxt, "xxxx", "Gift Card $").getAttribute("value");
		if(gcAmtshown.contains(gcAmount)) {
			Logger.info("Gift Card Amount Available and Amount Showing are same.");
		}
		else {
			Logger.info("Gift Card Amount Available is different from Amount Showing.");
		}
	}

	public void gcAmnt2Redeem() throws IOException {
		PosNewChkPage nchk=new PosNewChkPage((IOSDriver<WebElement>)ADR);
		String chkTotal=nchk.checkTotal();
		if(chkTotal.contains(posUtils.webElementWithDynamicXpath(btnb4stctxt, "xxxx", "$").getAttribute("name"))) {
			Logger.info("Total Check Amount is matched with amount 2 redeem in gift card");
		}
		else {
			Logger.error("Total Check Amount is not matching with amount 2 redeem in gift card");
		}
	}
	
	public void gcAmnt2Redeem(String str) throws IOException {
		String partAmt=posUtils.webElementWithDynamicXpath(btnb4stctxt, "xxxx", "$").getAttribute("name");
		partAmt=posUtils.num2Str(posUtils.float2int(posUtils.str2float(partAmt)));
		if((partAmt).contains(str)) {
			Logger.info("Specified Amount is matched with amount 2 redeem in gift card");
		}
		else {
			Logger.error("Specified Amount is not matching with amount 2 redeem in gift card");
		}
	}
	
	public void editAmountb4Auth(String str) {
		posUtils.webElementWithDynamicXpath(btnb4stctxt, "xxxx", "$").click();
		posUtils.enterNumber(str);
	}

	public void verifyDueBalance() {
		String amtPaid=posUtils.webElementWithDynamicXpath(stctxtflwngstctxt, "xxxx", "Amount Paid").getAttribute("value");
		String chkTotal=posUtils.webElementWithDynamicXpath(stctxtflwngstctxt, "xxxx", "Check Total").getAttribute("value");
		float paidAmnt=posUtils.price2float(amtPaid);
		float chkTAmt=posUtils.price2float(chkTotal);
		String balDue=posUtils.webElementWithDynamicXpath(stctxtflwngstctxt, "xxxx", "Balance Due").getAttribute("value");
		if(balDue.contains(String.valueOf((chkTAmt-paidAmnt)))) {
			Logger.info("Balance Due "+balDue+" is Matching with Check Total and Amount Paid");
		}
		else {
			Logger.error("Balance Due "+balDue+" is not Matching with Check Total and Amount Paid");
		}
	}

	@iOSFindBy(id="CLOSE CHECK")
	private MobileElement closeCheck;

	public void clickOnCloseCheck() {
		closeCheck.click();
	}

	@iOSFindBy(id="Gift Card Add Value Input")
	private MobileElement activategc;

	public boolean check4gcInactivity() {
		if(posUtils.isDisplayed(activategc) && posUtils.isEnabled(activategc)) {
			return true;
		}
		return false;
	}
	public void activateGC(float ft) {
		if(check4gcInactivity())
			activategc.click();
		AddAmount2GiftCard(ft);
		clickOnADDbutton();
		byCash();
		AddAmount2GiftCard(ft);
		if(displayGCContinue()) {
			clickOnContinue();
		}
		clickOnDone();
	}

	public void check4gcActivation(String gcnum) {
		posUtils.enterNumber(gcnum);
		//		if(displayGCLookUp()) {
		clickOnLookUP();
		//		}
		preserveGiftCardAmount();
		if(posUtils.price2float(gcAmount)>0) {
			Logger.info("Gift Card: "+gcnum+" is successfully activated.");
		} else {
			Logger.error("Gift Card: "+gcnum+" is not activated.");
			Assert.assertEquals(true, false);
		}
	}

	//under development
	public void refund() {
		posUtils.waitUntilElementDisplayed(posUtils.webElementWithDynamicXpath(stctxt, "xxxx", "Refunding payment"),2);
		posUtils.waitUntilElementDisappear(posUtils.webElementWithDynamicXpath(stctxt, "xxxx", "Refunding payment"), 30);

		posUtils.waitUntilElementDisplayed(posUtils.webElementWithDynamicXpath(stctxt, "xxxx", "Refunding payment"),2);
		posUtils.waitUntilElementDisappear(posUtils.webElementWithDynamicXpath(stctxt, "xxxx", "Refunding payment"), 30);
		posUtils.webElementWithDynamicXpath(buttons, "xxxx", "CANCEL").click();
	}
}
