package salido.pos.page;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import io.appium.java_client.ios.IOSDriver;
import salido.pos.base.PosBaseClass;

public class PosFloorPlanPage extends PosBaseClass {
	
	
	public PosFloorPlanPage() throws IOException {
		super();
		
	}

	public void floorView() throws InterruptedException
	{
		Thread.sleep(200);
		 ADR.findElement(By.xpath(prop.getProperty("DashboardButton"))).click();
		 ADR.findElement(By.xpath(prop.getProperty("FloorPlan"))).click();
		 Thread.sleep(200);
		 ADR.findElement(By.xpath(prop.getProperty("EditFloorPlan"))).click();
		 Thread.sleep(200);
		 ADR.findElement(By.xpath(prop.getProperty("FloorEditor"))).click();
		 Thread.sleep(200);
		 ADR.findElement(By.xpath(prop.getProperty("Position"))).click();
		 ADR.findElement(By.xpath(prop.getProperty("SavePlan"))).click();
		 Thread.sleep(200);
		 ADR.findElement(By.xpath(prop.getProperty("SaveChanges"))).click();
		 System.out.println("floor plan save");
		Thread.sleep(200);
	}
	
	public void Timeopen() throws InterruptedException, IOException
	
	{
		ADR.findElement(By.xpath(prop.getProperty("DashboardButton"))).click();
	 ADR.findElement(By.xpath(prop.getProperty("FloorPlan"))).click();
	 ADR.findElement(By.xpath(prop.getProperty("Timeopen"))).click();
		Thread.sleep(2000);
		//ADR.findElement(By.xpath(prop.getProperty("Table"))).click();
		ADR.findElement(By.xpath("//XCUIElementTypeApplication[@name=\"POS - Staging\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeOther[2]/XCUIElementTypeOther")).click();
        ADR.findElement(By.xpath(prop.getProperty("Menu"))).click();
       Thread.sleep(20);
         ADR.findElement(By.xpath(prop.getProperty("Pay"))).click();
       Thread.sleep(200);
       ADR.findElement(By.name(prop.getProperty("otherpayment"))).click();
   	ADR.findElement(By.xpath(prop.getProperty("Preauth"))).click();
   	ADR.findElement(By.xpath(prop.getProperty("PreauthCC"))).click();
   	PosChecksPage checks = new PosChecksPage((IOSDriver<WebElement>) ADR);
//   checks.Creditcard();
   	
   	ADR.findElement(By.xpath(prop.getProperty("Preauthexpiry"))).click();
//   	
//   checks.Expirydate();

   	ADR.findElement(By.xpath(prop.getProperty("PreauthButton"))).click();
   	
   	Thread.sleep(20000); 
   	
   	
   	ADR.findElement(By.xpath(prop.getProperty("Auth"))).click();
   	
   	Thread.sleep(200);
   	ADR.findElement(By.name("CLOSE CHECK")).click();
   	System.out.println("time open Successfully");
	}
	
	
public void PartySize() throws InterruptedException
	
	{
	Thread.sleep(200);
	ADR.findElement(By.xpath(prop.getProperty("DashboardButton"))).click();
	 
	 ADR.findElement(By.xpath(prop.getProperty("FloorPlan"))).click();
   	Thread.sleep(200);
   	
   ADR.findElement(By.xpath("//XCUIElementTypeStaticText[@name=\"Party Size\"] ")).click();
	
   	ADR.findElement(By.xpath("//XCUIElementTypeApplication[@name=\"POS - Staging\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeOther[2]/XCUIElementTypeOther")).click();
  
	System.out.println("party size TestCase Successfully Passed");
	}

public void lastorder() throws InterruptedException

{
	Thread.sleep(200);
	ADR.findElement(By.xpath(prop.getProperty("DashboardButton"))).click();
	 
	 ADR.findElement(By.xpath(prop.getProperty("FloorPlan"))).click();
	 
	 ADR.findElement(By.xpath("//XCUIElementTypeStaticText[@name=\"Last Ordered\"]")).click();
	 
	 ADR.findElement(By.xpath("//XCUIElementTypeApplication[@name=\"POS - Staging\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeOther[2]/XCUIElementTypeOther")).click();
	 System.out.println("LastOrder  TestCase Successfully Passed");
}







}
