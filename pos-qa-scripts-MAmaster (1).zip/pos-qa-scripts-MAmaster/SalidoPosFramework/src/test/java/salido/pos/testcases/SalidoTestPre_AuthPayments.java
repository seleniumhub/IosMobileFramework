package salido.pos.testcases;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.appium.java_client.ios.IOSDriver;
import salido.pos.base.PosBaseClass;
import salido.pos.dataProvider.DataProviderClass;
import salido.pos.logger.Logger;
import salido.pos.page.POSPaymentPage;
import salido.pos.page.PosChecksPage;
import salido.pos.page.PosDashBoardPage;
import salido.pos.page.PosGiftCardPage;
import salido.pos.page.PosLoginPage;
import salido.pos.page.PosNewChkPage;
import salido.pos.utils.PosUtilClass;

public class SalidoTestPre_AuthPayments extends PosBaseClass{

	PosUtilClass posUtils=new PosUtilClass();
	public SalidoTestPre_AuthPayments() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}
	
//	@BeforeClass
	public void relaunchApp() throws IOException {
//		Appiuminitialization();
		ADR.launchApp();
		PosLoginPage login=new PosLoginPage((IOSDriver<WebElement>)ADR);
		login.unlock();
	}

	@Test(enabled=true, priority=91, dataProvider="Visa", dataProviderClass = DataProviderClass.class)
	public void preAuthpayment(String CCnum,String CCExp,String CCpin) throws IOException {
		PosDashBoardPage DBpage=new PosDashBoardPage((IOSDriver<WebElement>)ADR);
		PosChecksPage chkPage=new PosChecksPage((IOSDriver<WebElement>)ADR);
		PosNewChkPage NChkpage=new PosNewChkPage((IOSDriver<WebElement>)ADR);
		POSPaymentPage payPage=new POSPaymentPage((IOSDriver<WebElement>)ADR);
		PosGiftCardPage gfPage=new PosGiftCardPage((IOSDriver<WebElement>)ADR);
		String checkNo=NChkpage.CreateCheck();
		NChkpage.clickOnPay();
		NChkpage.clickOnOtherPayments();
		payPage.selectPreAuth();
		payPage.enterCCdetails(CCnum, CCExp, CCpin);
		payPage.clickOnPreAuth();
		payPage.clickOnAuth();
		payPage.printerNotFound();
		payPage.closeCheck();
		String chkStatus=chkPage.searchAndOpenCheck(checkNo);
		if(chkStatus.equalsIgnoreCase("closed"))
			chkPage.reOpenCheck();
		NChkpage.clickOnPay();
		payPage.refundGiftCard();
		Logger.info("refunding Payment is covered here");
		payPage.checkVoid("Mind");
		payPage.back2Checks();
		DBpage.clickOnDashBoard();
		DBpage.clickFloor();
	}

	@Test(enabled=true,priority=91, dataProvider="Master", dataProviderClass = DataProviderClass.class)
	public void PreAuthPayment_Split_22_96(String CCnum,String CCExp,String CCpin) throws IOException {
		PosDashBoardPage DBpage=new PosDashBoardPage((IOSDriver<WebElement>)ADR);
		PosChecksPage chkPage=new PosChecksPage((IOSDriver<WebElement>)ADR);
		PosNewChkPage NChkpage=new PosNewChkPage((IOSDriver<WebElement>)ADR);
		POSPaymentPage payPage=new POSPaymentPage((IOSDriver<WebElement>)ADR);
		float totalBill=(float)0.0;
		String checkNo=NChkpage.CreateCheck();
		NChkpage.clickOnPay();
		totalBill=payPage.toatlBill();
		String []spltbil=payPage.splitbill(totalBill);
		for(int rp=0;rp<2;rp++) {
			NChkpage.clickOnOtherPayments();
			payPage.selectPreAuth();
			payPage.enterCCdetails(CCnum, CCExp, CCpin);
			payPage.clickOnPreAuth();
			payPage.clickOnAmntB4Auth();
			posUtils.enterNumber(spltbil[rp]);
			payPage.updatePayment();
			payPage.clickOnAuth();
			payPage.printerNotFound();
		}
		payPage.closeCheck();
		String chkStatus=chkPage.searchAndOpenCheck(checkNo);
		if(chkStatus.equalsIgnoreCase("closed"))
			chkPage.reOpenCheck();
		NChkpage.clickOnPay();
		payPage.refundGiftCard();
		Logger.info("refunding Payment is covered here");
		payPage.checkVoid("Test");
		payPage.back2Checks();
		DBpage.clickOnDashBoard();
		DBpage.clickFloor();
	}

	@Test(enabled=true,priority=91, dataProvider="Amex", dataProviderClass = DataProviderClass.class)
	public void preAuthPayment_Edit_74_96(String CCnum,String CCExp,String CCpin) throws IOException {
		PosDashBoardPage DBpage=new PosDashBoardPage((IOSDriver<WebElement>)ADR);
		PosChecksPage chkPage=new PosChecksPage((IOSDriver<WebElement>)ADR);
		PosNewChkPage NChkpage=new PosNewChkPage((IOSDriver<WebElement>)ADR);
		POSPaymentPage payPage=new POSPaymentPage((IOSDriver<WebElement>)ADR);
		float totalBill=(float)0.0;
		String checkNo=NChkpage.CreateCheck();
		NChkpage.clickOnPay();
		totalBill=payPage.toatlBill();
		NChkpage.clickOnOtherPayments();
		payPage.selectPreAuth();
		payPage.enterCCdetails(CCnum, CCExp, CCpin);
		payPage.clickOnPreAuth();
		payPage.clickOnAmntB4Auth();
		posUtils.enterNumber(posUtils.num2Str(posUtils.float2int(totalBill-5)));
		payPage.updatePayment();
		payPage.clickOnAuth();
		payPage.printerNotFound();
		//add tip
		payPage.editPayment((float)0.4);
		payPage.updatePayment();
		//edit amount and tip
		payPage.editPayment(totalBill-3, (float)0.6);
		payPage.updatePayment();
		payPage.refundGiftCard();
		Logger.info("refunding Payment is covered here");
		payPage.checkVoid("Item");
		DBpage.clickOnDashBoard();
		DBpage.clickFloor();
	} 

}
