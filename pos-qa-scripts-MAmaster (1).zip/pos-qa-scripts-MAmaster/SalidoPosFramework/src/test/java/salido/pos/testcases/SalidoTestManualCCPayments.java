package salido.pos.testcases;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.mongodb.DB;

import io.appium.java_client.ios.IOSDriver;
import salido.pos.base.PosBaseClass;
import salido.pos.dataProvider.DataProviderClass;
import salido.pos.logger.Logger;
import salido.pos.page.POSPaymentPage;
import salido.pos.page.PosChecksPage;
import salido.pos.page.PosDashBoardPage;
import salido.pos.page.PosLoginPage;
import salido.pos.page.PosNewChkPage;
import salido.pos.utils.PosUtilClass;

public class SalidoTestManualCCPayments extends PosBaseClass{

	PosUtilClass posutils=new PosUtilClass();
	public SalidoTestManualCCPayments() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}

//	@BeforeClass
	public void relaunchApp() throws IOException {
//		Appiuminitialization();
		ADR.launchApp();
		PosLoginPage login=new PosLoginPage((IOSDriver<WebElement>)ADR);
		login.unlock();
	}

	@Test(enabled=true, priority=71, dataProvider="Visa", dataProviderClass = DataProviderClass.class)
	public void mCCpayment(String CCnum,String CCExp,String CCpin) throws IOException {
		PosDashBoardPage DBpage=new PosDashBoardPage((IOSDriver<WebElement>)ADR);
		PosChecksPage chkPage=new PosChecksPage((IOSDriver<WebElement>)ADR);
		PosNewChkPage NChkpage=new PosNewChkPage((IOSDriver<WebElement>)ADR);
		POSPaymentPage payPage=new POSPaymentPage((IOSDriver<WebElement>)ADR);
		String checkNo=NChkpage.CreateCheck();
		NChkpage.clickOnPay();
		payPage.selectManualCC();
		payPage.enterCCdetails(CCnum, CCExp, CCpin);
		payPage.clickAuthorize();
		payPage.closeCheck();
		String chkStatus=chkPage.searchAndOpenCheck(checkNo);
		if(chkStatus.equalsIgnoreCase("closed"))
			chkPage.reOpenCheck();
		NChkpage.clickOnPay();
		payPage.refundGiftCard();
		Logger.info("refunding Payment is covered here");
		payPage.checkVoid("Mind");
		payPage.back2Checks();
		DBpage.clickOnDashBoard();
		DBpage.clickFloor();
	}

	@Test(enabled=true,priority=71, dataProvider="Master", dataProviderClass = DataProviderClass.class)
	public void mCCpayment_split_19(String CCnum,String CCExp,String CCpin) throws IOException {
		PosDashBoardPage DBpage=new PosDashBoardPage((IOSDriver<WebElement>)ADR);
		PosChecksPage chkPage=new PosChecksPage((IOSDriver<WebElement>)ADR);
		PosNewChkPage NChkpage=new PosNewChkPage((IOSDriver<WebElement>)ADR);
		POSPaymentPage payPage=new POSPaymentPage((IOSDriver<WebElement>)ADR);
		float totalBill=(float)0.0;
		String checkNo=NChkpage.CreateCheck();
		NChkpage.clickOnPay();
		totalBill=payPage.toatlBill();
		String []spltbil=payPage.splitbill(totalBill);
		for(int rp=0;rp<2;rp++) {
			payPage.selectManualCC();
			posutils.enterNumber(spltbil[rp]);
			payPage.enterCCdetails(CCnum, CCExp, CCpin);
			payPage.clickAuthorize();
		}
		payPage.closeCheck();
		String chkStatus=chkPage.searchAndOpenCheck(checkNo);
		if(chkStatus.equalsIgnoreCase("closed"))
			chkPage.reOpenCheck();
		NChkpage.clickOnPay();
		payPage.refundGiftCard();
		Logger.info("refunding Payment is covered here");
		payPage.checkVoid("Test");
		payPage.back2Checks();
		DBpage.clickOnDashBoard();
		DBpage.clickFloor();
	}

	@Test(enabled=true,priority=71, dataProvider="Amex", dataProviderClass = DataProviderClass.class)
	public void mCCpayment_Edit_71(String CCnum,String CCExp,String CCpin) throws IOException {
		PosDashBoardPage DBpage=new PosDashBoardPage((IOSDriver<WebElement>)ADR);
		PosChecksPage chkPage=new PosChecksPage((IOSDriver<WebElement>)ADR);
		PosNewChkPage NChkpage=new PosNewChkPage((IOSDriver<WebElement>)ADR);
		POSPaymentPage payPage=new POSPaymentPage((IOSDriver<WebElement>)ADR);
		float totalBill=(float)0.0;
		String checkNo=NChkpage.CreateCheck();
		NChkpage.clickOnPay();
		totalBill=payPage.toatlBill();
		payPage.selectManualCC();
		payPage.enterCCdetails(CCnum, CCExp, CCpin);
		payPage.clickAuthorize();
		//add tip
		payPage.editPayment((float)0.4);
		payPage.updatePayment();
		//edit amount and tip
		payPage.editPayment(totalBill-3, (float)0.6);
		payPage.updatePayment();
		payPage.refundGiftCard();
		Logger.info("refunding Payment is covered here");
		payPage.checkVoid("Item");
		DBpage.clickOnDashBoard();
		DBpage.clickFloor();
	}
	
	@Test(enabled=true, priority=71)
	public void mCCpayment_INVcard() throws IOException {
		PosDashBoardPage DBpage=new PosDashBoardPage((IOSDriver<WebElement>)ADR);
		PosChecksPage chkPage=new PosChecksPage((IOSDriver<WebElement>)ADR);
		PosNewChkPage NChkpage=new PosNewChkPage((IOSDriver<WebElement>)ADR);
		POSPaymentPage payPage=new POSPaymentPage((IOSDriver<WebElement>)ADR);
		String checkNo=NChkpage.CreateCheck();
		NChkpage.clickOnPay();
		payPage.selectManualCC();
		DateFormat df = new SimpleDateFormat("yy"); // Just the year, with 2 digits
		String formattedDate = df.format(Calendar.getInstance().getTime());
		payPage.enterCCdetails("4242424242424243", "12"+formattedDate, "201");
		payPage.clickOnAuthorize();
		payPage.invalidCrad();
		payPage.checkVoid("Mind");
		DBpage.clickOnDashBoard();
		DBpage.clickFloor();
	}
	
	@Test(enabled=true, priority=71)
	public void mCCpayment_10Digit() throws IOException {
		PosDashBoardPage DBpage=new PosDashBoardPage((IOSDriver<WebElement>)ADR);
		PosChecksPage chkPage=new PosChecksPage((IOSDriver<WebElement>)ADR);
		PosNewChkPage NChkpage=new PosNewChkPage((IOSDriver<WebElement>)ADR);
		POSPaymentPage payPage=new POSPaymentPage((IOSDriver<WebElement>)ADR);
		String checkNo=NChkpage.CreateCheck();
		NChkpage.clickOnPay();
		payPage.selectManualCC();
		DateFormat df = new SimpleDateFormat("yy"); // Just the year, with 2 digits
		String formattedDate = df.format(Calendar.getInstance().getTime());
		payPage.enterCCdetails("4242424243", "12"+formattedDate, "201");
		Assert.assertEquals(false, payPage.AuthoriseEnabled());
		payPage.clickOnBack();
		payPage.checkVoid("Mind");
		DBpage.clickOnDashBoard();
		DBpage.clickFloor();
	}
	
	
	@Test(enabled=true, priority=71)
	public void mCCpayment_EXPcard() throws IOException {
		PosDashBoardPage DBpage=new PosDashBoardPage((IOSDriver<WebElement>)ADR);
		PosChecksPage chkPage=new PosChecksPage((IOSDriver<WebElement>)ADR);
		PosNewChkPage NChkpage=new PosNewChkPage((IOSDriver<WebElement>)ADR);
		POSPaymentPage payPage=new POSPaymentPage((IOSDriver<WebElement>)ADR);
		String checkNo=NChkpage.CreateCheck();
		NChkpage.clickOnPay();
		//expired card
		payPage.selectManualCC();
		payPage.enterCCdetails("4242424242424242", "1212", "201");
		payPage.clickOnAuthorize();
		payPage.expiredCrad();
		payPage.checkVoid("Mind");
		DBpage.clickOnDashBoard();
		DBpage.clickFloor();
	}

}
