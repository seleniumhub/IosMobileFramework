package salido.pos.page;

import java.io.IOException;
import salido.pos.logger.Logger;
import salido.pos.utils.PosUtilClass;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import salido.pos.base.PosBaseClass;

public class PosLoginPage extends PosBaseClass {
	PosUtilClass posUtils=new PosUtilClass();
	public PosLoginPage(IOSDriver<WebElement> driver) throws IOException {
		super();
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	@iOSFindBy(xpath="//XCUIElementTypeTextField")
	private MobileElement email;
	@iOSFindBy(xpath="//XCUIElementTypeSecureTextField")
	private MobileElement password;
	@iOSFindBy(id="OrderEntryModalCheckmarkButton")
	private MobileElement rightArrow;

	public void poslogin() throws InterruptedException {
		WebElement banner = ADR.findElement(By.name("Swipe Left to Begin Setup"));
		org.openqa.selenium.Point bannerPoint = banner.getLocation();
		Dimension screenSize = ADR.manage().window().getSize();

		int startX = Math.toIntExact(Math.round(screenSize.getWidth() * 0.8));
		int endX = 0;

		TouchAction action = new TouchAction(ADR);
		action
		.press(PointOption.point(startX, bannerPoint.getY()))
		.waitAction(WaitOptions.waitOptions(Duration.ofMillis(500)))
		.moveTo(PointOption.point(endX, bannerPoint.getY()))
		.release();
		ADR.performTouchAction(action);

		posUtils.waitUntilElementDisplayed(email,10);
		email.sendKeys(prop.getProperty("value"));
		password.sendKeys(prop.getProperty("Passwordvalue"));

		try {
			password.sendKeys(Keys.ENTER);
			posUtils.waitForSec(1);
		}
		catch(WebDriverException e) {
			//			e.printStackTrace();
		}
		try {
			if(rightArrow.isDisplayed()) {
				rightArrow.click();
			}
		}
		catch(ElementNotVisibleException e) {
			//			e.printStackTrace();
		}
		catch(NoSuchElementException e) {
			//			e.printStackTrace();
		}
		Thread.sleep(2000);
		Logger.info("Login Successfull");
	}

	@iOSFindBy(id="What Organization is this Station for?")
	private MobileElement OrgPage;

	private String selctOrgBrandLocTerm="//XCUIElementTypeCell/XCUIElementTypeStaticText[contains(@name,'xxxx')]";

	@iOSFindBy(id="What Brand is this Station for?")
	private MobileElement brandPage;

	public void organizationName(String str) throws InterruptedException {
		posUtils.waitUntilElementDisplayed(OrgPage,10);
		posUtils.webElementWithDynamicXpath(selctOrgBrandLocTerm, "xxxx", str).click();
		posUtils.waitUntilElementDisplayed(brandPage,10);
		String text = brandPage.getText();
		Assert.assertEquals(text, "What Brand is this Station for?");
		Logger.info("Organization selected Successfully");
	}

	@iOSFindBy(id="What Restaurant is this Station for?")
	private MobileElement locationPage;

	public void BrandName(String str) throws InterruptedException {
		posUtils.waitUntilElementDisplayed(brandPage,10);
		posUtils.webElementWithDynamicXpath(selctOrgBrandLocTerm, "xxxx", str).click();
		posUtils.waitUntilElementDisplayed(locationPage,10);
		Assert.assertEquals(locationPage.getText(), "What Restaurant is this Station for?");
		Logger.info("Brand selected  Successfully");
	}

	@iOSFindBy(id="What Terminal is this?")
	private MobileElement terminalPage;

	public void LocationName(String str) throws InterruptedException {
		posUtils.waitUntilElementDisplayed(locationPage,10);
		posUtils.webElementWithDynamicXpath(selctOrgBrandLocTerm, "xxxx", str).click();
		posUtils.waitUntilElementDisplayed(terminalPage,10);
		Assert.assertEquals(terminalPage.getText(), "What Terminal is this?");
		Logger.info("Location selected  Successfully");
	}

	@iOSFindBy(id="Close")
	private MobileElement close;
	@iOSFindBy(xpath="//XCUIElementTypeImage[@name=\"sALIDOPinIn\"]/../preceding-sibling::XCUIElementTypeStaticText[1]")
	private MobileElement getLocation;
	@iOSFindBy(xpath="//XCUIElementTypeImage[@name=\"sALIDOPinIn\"]/../preceding-sibling::XCUIElementTypeStaticText[2]")
	private MobileElement getTerminal;

	public void TerminalName(String str) throws InterruptedException, IOException {
		posUtils.waitUntilElementDisplayed(terminalPage,10);
		while((posUtils.webElementSWithDynamicXpath(selctOrgBrandLocTerm, "xxxx", str).size())==0) {
			posUtils.ScrollDown();
		}
		while(!posUtils.webElementSWithDynamicXpath(selctOrgBrandLocTerm, "xxxx", str).get(0).isDisplayed()) {
			posUtils.ScrollDown();
		}
		posUtils.webElementSWithDynamicXpath(selctOrgBrandLocTerm, "xxxx", str).get(0).click();
		posUtils.waitUntilElementDisplayed((MobileElement)ADR.findElement(By.id(prop.getProperty("1"))));
		Logger.info("Terminal selected Successfully");
		posUtils.fluentWaitforElement(getTerminal,40);
		String text = getTerminal.getText();
		Assert.assertEquals(text, str);
		Logger.info("Terminal  Verified  Successfully");
		unlock();
	}	
	@iOSFindBy(id="closeNotifcenter")
	private MobileElement notifications;

	@iOSFindBy(xpath="//XCUIElementTypeButton[@name=\"DashboardButtonNormal\"]")
	private MobileElement dashBoardNormal;
	boolean newUser=false;
	public void unlock() throws IOException {

		Logger.info("Waiting for a Minute, upgrade popup");
		try {
			posUtils.fluentWaitforElement(close,30);
			if(close.isDisplayed()) {
				close.click();
				Logger.info("Close Button Displayed and closed");
			}
		}
		catch(NoSuchElementException e) {
			Logger.info("Upgrade to new version pop up not appeared");
		}
//		try {
//			Logger.info("Checkeing for Internet Connectivity.");
//			if(ADR.findElementByXPath("//XCUIElementTypeImage[@name=\"iconOfflineQuiet\"]").isEnabled())
//				Logger.info("No Proper Internet");
//		}
//		catch(NoSuchElementException e) {
//			if(ADR.findElementById("iconConnectionQuiet").isEnabled())
//				Logger.info("Internet is Good");
//		}
		Logger.info("Waiting for Location to appear");
		try {
			posUtils.fluentWaitforElement(getLocation,30);
		}
		catch(NoSuchElementException e) {
			
		}
		Logger.info("Unlocking the App.");
		//		posUtils.enterNumber(prop.getProperty("BhavyaLock"));
		posUtils.enterNumber(prop.getProperty("GovindPin"));
		Logger.info("Entered the Pin");

		try {
			Logger.info("Checking for Notifications");
			posUtils.waitUntilElementDisplayed(notifications,20);
			if(notifications.isDisplayed()) {
				notifications.click();
			}
		}
		catch(NoSuchElementException exp) {
			Logger.info("Notifications did not appear. checking for DashBoardNormal");
			posUtils.waitUntilElementDisplayed(dashBoardNormal,10);
//			try {
				if(ADR.findElementByXPath("//XCUIElementTypeButton[@name=\"DashboardButtonNormal\"]").isDisplayed()) {
					Logger.info("Dashboard page is displayed");
				}
//			}
//			catch(NoSuchElementException e) {
//				checkStartShift();
//				if(newUser)
//					checkUserAccessibility();
//			}
		}

	}

	@iOSFindBy(xpath="//XCUIElementTypeImage[@name=\"sALIDOPinIn\"]/../../following-sibling::XCUIElementTypeOther/XCUIElementTypeStaticText")
	private MobileElement startShift;
	@iOSFindBy(xpath="//XCUIElementTypeImage[@name=\"sALIDOPinIn\"]/../../following-sibling::XCUIElementTypeOther/XCUIElementTypeCollectionView/descendant::XCUIElementTypeStaticText")
	private MobileElement position;
	@iOSFindBy(xpath="//XCUIElementTypeButton[@name=\"End Break\"]")
	private MobileElement endBreak;

	public void checkStartShift() {
		try {
			Logger.info("Checking for the User to Start Shift");
			posUtils.waitUntilElementDisplayed(position,25);
			if(position.isDisplayed()) {
				newUser=true;
				Logger.info("Welcome new User");
				Logger.info("Hi "+ startShift.getText());
				Logger.info("Your Position is: "+position.getText());
				position.click();
			}
		}
		catch(NoSuchElementException e) {
			Logger.info("Checking for the User on Break");
			if(endBreak.isDisplayed()) {
				Logger.info("Hi "+ startShift.getText());
				Logger.info("End Break");
				endBreak.click();
			}
		}
	}

	@iOSFindBy(id="Support")
	private MobileElement support;
	@iOSFindBy(xpath="//XCUIElementTypeButton[@name=\"Support\"]/preceding::XCUIElementTypeButton[1]")
	private MobileElement user;
	@iOSFindBy(xpath="//XCUIElementTypeCollectionView/XCUIElementTypeOther[2]/preceding::XCUIElementTypeCell/XCUIElementTypeStaticText")
	private List<MobileElement> POS_permissions;
	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"Manage Position Categories\"]")
	private MobileElement managePositionCategories;
	@iOSFindBy(xpath="//XCUIElementTypeCollectionView/XCUIElementTypeOther/following::XCUIElementTypeCell/XCUIElementTypeStaticText")
	private List<MobileElement> Bridge_permissions;

	public void checkUserAccessibility() {
		try {
			posUtils.waitUntilElementDisplayed(support,10);
			if(support.isDisplayed()) {
				Logger.info("Going to Show User Accessibility Settings");
				user.click();
				for(MobileElement ele:POS_permissions) {
					posUtils.isDisplayed(ele);
					posUtils.isEnabled(ele);
				}
				posUtils.ScrollDown();
				posUtils.ScrollDown(400, 400, 0.55, 0.5);
				for(MobileElement ele:Bridge_permissions) {
					posUtils.isDisplayed(ele);
					posUtils.isEnabled(ele);
				}
				ADR.findElement(By.id(prop.getProperty("backButton"))).click();
				try {
					if(ADR.findElement(By.id("Floor Plan")).isDisplayed()) {
						ADR.findElement(By.id("Floor Plan")).click();
					}
				}
				catch(NoSuchElementException e) {
					posUtils.waitUntilElementDisplayed(dashBoardNormal,10);
				}
			}
		}
		catch(NoSuchElementException e) {
		}
	}

}
