package salido.pos.page;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import io.appium.java_client.MobileElement;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;
import salido.pos.base.PosBaseClass;
import salido.pos.logger.Logger;
import salido.pos.utils.PosUtilClass;

public class PosGuestPage extends PosBaseClass{

	PosUtilClass posUtils=new PosUtilClass();
//	static Logger Logger = Logger.getLogger(PosChecksPage.class);
	public PosGuestPage(IOSDriver<WebElement> driver) throws IOException {
		super();
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@iOSFindBy(xpath="//XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeButton")
	private MobileElement newGuest;
	
	@iOSFindBy(id="SAVE")
	private MobileElement saveGuest;
	
	public void clickOnNewGuestIcon() {
		try {
		if(newGuest.isDisplayed()) {
			Logger.info("New Guset Icon is displayed and clicking on it to create new guest.");
			newGuest.click();
			posUtils.waitUntilElementDisplayed(saveGuest);
		}
		else {
			Logger.info("new Guest Icon is not displayed in the page.");
		}
		}
		catch(NoSuchElementException e) {
			e.printStackTrace();
		}
	}
	
	private String textField="//XCUIElementTypeButton[@name=\"closeBridge\"]/following-sibling::XCUIElementTypeCollectionView/XCUIElementTypeCell/XCUIElementTypeTextField[";
	
	@iOSFindBy(xpath="//XCUIElementTypeButton[@name=\"closeBridge\"]/following-sibling::XCUIElementTypeCollectionView/XCUIElementTypeCell/XCUIElementTypeButton[1]")
	private MobileElement male;
	
	@iOSFindBy(xpath="//XCUIElementTypeButton[@name=\"closeBridge\"]/following-sibling::XCUIElementTypeCollectionView/XCUIElementTypeCell/XCUIElementTypeButton[2]")
	private MobileElement female;
	
	public void enterGuestData() {
		posUtils.webElementWithDynamicIndexXpath(textField, 1, "]").sendKeys("AutoFirstName");
		posUtils.webElementWithDynamicIndexXpath(textField, 2, "]").sendKeys("AutoLastName");
		if(male.isDisplayed()) {
			male.click();
		}
		else {
			female.click();
		}
		posUtils.webElementWithDynamicIndexXpath(textField, 3, "]").sendKeys("9963115794");  //7795469004
		posUtils.webElementWithDynamicIndexXpath(textField, 5, "]").sendKeys("aUtomation@auto.com");
	}
	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"Sorry, could not save at this time.\"]")
	private MobileElement cantSave;
	
	@iOSFindBy(id="closeBridge")
	private MobileElement closeCreateGuest;
	
	public void closeGuest() {
		closeCreateGuest.click();
	}
	public void clickOnSAVE() {
		saveGuest.click();
		try {
		if(searchGuest.isDisplayed()) {
			Logger.info("User Successfully created Guest");
		}
		}
		catch(NoSuchElementException e) {
			Logger.info("Guest did not Save");
		}
		try {
		if(cantSave.isDisplayed()) {
			Logger.info("Guest Already Exist with the details");
			closeCreateGuest.click();
		}
		}
		catch(NoSuchElementException e) {
			Logger.info("Internet Issue");
		}
	}
	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"No Guests Found.\"]/preceding::XCUIElementTypeTextField")
	private MobileElement searchGuest;
	
	private String guestfound="(//XCUIElementTypeStaticText[@name=\"Guests\"]/following::XCUIElementTypeCollectionView/descendant::XCUIElementTypeCell/XCUIElementTypeStaticText[contains(@name,'xxxx')])[1]";
	
	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"Guests\"]/following::XCUIElementTypeCollectionView/descendant::XCUIElementTypeCell")
	private List<MobileElement> searchResults;
	
	public boolean VerifyGuestcreation(String str) throws InterruptedException {
		searchGuest.clear();
		searchGuest.sendKeys(str);
		Thread.sleep(5000);
		try {
		if(posUtils.webElementWithDynamicXpath(guestfound, "xxxx", str).isDisplayed()) {
			Logger.info("Guest Details appeared when searched.");
			return true;
		}
		}
		catch(NoSuchElementException e) {
			if(foundNoGuest()) {
				return false;
			}
		}
		return false;
	}
	@iOSFindBy(id="No Guests Found.")
	private MobileElement noguest;
	public boolean foundNoGuest() {
		try {
			if(noguest.isDisplayed()) {
				Logger.info("Guest was not Found");
				return true;
			}
		}
		catch(NoSuchElementException e) {
			e.printStackTrace();
		}
		return false;
	}
//	public void clickOnGuest(String str,int num) {
//		posUtils.webElementWithStringIndexXpath(guestnumfound, "xxxx", str, num, "]").click();
//	}
	public void Guests() throws InterruptedException{
		System.out.println("Guestmethod");
		ADR.findElement(By.xpath(prop.getProperty("DashboardButton"))).click();
		ADR.findElement(By.xpath(prop.getProperty("Guest"))).click();
		Thread.sleep(2000);
		ADR.findElement(By.xpath(prop.getProperty("AddGuest"))).click();
		ADR.findElement(By.xpath(prop.getProperty("FirstGuest"))).sendKeys("guestfirstname1");
		ADR.findElement(By.xpath(prop.getProperty("LastGuest"))).sendKeys("guestlastname");
		ADR.findElement(By.xpath(prop.getProperty("Email"))).sendKeys("test@test1.com");
		ADR.findElement(By.xpath(prop.getProperty("male"))).click();
		
		ADR.findElement(By.xpath(prop.getProperty("save"))).click();
		ADR.findElement(By.xpath(prop.getProperty("DashboardButton"))).click();
		ADR.findElement(By.xpath(prop.getProperty("Guest"))).click();
		ADR.findElement(By.xpath(prop.getProperty("search"))).sendKeys("guestfirstname1");
		Thread.sleep(2000);
		WebElement result1 = ADR.findElement(By.xpath(prop.getProperty("TableValue")));
	
		String text1 = result1.getText();
		
		System.out.println(text1);
		Assert.assertEquals(text1, "guestfirstname1 guestlastname");
		System.out.println("Guest Craeted  Successfully");
		

	}
	
public void GuestAddress() throws InterruptedException
{
	System.out.println("GuestAddressmethod");
	ADR.findElement(By.xpath(prop.getProperty("DashboardButton"))).click();
	ADR.findElement(By.xpath(prop.getProperty("Guest"))).click();
	Thread.sleep(2000);
	ADR.findElement(By.xpath(prop.getProperty("AddGuest"))).click();
	ADR.findElement(By.xpath(prop.getProperty("FirstGuest"))).sendKeys("guestfirst");
	ADR.findElement(By.xpath(prop.getProperty("LastGuest"))).sendKeys("guestlast");
	ADR.findElement(By.xpath(prop.getProperty("Address"))).click();
	Thread.sleep(2000);
	ADR.findElement(By.xpath(prop.getProperty("Address1"))).click();
	ADR.findElement(By.xpath(prop.getProperty("Company"))).sendKeys("TestCompany");
	ADR.findElement(By.xpath(prop.getProperty("StreetAddress"))).sendKeys("StreetAddress");
	ADR.findElement(By.xpath(prop.getProperty("City"))).sendKeys("denver");
	ADR.findElement(By.xpath(prop.getProperty("state"))).sendKeys("co");
	ADR.findElement(By.xpath(prop.getProperty("Zip"))).sendKeys("20888");
	ADR.findElement(By.xpath(prop.getProperty("save"))).click();
	System.out.println("Guest Address Save Successfully");
}

public void DeleteAddress() throws InterruptedException
{
	System.out.println("GuestDeleteAddressMethod");
	ADR.findElement(By.xpath(prop.getProperty("DashboardButton"))).click();
	ADR.findElement(By.xpath(prop.getProperty("Guest"))).click();
	ADR.findElement(By.xpath(prop.getProperty("search"))).sendKeys("Tgu");
	ADR.findElement(By.xpath(prop.getProperty("TableValue"))).click();
	Thread.sleep(200);
	ADR.findElement(By.xpath(prop.getProperty("delete"))).click();
	ADR.findElement(By.xpath(prop.getProperty("save"))).click();
}
}
