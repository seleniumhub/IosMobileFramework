package salido.pos.logger;

import java.io.File;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import org.apache.log4j.Level;
import org.apache.log4j.Priority;
import org.apache.log4j.PropertyConfigurator;
import org.testng.Reporter;

public class Logger {
	protected static boolean isConfigured = false;
	protected static String loggerFile= File.separator+"log4j.properties";
	
	public synchronized static org.apache.log4j.Logger getLogger(String logFileName){
		if(!isConfigured) {
			PropertyConfigurator.configure(System.getProperty("user.dir")+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+logFileName);			
		}
		return org.apache.log4j.Logger.getLogger(getClassName());
	} 
	public synchronized static org.apache.log4j.Logger getLogger(){
		if(!isConfigured) {
			PropertyConfigurator.configure(System.getProperty("user.dir")+File.separator+"src"+File.separator+"test"+File.separator+"resources"+org.apache.commons.io.FilenameUtils.separatorsToSystem(loggerFile));
		}
		return org.apache.log4j.Logger.getLogger(getClassName());
	} 
	public synchronized static String getClassName() {
		try {
			return Thread.currentThread().getContextClassLoader().loadClass(Thread.currentThread().getStackTrace()[4].getClassName()).getName();
		}
		catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		return "";
	}
	public synchronized static void debug(Object message) {
		getLogger().debug(message);
		Reporter.log(getTimeStamp()+" "+message);
	}
	public static String getTimeStamp() {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		java.util.Date date= new java.util.Date();
		Timestamp ts=new Timestamp(date.getTime());
		return format.format(ts);
	}
	public synchronized static void debug(Object message, Throwable t) {
		getLogger().debug(message,t);
		Reporter.log(getTimeStamp()+" "+message);
	}
	
	public synchronized static void error(Object message) {
		getLogger().error(message);
		Reporter.log(getTimeStamp()+" "+message);
	}
	public synchronized static void error(Object message, Throwable t) {
		getLogger().error(message,t);
		Reporter.log(getTimeStamp()+" "+message);
	}
	public synchronized static void fatal(Object message) {
		getLogger().fatal(message);
		Reporter.log(getTimeStamp()+" "+message);
	}
	public synchronized static void fatal(Object message, Throwable t) {
		getLogger().fatal(message,t);
		Reporter.log(getTimeStamp()+" "+message);
	}
	public synchronized static void info(Object message) {
		getLogger().info(message);
		Reporter.log(getTimeStamp()+" "+message);
	}
	public synchronized static void info(Object message, Throwable t) {
		getLogger().info(message,t);
		Reporter.log(getTimeStamp()+" "+message);
	}
	public synchronized static void warn(Object message) {
		getLogger().warn(message);
		Reporter.log(getTimeStamp()+" "+message);
	}
	public synchronized static void warn(Object message, Throwable t) {
		getLogger().warn(message,t);
		Reporter.log(getTimeStamp()+" "+message);
	}
	public synchronized static boolean isDebugEnabled() {
		return getLogger().isDebugEnabled();
	}
	public synchronized static boolean isInfoEnabled() {
		return getLogger().isInfoEnabled();
	}
	public synchronized static boolean isEnabledFor(Priority level) {
		return getLogger().isEnabledFor(level);
	}
	public synchronized static void setLevel(Level level) {
		getLogger().setLevel(level);
	}
	
}
