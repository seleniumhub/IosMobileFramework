package salido.pos.testcases;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import java.io.IOException;

import org.testng.annotations.Test;

import salido.pos.base.PosBaseClass;
import salido.pos.page.PosFloorPlanPage;

import org.testng.annotations.Test;

public class SalidoTestFloorPlan extends PosBaseClass {
	
  public SalidoTestFloorPlan() throws IOException {
		super();
		
	}
PosFloorPlanPage floor = new PosFloorPlanPage();
  
  
@Test(enabled = false,priority =3)
  public void floorview() throws InterruptedException
  {
	
	System.out.println("floor method");
	floor.floorView();
  }


@Test(enabled = false  ,priority =4)
public void floorTimeopen() throws InterruptedException, IOException
{
	
	System.out.println("floor TimeOpen method");
	floor.Timeopen();
}


@Test(enabled = false ,priority =5)
public void floorPartySize() throws InterruptedException
{
	
	System.out.println("floorParty Size method");
	floor.PartySize();
}

@Test(enabled = false ,priority =5)
public void floorLastorder() throws InterruptedException
{
	
	System.out.println("floorLastorder Size method");
	floor.lastorder();
}




}
