package salido.pos.dataProvider;

import org.testng.annotations.DataProvider;

public class DataProviderClass {
	
	@DataProvider(name="Visa")
	public static Object[][] TestCard02(){
		return new Object[][] {
				{"4761739001010119","1222","201"}
		};
	}
	
	@DataProvider(name="Master")
	public static Object[][] TestCard20(){
		return new Object[][] {
				{"5413330089099130","1222","201"}
		};
	}
	
	@DataProvider(name="Amex")
	public static Object[][] TestCard13(){
		return new Object[][] {
				{"374245001751006","1224","201"}
		};
	}
	
	@DataProvider(name="All")
	public static Object[][] TestCard14(){
		return new Object[][] {
				{"374245001751006","1224","201"}, //Amex
				{"5413330089099130","1222","201"}, //Master
				{"4761739001010119","1222","201"}, //Visa
				{"6510000000000133","1223",""} //Discover
		};
	}
	
	@DataProvider(name="GiftCard")
	public Object[][] giftCardNumber(){
		return new Object[][] {
			{"2073220100145802"}
		};
	}

}
