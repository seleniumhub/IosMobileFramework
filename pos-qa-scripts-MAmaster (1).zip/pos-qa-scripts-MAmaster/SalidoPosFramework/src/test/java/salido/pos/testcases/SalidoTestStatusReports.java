package salido.pos.testcases;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;

public class SalidoTestStatusReports {
	
	
	@Test ( enabled =false)
	  public void reports()
	  {
		 System.out.println("reports method"); 
	  }


}
