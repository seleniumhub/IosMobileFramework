package salido.pos.testnglisteners;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import io.appium.java_client.ios.IOSDriver;
import salido.pos.base.PosBaseClass;
import salido.pos.logger.Logger;
import salido.pos.page.PosLoginPage;
import salido.pos.utils.PosUtilClass;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
public class TestListener implements ITestListener{
	PosUtilClass Utils;
	@Override
	public void onTestStart(ITestResult result) {
		Logger.info("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		Logger.info("Started the testcase: "+result.getMethod().getMethodName());
		Logger.info("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		Logger.info("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		Logger.info("Completed the testcase: "+result.getMethod().getMethodName());
		Logger.info("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		
	}

	@Override
	public void onTestFailure(ITestResult iTestResult) {
		
        try {
        	PosBaseClass pBclass=new PosBaseClass();
            File file = pBclass.ADR.getScreenshotAs(OutputType.FILE);
            String replaceString= "/target/ScreenShots/";
            String  destDir=System.getProperty("user.dir")+org.apache.commons.io.FilenameUtils.separatorsToSystem(replaceString);
            // the filename is the folder name on test.screenshot.path property plus the completeTestName
            FileUtils.copyFile(file,
                    new File(destDir + composeTestName(iTestResult) + ".png"));
            
        } 
        catch (IOException e) {
            e.printStackTrace();
        } finally {
        	Logger.info("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    		Logger.error("Failed the testcase: "+iTestResult.getMethod().getMethodName());
    		Logger.info("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        	PosBaseClass base;
			try {
				base = new PosBaseClass();
				base.ADR.launchApp();
	    		PosLoginPage loginPage=new PosLoginPage((IOSDriver<WebElement>) base.ADR);
	    		loginPage.unlock();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
		
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onStart(ITestContext context) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onFinish(ITestContext context) {
		// TODO Auto-generated method stub
		
	}
	
	private String composeTestName(ITestResult iTestResult) {
        StringBuffer completeFileName = new StringBuffer();
        completeFileName.append(iTestResult.getTestClass().getRealClass().getSimpleName()); // simplified class name
        completeFileName.append("_");
        completeFileName.append(iTestResult.getName()); // method name
        //add IST timeStamp
        SimpleDateFormat gmtDateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
        gmtDateFormat.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
        completeFileName.append(gmtDateFormat.format(new Date()));
        // all the parameters information
        Object[] parameters = iTestResult.getParameters();
        for(Object parameter : parameters) {
            completeFileName.append("_");
            completeFileName.append(parameter);
        } 
        // return the complete name and replace : by - (in the case the emulator have port as device name)
        return completeFileName.toString().replace(":", "-");
    }

}
