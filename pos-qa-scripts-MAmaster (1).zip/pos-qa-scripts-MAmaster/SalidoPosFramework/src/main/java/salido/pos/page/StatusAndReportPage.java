package salido.pos.page;

public class StatusAndReportPage {

}
