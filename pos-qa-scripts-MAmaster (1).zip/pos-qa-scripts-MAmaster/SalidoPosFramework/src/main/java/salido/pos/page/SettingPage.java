package salido.pos.page;

public class SettingPage {

}
