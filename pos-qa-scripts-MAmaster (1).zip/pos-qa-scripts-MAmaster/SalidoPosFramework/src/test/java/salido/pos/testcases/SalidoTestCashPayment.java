package salido.pos.testcases;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import salido.pos.logger.Logger;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.appium.java_client.ios.IOSDriver;
import salido.pos.base.PosBaseClass;
import salido.pos.page.ManageMenuPage;
import salido.pos.page.POSPaymentPage;
import salido.pos.page.PosChecksPage;
import salido.pos.page.PosDashBoardPage;
import salido.pos.page.PosLoginPage;
import salido.pos.page.PosManageBankPage;
import salido.pos.page.PosNewChkPage;

public class SalidoTestCashPayment extends PosBaseClass{

	private String checkNo;
	public SalidoTestCashPayment() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}
	
//	@BeforeClass
	public void launchSalidoApp() throws IOException {
		Appiuminitialization();
//		ADR.launchApp();
		PosLoginPage loginPage=new PosLoginPage((IOSDriver<WebElement>)ADR);
		loginPage.unlock();
	}
	
	
	@Test (priority=51,enabled=true)
	public void PayCashAuthClose_TC_05() throws IOException, InterruptedException {
		PosManageBankPage MBPage = new PosManageBankPage((IOSDriver<WebElement>)ADR);
		PosDashBoardPage DBPage=new PosDashBoardPage((IOSDriver<WebElement>) ADR);
		PosChecksPage PChPage=new PosChecksPage((IOSDriver<WebElement>) ADR);
		PosNewChkPage NChkPage=new PosNewChkPage((IOSDriver<WebElement>) ADR);
		POSPaymentPage PCPage=new POSPaymentPage((IOSDriver<WebElement>) ADR);
		MBPage.checkBank((float)500);
		checkNo=NChkPage.CreateCheck();
		float bill=PCPage.toatlBill();
		try {
			PCPage.payByCash();		
			PChPage.clickOnFloorPlan();
			DBPage.clickOnDashBoard();
			DBPage.clickOnBank();
			MBPage.verifyPayInOut(bill);
			MBPage.preserveBankAmount();
			DBPage.clickOnDashBoard();
			DBPage.checkChecksMenu();
		}
		finally {
			try {
				PChPage.clickOnFloorPlan();
				DBPage.clickOnDashBoard();
				DBPage.checkChecksMenu();
				String chkstate = PChPage.searchAndOpenCheck(checkNo);
				if(chkstate.equalsIgnoreCase("closed"))
					PChPage.reOpenCheck();
				PCPage.clickOnPay();
				PCPage.refundPayment();
				Logger.info("Refunding the Payment test case is covered here");
				PCPage.checkVoid("Item");
				Logger.info("Voiding check test case is covered here");
				PCPage.back2Checks();
				DBPage.clickOnDashBoard();
				DBPage.clickOnBank();
				MBPage.verifyPayInOut(-bill);
				DBPage.clickOnDashBoard();
				DBPage.checkChecksMenu();
			}
			catch(NoSuchElementException e) {
				Logger.info("Check #"+checkNo+" is not voided. If require Void Manually");
				DBPage.clickOnDashBoard();
				e.printStackTrace();
			}
		}
	}
	
//Item, Mind, Error, Reason and Testing --> voiding reasons
	@Test (priority=51,enabled=true)
	public void PayCashSplitClose_TC_06() throws IOException, InterruptedException {
		PosManageBankPage MBPage = new PosManageBankPage((IOSDriver<WebElement>)ADR);
		PosChecksPage PChPage=new PosChecksPage((IOSDriver<WebElement>) ADR);
		POSPaymentPage PCPage=new POSPaymentPage((IOSDriver<WebElement>) ADR);
		PosNewChkPage NChkPage=new PosNewChkPage((IOSDriver<WebElement>) ADR);
		PosDashBoardPage DBPage=new PosDashBoardPage((IOSDriver<WebElement>) ADR);
		MBPage.checkBank((float)500);
		String checkNo=NChkPage.CreateCheck();
		float bill=PCPage.toatlBill();
		try {
			PCPage.splitPaybyCash();	
			PChPage.clickOnFloorPlan();
			DBPage.clickOnDashBoard();
			DBPage.clickOnBank();
			MBPage.verifyPayInOut(bill);
			MBPage.preserveBankAmount();
			DBPage.clickOnDashBoard();
			DBPage.checkChecksMenu();
		}
		finally {
			try {
				PChPage.clickOnFloorPlan();
				DBPage.clickOnDashBoard();
				DBPage.checkChecksMenu();
				String chkstate = PChPage.searchAndOpenCheck(checkNo);
				if(chkstate.equalsIgnoreCase("closed"))
					PChPage.reOpenCheck();
				PCPage.clickOnPay();
				PCPage.refundPayment();
				Logger.info("Refunding the Payment test case is covered here");
				PCPage.checkVoid("Mind");
				Logger.info("Voiding check test case is covered here");
				PCPage.back2Checks();
				DBPage.clickOnDashBoard();
				DBPage.clickOnBank();
				MBPage.verifyPayInOut(-bill);
				DBPage.clickOnDashBoard();
				DBPage.checkChecksMenu();
			}
			catch(NoSuchElementException e) {
				Logger.info("Check #"+checkNo+" is not voided. If require Void Manually");
				DBPage.clickOnDashBoard();
				e.printStackTrace();
			}
		}
	}
	
	@Test (priority=51,enabled=true)
	public void PayCashEditExisting_TC_57() throws IOException {
		PosManageBankPage MBPage = new PosManageBankPage((IOSDriver<WebElement>)ADR);
		PosChecksPage PChPage=new PosChecksPage((IOSDriver<WebElement>) ADR);
		POSPaymentPage PCPage=new POSPaymentPage((IOSDriver<WebElement>) ADR);
		PosNewChkPage NChkPage=new PosNewChkPage((IOSDriver<WebElement>) ADR);
		PosDashBoardPage DBPage=new PosDashBoardPage((IOSDriver<WebElement>) ADR);
		MBPage.checkBank((float)500);
		String checkNo=NChkPage.CreateCheck();
		float bill=PCPage.toatlBill();
		try {
			PCPage.clickOnPay();
			PCPage.byCashEnabled();
			PCPage.payPartialByCash((float) 0.0, (float)0.4);
			PCPage.editPayment((float)0.6);
			PCPage.updatePayment();
			PCPage.closeCheck();
			PChPage.clickOnFloorPlan();
			DBPage.clickOnDashBoard();
			DBPage.clickOnBank();
			MBPage.verifyPayInOut(bill);
			MBPage.preserveBankAmount();
			DBPage.clickOnDashBoard();
			DBPage.checkChecksMenu();
		}
		finally {
			try {
				DBPage.clickOnDashBoard();
				DBPage.checkChecksMenu();
				String chkstate = PChPage.searchAndOpenCheck(checkNo);
				if(chkstate.equalsIgnoreCase("closed"))
					PChPage.reOpenCheck();
				PCPage.clickOnPay();
				PCPage.refundPayment();
				Logger.info("Refunding the Payment test case is covered here");
				PCPage.checkVoid("Test");
				Logger.info("Voiding check test case is covered here");
				PCPage.back2Checks();
				DBPage.clickOnDashBoard();
				DBPage.clickOnBank();
				MBPage.verifyPayInOut(-bill);
				DBPage.clickOnDashBoard();
				DBPage.checkChecksMenu();
			}
			catch(NoSuchElementException e) {
				Logger.info("Check #"+checkNo+" is not voided. If require Void Manually");
				DBPage.clickOnDashBoard();
				e.printStackTrace();
			}
		}
	}
	
}
