package salido.pos.testcases;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.appium.java_client.ios.IOSDriver;
import salido.pos.base.PosBaseClass;
import salido.pos.dataProvider.DataProviderClass;
import salido.pos.logger.Logger;
import salido.pos.page.POSPaymentPage;
import salido.pos.page.PosChecksPage;
import salido.pos.page.PosDashBoardPage;
import salido.pos.page.PosLoginPage;
import salido.pos.page.PosNewChkPage;
import salido.pos.utils.PosUtilClass;

public class SalidoTestCustomPayment extends PosBaseClass{

	PosUtilClass posutils=new PosUtilClass();
	public SalidoTestCustomPayment() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}

//	@BeforeClass
	public void relaunchApp() throws IOException {
//		Appiuminitialization();
		ADR.launchApp();
		PosLoginPage login=new PosLoginPage((IOSDriver<WebElement>)ADR);
		login.unlock();
	}

	@Test(enabled=true, priority=81)
	public void customPayment() throws IOException {
		PosDashBoardPage DBpage=new PosDashBoardPage((IOSDriver<WebElement>)ADR);
		PosChecksPage chkPage=new PosChecksPage((IOSDriver<WebElement>)ADR);
		PosNewChkPage NChkpage=new PosNewChkPage((IOSDriver<WebElement>)ADR);
		POSPaymentPage payPage=new POSPaymentPage((IOSDriver<WebElement>)ADR);
		String checkNo=NChkpage.CreateCheck();
		NChkpage.clickOnPay();
		NChkpage.clickOnOtherPayments();
		payPage.selectCustom();
		payPage.clickOnADD();
		payPage.closeCheck();
		String chkStatus=chkPage.searchAndOpenCheck(checkNo);
		if(chkStatus.equalsIgnoreCase("closed"))
			chkPage.reOpenCheck();
		NChkpage.clickOnPay();
		payPage.refundCustom();
		Logger.info("refunding Payment is covered here");
		payPage.checkVoid("Mind");
		payPage.back2Checks();
		DBpage.clickOnDashBoard();
		DBpage.clickFloor();
	}

	@Test(enabled=true,priority=81)
	public void customPayment_split_19() throws IOException {
		PosDashBoardPage DBpage=new PosDashBoardPage((IOSDriver<WebElement>)ADR);
		PosChecksPage chkPage=new PosChecksPage((IOSDriver<WebElement>)ADR);
		PosNewChkPage NChkpage=new PosNewChkPage((IOSDriver<WebElement>)ADR);
		POSPaymentPage payPage=new POSPaymentPage((IOSDriver<WebElement>)ADR);
		float totalBill=(float)0.0;
		String checkNo=NChkpage.CreateCheck();
		NChkpage.clickOnPay();
		totalBill=payPage.toatlBill();
		String []spltbil=payPage.splitbill(totalBill);
		for(int rp=0;rp<2;rp++) {
			NChkpage.clickOnOtherPayments();
			payPage.selectCustom();
			posutils.enterNumber(spltbil[rp]);
			payPage.clickOnADD();
		}
		payPage.closeCheck();
		String chkStatus=chkPage.searchAndOpenCheck(checkNo);
		if(chkStatus.equalsIgnoreCase("closed"))
			chkPage.reOpenCheck();
		NChkpage.clickOnPay();
		payPage.refundCustom();
		Logger.info("refunding Payment is covered here");
		payPage.checkVoid("Test");
		payPage.back2Checks();
		DBpage.clickOnDashBoard();
		DBpage.clickFloor();
	}

	@Test(enabled=true,priority=81)
	public void customPayment_Edit_71() throws IOException {
		PosDashBoardPage DBpage=new PosDashBoardPage((IOSDriver<WebElement>)ADR);
		PosChecksPage chkPage=new PosChecksPage((IOSDriver<WebElement>)ADR);
		PosNewChkPage NChkpage=new PosNewChkPage((IOSDriver<WebElement>)ADR);
		POSPaymentPage payPage=new POSPaymentPage((IOSDriver<WebElement>)ADR);
		float totalBill=(float)0.0;
		String checkNo=NChkpage.CreateCheck();
		NChkpage.clickOnPay();
		totalBill=payPage.toatlBill();
		NChkpage.clickOnOtherPayments();
		payPage.selectCustom();
		payPage.clickOnADD();
		//add tip
		payPage.editPayment(0, (float)0.4);
		payPage.updatePayment();
		//edit amount and tip
		payPage.editPayment(totalBill-3, (float)0.6);
		payPage.updatePayment();
		payPage.refundCustom();
		Logger.info("refunding Payment is covered here");
		payPage.checkVoid("Item");
		DBpage.clickOnDashBoard();
		DBpage.clickFloor();
	}
}
