package salido.pos.page;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import salido.pos.base.PosBaseClass;
import salido.pos.logger.Logger;
import salido.pos.utils.PosUtilClass;

public class BrowserLoginPage extends PosBaseClass{

	PosUtilClass posUtils=new PosUtilClass();
			
	public BrowserLoginPage() throws IOException {
		super();
		PageFactory.initElements(new AppiumFieldDecorator(ADR), this);
	}

	@FindBy(id="session_email")
	private WebElement emailfiled;
	
	@FindBy(id="session_password")
	private WebElement passwordField;
	
	@FindBy(xpath="//button")
	private WebElement signIn;
	
	public void enterLoginDetails(String email,String password) {
		WebDriverWait wait=new WebDriverWait(ADR,35);
		wait.until(ExpectedConditions.visibilityOf(emailfiled));
		Logger.info("Entering the credentials");
		emailfiled.sendKeys(email);
		passwordField.sendKeys(password);
		signIn.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("mount")));
		Logger.info("Login Successful");
	}
	
	@FindBy(xpath="//div[@class=\"dashboard-topbar--right dashboard-topbar--section\"]/div[@class=\"old-bridge-return\"]")
	private WebElement switchBridge;
	
	@FindBy(xpath="//button[contains(text(),'Close')]")
	private WebElement close;
	
	public void bridgeSwitch() {
		WebDriverWait wait=new WebDriverWait(ADR,35);
		wait.until(ExpectedConditions.visibilityOf(switchBridge));
		switchBridge.click();
		Logger.info("Switching to older version");
		wait.until(ExpectedConditions.visibilityOf(close));
		close.click();
	}
	
	@FindBy(id="user-info")
	private WebElement userInfo;
	
	@FindBy(xpath="//a[text()=\"Logout\"]")
	private WebElement logout;
	
	@FindBy(xpath="//div[contains(text(),'signed out')]")
	private WebElement signedOut;
	
	public void logOut() {
		userInfo.click();
		posUtils.waitUntilElementDisplayed(logout);
		Logger.info("LogOut is visible");
		logout.click();
		posUtils.waitUntilElementDisplayed(signedOut);
		Assert.assertEquals(true, signedOut.isDisplayed());
		Logger.info("Signed Out successfully");
	}
	
	@FindBy(id="developer")
	private WebElement developer;
	
	@FindBy(xpath="//a[text()=\"Applications\"]")
	private WebElement Apps;
	
	@FindBy(xpath="//td[contains(text(),'POS (STG)')]/following-sibling::td/a[contains(text(),'View Builds')]")
	private WebElement viewPOS_STG_Builds;
	
	@FindBy(id="users")
	private WebElement buildsPage;
	
	@FindBy(xpath="//tbody/tr/td[1]")
	private WebElement latestVersion;
	
	@FindBy(xpath="//tbody/tr/td[2]")
	private WebElement latestBuild;
	
	@FindBy(xpath="//tbody/tr[1]/td/ul/li/a")
	private WebElement dots3;
	
	@FindBy(xpath="//tbody/tr[1]/td/ul/li/descendant::a[contains(text(),'Download')]")
	private WebElement downloadBuild;
	
	@FindBy(id="Open")
	private WebElement openiTunes;
	
	public boolean downloadBuild() {
		developer.click();
		Apps.click();
		WebDriverWait wait=new WebDriverWait(ADR,30);
		wait.until(ExpectedConditions.visibilityOf(viewPOS_STG_Builds));
		viewPOS_STG_Builds.click();
		wait.until(ExpectedConditions.visibilityOf(buildsPage));
		String version=latestVersion.getText();
		Logger.info("Version :"+version);
		Logger.info("Build# "+latestBuild.getText());
		dots3.click();
		downloadBuild.click();
		// need to work on next 2 lines, no able to identify open 
		if(openiTunes.isDisplayed())  
			openiTunes.click();
		    Logger.info("wait for Alert");
//		    WebDriverWait wait = new WebDriverWait(ADR, 60);
		    try {
		        wait.until(ExpectedConditions.alertIsPresent());
		        Logger.info("Accepting the Alert");
		        ADR.switchTo().alert().accept();
		        return true;
		    } catch (Exception e) {
		        Logger.info("no alert visible after "+30+" sec.");
		    }
		    return false;
	}
	
}
