package salido.pos.testcases;

import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.appium.java_client.ios.IOSDriver;

import org.testng.annotations.Test;
import java.io.IOException;
import java.net.MalformedURLException;

import org.testng.annotations.Test;

import salido.pos.base.PosBaseClass;
import salido.pos.page.PosDashBoardPage;
import salido.pos.page.PosLoginPage;
import salido.pos.page.PosManageBankPage;
import salido.pos.utils.PosUtilClass;

import org.testng.annotations.Test;

public class SalidoTestMangeBank extends PosBaseClass{

	PosUtilClass posUtils=new PosUtilClass();

	public SalidoTestMangeBank() throws IOException {
		super();
	}

//	@BeforeTest
//	public void AppInit() throws IOException {
//		Appiuminitialization();
//		ADR.launchApp();
//		PosLoginPage login=new PosLoginPage((IOSDriver<WebElement>)ADR);
//		login.unlock();
//	}

//	@BeforeClass
//	public void manageBank() throws IOException {
//		ADR.launchApp();
//		PosLoginPage login=new PosLoginPage((IOSDriver<WebElement>)ADR);
//		login.unlock();
//	}

	@Test(enabled = true, priority =12)
	public void openbank() throws IOException{
		PosManageBankPage bank = new PosManageBankPage((IOSDriver<WebElement>)ADR);
		PosDashBoardPage menu=new PosDashBoardPage((IOSDriver<WebElement>)ADR);
		menu.clickOnDashBoard();
		menu.checkMangeBank();
		bank.checkBank((float)500);
	}

	@Test(enabled = true, priority =13)
	public void Payin() throws IOException {
		PosManageBankPage bank = new PosManageBankPage((IOSDriver<WebElement>)ADR);
		PosDashBoardPage menu=new PosDashBoardPage((IOSDriver<WebElement>)ADR);
		menu.clickOnDashBoard();
		menu.checkMangeBank();
		bank.preserveBankAmount();
		try {
		bank.bankPayIn((float)200);
		} finally {
		bank.preserveBankAmount();
		bank.Payout((float)200);
		}
	}

	@Test(enabled = true, priority =14)
	public void close() throws IOException{
		PosManageBankPage bank = new PosManageBankPage((IOSDriver<WebElement>)ADR);
		PosDashBoardPage menu=new PosDashBoardPage((IOSDriver<WebElement>)ADR);
		menu.clickOnDashBoard();
		menu.checkMangeBank();
		float bal=bank.getBankAmount();
		bank.preserveBankAmount();
		try {
			bank.closeBank(bal);
		} finally {
			bank.openBank(bal);
		}
	}	


	@Test(enabled = true, priority =21)
	public void Payout() throws IOException{  
		PosManageBankPage bank = new PosManageBankPage((IOSDriver<WebElement>)ADR);
		PosDashBoardPage menu=new PosDashBoardPage((IOSDriver<WebElement>)ADR);
		menu.clickOnDashBoard();
		menu.checkMangeBank();
		bank.preserveBankAmount();
		float bal=bank.getBankAmount();
		try {
			bank.Payout((float)bal);
		} finally {
			bank.preserveBankAmount();
			bank.bankPayIn((float)bal);
		}
	}	

	@Test(enabled = true, priority =16)
	public void Payoutmore() throws IOException{  
		PosManageBankPage bank = new PosManageBankPage((IOSDriver<WebElement>)ADR);
		PosDashBoardPage menu=new PosDashBoardPage((IOSDriver<WebElement>)ADR);
		menu.clickOnDashBoard();
		menu.checkMangeBank();
		bank.preserveBankAmount();
		float bal=bank.getBankAmount();
		bank.Payout((float)(bal+5));
	}	

	@Test(enabled = true, priority =17)
	public void closeless() throws IOException{
		PosManageBankPage bank = new PosManageBankPage((IOSDriver<WebElement>)ADR);
		PosDashBoardPage menu=new PosDashBoardPage((IOSDriver<WebElement>)ADR);
		menu.clickOnDashBoard();
		menu.checkMangeBank();
		float bal=bank.getBankAmount();
		bank.preserveBankAmount();
		try {
			bank.closeBank(bal-(bal-5));
		}
		finally {
			bank.openBank(bal);
		}
	}	

	@Test(enabled = true, priority =18)
	public void closemore() throws IOException{
		PosManageBankPage bank = new PosManageBankPage((IOSDriver<WebElement>)ADR);
		PosDashBoardPage menu=new PosDashBoardPage((IOSDriver<WebElement>)ADR);
		menu.clickOnDashBoard();
		menu.checkMangeBank();
		float bal=bank.getBankAmount();
		bank.preserveBankAmount();
		try {
			bank.closeBank(bal+5);
		} finally {
			bank.openBank(bal);
		}
	}	
}
