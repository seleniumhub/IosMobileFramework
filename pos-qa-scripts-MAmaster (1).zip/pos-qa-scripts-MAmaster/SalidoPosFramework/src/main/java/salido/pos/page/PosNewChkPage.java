package salido.pos.page;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import io.appium.java_client.MobileElement;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;
import salido.pos.base.PosBaseClass;
import salido.pos.logger.Logger;
import salido.pos.utils.PosUtilClass;

public class PosNewChkPage extends PosBaseClass{

	PosUtilClass posUtils=new PosUtilClass();

	public PosNewChkPage(IOSDriver<WebElement> driver) throws IOException  {
		super();
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	private String chkParam="//XCUIElementTypeStaticText[@name=\"OWNER\"]/following-sibling::XCUIElementTypeStaticText[";


	public String getNewCheckNo() {
		String checkno="";
		if(chkTable.getAttribute("name").equalsIgnoreCase("none")) {
			checkno=posUtils.webElementWithDynamicIndexXpath(chkParam, 1, "]").getAttribute("value");
		}
		else {
			checkno=posUtils.webElementWithDynamicIndexXpath(chkParam, 2, "]").getAttribute("value");
		}
		Logger.info("Check# is: "+checkno);
		return checkno;
	}


	private MobileElement chkTime() {
		if(chkTable.getAttribute("name").equalsIgnoreCase("none")) {
			return (MobileElement) posUtils.webElementWithDynamicIndexXpath(chkParam, 3, "]");
		}
		else {
			return (MobileElement) posUtils.webElementWithDynamicIndexXpath(chkParam, 4, "]");
		}
	}

	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"TABLE\"]/preceding::XCUIElementTypeOther/preceding::XCUIElementTypeButton[2]")
	private WebElement chkTable;

	public String getChkOwner() {
		String chkOwner="";
		if(chkTable.getAttribute("name").equalsIgnoreCase("none")) {
			chkOwner=posUtils.webElementWithDynamicIndexXpath(chkParam, 3, "]").getAttribute("value");
		}
		else {
			chkOwner=posUtils.webElementWithDynamicIndexXpath(chkParam, 4, "]").getAttribute("value");
		}
		Logger.info("Check Owner is: "+chkOwner);
		return chkOwner;
	}

	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"ORDER TYPE\"]/preceding::XCUIElementTypeButton[3]")
	private WebElement selectOrderType;

	public void newCheck(String str) throws IOException {
		PosChecksPage checks= new PosChecksPage((IOSDriver<WebElement>) ADR);
		checks.selectRevenueCenter(str);
		//		checks.selectEmployeeAll();
		//		checks.selectOrderTypeAll();
		//		String []checkStatus= {"Open","Close","Schedule"};
		//		ArrayList<String> chknoary = new ArrayList<String>();
		//		for(String status:checkStatus) {
		//			clickOnStatusType();
		//			selectChkStatusType(status);
		//			int checkslNo=noOfChecks.size();
		////			Logger.info("Total number of checks of available are: "+checkslNo);
		//			for(int num=1;num<=checkslNo;num++) {
		//				chknoary.add(webElementWithDynamicIndexXpath(checkNo1, num, checkNo2).getAttribute("name"));
		//			}
		//		}
		checks.clickOncreateNewCheck();
		//		Check Number is randomly generated. It is possible to have duplicates within the day but usually doesn’t happen
		String newChkNo = getNewCheckNo();
		if(chkTime().getAttribute("name").equalsIgnoreCase("new")) {
			Logger.info("new Check is tring to create with Check No: "+newChkNo);
			//			if(chknoary.contains(newChkNo)) {
			//				Logger.info("App trying to create new check with the existing check Number");
			//				Assert.assertEquals(true, false);
			//			}
			//			else {
			//				Logger.info("New check has the check number which is not available in existing checks:"+ newChkNo);
			//			}
		}
		else {
			Logger.info("New check is not created after clicking on CreateNewCheck");
		}
		ManageMenuPage MMPage=new ManageMenuPage((IOSDriver<WebElement>) ADR);
		MMPage.clickOnDashBoard();
	}
	@iOSFindBy(xpath="//XCUIElementTypeButton[@name=\"SEARCH\"]/following-sibling::XCUIElementTypeButton[1]")
	private WebElement selectMenu;

	private String checkmenu="//XCUIElementTypeStaticText[@name=\"Subtotal\"]/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther/XCUIElementTypeButton[";

	public void clickOnDiscount() {
		posUtils.webElementWithDynamicIndexXpath(checkmenu, 1, "]").click();
	}

	public void clikOnVoidChk() {
		posUtils.webElementWithDynamicIndexXpath(checkmenu, 2, "]").click();
		Logger.info("clicked on Void Check");
	} 

	public void clikOnSaveSend() {
		posUtils.webElementWithDynamicIndexXpath(checkmenu, 4, "]").click();
		Logger.info("clicked on save/send Check");
	} 

	public void clickOnGratuity() {
		posUtils.webElementWithDynamicIndexXpath(checkmenu, 5, "]").click();
	}

	public void clickOnTransfer() {
		posUtils.webElementWithDynamicIndexXpath(checkmenu, 6, "]").click();
	}

	public void clickOnSplit() {
		posUtils.webElementWithDynamicIndexXpath(checkmenu, 7, "]").click();
		Logger.info("Clicked on split button");
	}

	@iOSFindBy(id="Merge")
	private WebElement confirmMerge;

	public void clickOnMerge() {
		posUtils.webElementWithDynamicIndexXpath(checkmenu, 8, "]").click();
		Logger.info("Clicked on Merge button");
		try {
			if(confirmMerge.isDisplayed()) {
				confirmMerge.click();
			}
		}
		catch(NoSuchElementException e) {
			Logger.info("Pop up didn't appear for confirmation");
		}
	}

	@iOSFindBy(accessibility="Beverages")
	private WebElement beverages;

	@iOSFindBy(xpath="(//XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeCollectionView/XCUIElementTypeCell/XCUIElementTypeOther/following-sibling::XCUIElementTypeOther/following-sibling::XCUIElementTypeStaticText/..)[last()]/XCUIElementTypeStaticText[1]")
	private WebElement itemName;
	@iOSFindBy(xpath="(//XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeCollectionView/XCUIElementTypeCell/XCUIElementTypeOther/following-sibling::XCUIElementTypeOther/following-sibling::XCUIElementTypeStaticText/..)[last()]/XCUIElementTypeStaticText[3]")
	private WebElement itemtype;

	public void addItemNVerify() throws IOException {
		ManageMenuPage MMPage=new ManageMenuPage((IOSDriver<WebElement>) ADR);
		posUtils.fluentWaitforElement(selectMenu);
		selectMenu.click();
		if(MMPage.displaySelectMenu()) {
			MMPage.selectBreakfast();
		}
		beverages.click();
		String item1=MMPage.clickOnMeatbal();
		String item1type=MMPage.selectSmall();
		if(itemName.getAttribute("value").equalsIgnoreCase(item1) && itemtype.getAttribute("value").contains(item1type)) {
			Logger.info(item1+" "+item1type+" is selected");
		}
		else {
			Logger.error("Wrong item is selected");
		}
		String item2=MMPage.clickOnBurger();
		String item2type=MMPage.selectLarge();
		if(itemName.getAttribute("value").equalsIgnoreCase(item2) && itemtype.getAttribute("value").contains(item2type)) {
			Logger.info(item2+" "+item2type+" is selected");
		}
		else {
			Logger.error("Wrong item is selected");
		}
		String item3=MMPage.selectRedWine();
		if(itemName.getAttribute("value").equalsIgnoreCase(item3)) {
			Logger.info(item3+" is selected");
		}
		else {
			Logger.error("Wrong item is selected");
		}
		//		clikOnSaveSend();
	}

	public void addbreakfast() throws IOException {
		ManageMenuPage MMPage=new ManageMenuPage((IOSDriver<WebElement>) ADR);
		posUtils.fluentWaitforElement(selectMenu);
		selectMenu.click();
		if(MMPage.displaySelectMenu()) {
			MMPage.selectBreakfast();
		}
		beverages.click();
		MMPage.clickOnMeatbal();
		MMPage.selectSmall();
		Logger.info("Italian Meatbal Small is selected");
		MMPage.clickOnAlcohol();
		MMPage.selectLarge();
		Logger.info("Alcohol Large is selected");
		MMPage.selectVegLasagne();
		Logger.info("Veg Lasagne is selected");
	}

	private String checkno;

	private String stctxt="//XCUIElementTypeStaticText[contains(@name,'xxxx')]";

	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"Dine In\"]")
	private WebElement dineIn;

	public String CreateCheck() throws IOException {
		PosDashBoardPage DBPage=new PosDashBoardPage((IOSDriver<WebElement>) ADR);
		PosChecksPage PChPage=new PosChecksPage((IOSDriver<WebElement>) ADR);
		DBPage.clickOnDashBoard();
		DBPage.checkChecksMenu();
		//		PChPage.listRevenueCenters();
		//		PChPage.selectRevenueCenter("Bar");
		PChPage.clickOncreateNewCheck();
		enterLabel();
		Logger.info("clicking on Order type");
		selectOrderType.click();
		Logger.info("clicking on Dine In");
		dineIn.click();
		checkno=getNewCheckNo();
		addbreakfast();
		clikOnSaveSend();
		Logger.info("successfully created Check #: "+checkno);
		return checkno;
	}

	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"Please provide a label for this check.\"]/preceding::XCUIElementTypeTextField[1]")
	private WebElement labelTextFiled;
	@iOSFindBy(id="DONE")
	private WebElement labelDone;

	public void enterLabel() {
		try {
			String str=labelTextFiled.getAttribute("value");
			labelTextFiled.sendKeys(str);
			posUtils.isEnabled(labelDone);
			labelDone.click();
		} catch(NoSuchElementException e) {
			Logger.info("Check Label did not appear");
		}

	}

	@iOSFindBy(xpath="(//XCUIElementTypeCollectionView)[1]/XCUIElementTypeCell")
	private List<WebElement> noOfItemsSelected;

	private String slctdItm="(//XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeCollectionView/XCUIElementTypeCell/XCUIElementTypeOther/following-sibling::XCUIElementTypeOther/following-sibling::XCUIElementTypeStaticText/..)["; 
	private String itmPrice="]/XCUIElementTypeStaticText[2]";
	private String itmQntty="]/XCUIElementTypeStaticText[3]";
	private String sltditmNam="]/XCUIElementTypeStaticText[1]";

	@iOSFindBy(id="iconRepeatSmall")
	private WebElement reorder;

	@iOSFindBy(id="check") 
	private WebElement done;

	@iOSFindBy(id="iconRemove") 
	private WebElement voidItem;

	public int randomlySelectOrderedItem() {
		int ordereditemsNo=noOfItemsSelected.size();
		int num=1;
		if(ordereditemsNo>1)
			num=posUtils.getRandomNumberInRange(1, ordereditemsNo);
		posUtils.webElementWithDynamicIndexXpath(slctdItm, num, "]").click();
		return num;
	}

	public void deselctOrderedItem(int num) {
		posUtils.webElementWithDynamicIndexXpath(slctdItm, num, "]").click();
	}

	@iOSFindBy(id="DISCOUNTS")
	private WebElement itemDiscount;

	@iOSFindBy(id="No Discount")
	private WebElement removeItemDiscount;

	public void selectItemDiscount(String str,String discfom) {
		itemDiscount.click();
		posUtils.waitUntilElementDisplayed(removeItemDiscount,15);
		String discVal=posUtils.webElementWithDynamicXpath(stctxtflwgstctxt, "xxxx", str).getAttribute("name");
		Logger.info("Discount Applied is: "+discVal);
		if(discVal.contains("$")) {
			if(discfom.equals(discVal.split("\\$")[1])) {
				Logger.info("Value Matched");
			}
			else {
				Assert.assertEquals(true, false);
			}
		}
		else if(discVal.contains("%")) {
			if(discfom.equals(discVal.split("\\%")[0])) {
				Logger.info("Value Matched");
			}
			else {
				Assert.assertEquals(true, false);
			}
		}
		posUtils.webElementWithDynamicXpath(stctxt, "xxxx", str).click();
		posUtils.waitUntilElementDisplayed(addNote,3);
		try {
			if(addNote.isDisplayed()) {
				posUtils.webElementWithDynamicXpath(stctxt+"/following::XCUIElementTypeTextField", "xxxx", "ADD DISCOUNT").sendKeys("Discount added for testing");
				addNote.click();
			}
		} catch(NoSuchElementException e) {
			Logger.info("Add Note is not dispalyed");
		}
	}

	public void removeItemDiscount() {
		itemDiscount.click();
		removeItemDiscount.click();
	}

	public boolean editItemCount() {
		boolean cntMtchd=true;
		int itemCnt=noOfItemsSelected.size();
		for(int num=1;num<=itemCnt;num++) {
			posUtils.webElementWithDynamicIndexXpath(slctdItm, num, "]").click();
			int repeat=0;
			int numdispld=0;
			int entrnum=0;
			if(num==1) {
				repeat=posUtils.getRandomNumberInRange(2, 7);
				for(int num2=1;num2<=repeat;num2++) {
					reorder.click();
				}		
				entrnum=repeat+1;
				posUtils.webElementWithDynamicIndexXpath(slctdItm, num, "]").click();
			}
			else if(num==itemCnt) {
				entrnum=posUtils.getRandomNumberInRange(2, 7);
				posUtils.enterNumber(posUtils.num2Str(entrnum));
				done.click();
			}else {
				entrnum=repeat+1;
				posUtils.webElementWithDynamicIndexXpath(slctdItm, num, "]").click();
			}
			numdispld=getSelectedItemQuantity(num);
			if(entrnum==numdispld) {	
				Logger.info("Item "+num+" Count displayed correct");
			}
			else {
				Logger.error("Item "+num+" Count displayed Wrong");
				cntMtchd=false;
			}			

		}
		return cntMtchd;
	}
	public int getSelectedItemQuantity(int slNoSelected) {
		String itmCntstr=posUtils.webElementWithDynamicIndexXpath(slctdItm, slNoSelected, itmQntty).getAttribute("name");
		return getItemQuantity(itmCntstr);
	}
	@iOSFindBy(id="$")
	private WebElement priceButton;

	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\" / ea\"]/preceding::XCUIElementTypeTextField[1]")
	private WebElement eachPrice;

	@iOSFindBy(id="CANCEL")
	private WebElement cancel;
	public boolean verifyAllItemsPrice() {
		boolean pricematchd=true;
		int itemCnt=noOfItemsSelected.size();
		for(int num=1;num<=itemCnt;num++) {
			posUtils.webElementWithDynamicIndexXpath(slctdItm, num, "]").click();
			priceButton.click();
			float eaprice=posUtils.str2float(eachPrice.getAttribute("value"));
			cancel.click();
			posUtils.webElementWithDynamicIndexXpath(slctdItm, num, "]").click();
			String itmprcstr=posUtils.webElementWithDynamicIndexXpath(slctdItm, num, itmPrice).getAttribute("name");
			float itmprc=posUtils.price2float(itmprcstr);
			String itmCntstr=posUtils.webElementWithDynamicIndexXpath(slctdItm, num, itmQntty).getAttribute("name");
			int qntty=getItemQuantity(itmCntstr);
			if(qntty==1) {
				if(eaprice==itmprc) {
					Logger.info("Item "+num+" price displayed correct");
				}
				else {
					Logger.error("Item "+num+" price displayed Wrong");
					pricematchd=false;
					Assert.assertEquals(true, false);
				}
			}
			else if(qntty>1) {
				if((eaprice*qntty)==itmprc) {
					Logger.info("Item "+num+" price displayed correct");
				}
				else {
					Logger.error("Item "+num+" price displayed Wrong");
					pricematchd=false;
					Assert.assertEquals(true, false);
				}
			}
		}
		return pricematchd;
	}
	public int getItemQuantity(String str) {		
		String []spltstr=str.split("\\s");
		return posUtils.str2num(spltstr[0].substring(1));		
	}
	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"TABLE\"]/../XCUIElementTypeButton[1]")
	private WebElement label;
	public void clickOnLabel() {
		label.click();
	}

	@iOSFindBy(xpath="//XCUIElementTypeButton[@name=\"+\"]/preceding::XCUIElementTypeTextField[1]")
	private WebElement partySize;

	@iOSFindBy(id="+")
	private WebElement incrmnt;

	@iOSFindBy(id="-")
	private WebElement decrmnt;

	public void verifyPartySize(int defSize) {
		if(posUtils.str2num(partySize.getAttribute("value"))==defSize) {
			Logger.info("Party Size matched");
		} else {
			Logger.error("Party Size did not match");
			Assert.assertEquals(true, false);
		}
	}

	public void editPartySize() {
		partySize.click();
		singleElementClickRepeat(((partySize.getAttribute("value")).toCharArray()).length, (MobileElement) ADR.findElementById(prop.getProperty("deletekey")));
		int psize=posUtils.getRandomNumberInRange(1, 15);
		posUtils.enterNumber(posUtils.num2Str(psize));
		ADR.findElementById(prop.getProperty("savekey")).click();
		int dec=posUtils.getRandomNumberInRange(0, psize);
		singleElementClickRepeat(dec,decrmnt);
		int inc=posUtils.getRandomNumberInRange(0, (psize-dec+1));
		singleElementClickRepeat(inc,incrmnt);
		String psz=posUtils.num2Str(psize-dec+inc);
		if(psz.equals(partySize.getAttribute("value"))) {
			Logger.info("Party Size entered is matched with display");
		}
		else {
			Logger.error("Party Size entered is not matched with display");
		}
	}

	public void singleElementClickRepeat(int num,WebElement ele) {
		for(int num1=1;num1<=num;num1++) {
			ele.click();
		}
	}

	@iOSFindBy(xpath="//XCUIElementTypeButton[@name=\"+\"]/following-sibling::XCUIElementTypeTextField[1]")
	private WebElement editLabel;
	public void editLabelText(String str) {
		editLabel.click();
		new Actions(ADR).sendKeys(Keys.COMMAND, "k").perform();
		editLabel.clear();
		String labelstr="Auto "+str;
		editLabel.sendKeys(labelstr);
		//		ADR.getKeyboard().pressKey("\n");
		if(editLabel.getAttribute("value").equalsIgnoreCase(labelstr)) {
			Logger.info("Entered label text is matching with dispaly");
		}
		else {
			Logger.error("Entered label text is not matching with dispaly");
		}
	}
	@iOSFindBy(xpath="//XCUIElementTypeImage[@name=\"iconAddGuest\"]/preceding::XCUIElementTypeButton[1]")
	private WebElement addGuestButton;

	@iOSFindBy(id="iconDiscardDark")
	private WebElement removeGuest;

	@iOSFindBy(xpath="//XCUIElementTypeButton[@name=\"New Guest\"]/preceding::XCUIElementTypeTextField[1]")
	private WebElement searchfield;
	private String guestfound="//XCUIElementTypeButton[@name=\"closeBridge\"]/following::XCUIElementTypeCollectionView/XCUIElementTypeCell[";
	private String guestnumfound="]/XCUIElementTypeStaticText[contains(@name,'xxxx')]";

	@iOSFindBy(xpath="//XCUIElementTypeButton[@name=\"closeBridge\"]/following::XCUIElementTypeCollectionView/XCUIElementTypeCell")
	private List<WebElement> searchresults;

	public void searchGuestandClick(String str,int num) throws IOException, InterruptedException {
		searchfield.clear();
		searchfield.sendKeys(str,Keys.ENTER);
		Thread.sleep(5000);
		if(!posUtils.webElementWithIndexStringReplaceXpath(guestfound, num, guestnumfound,"xxxx", str).isDisplayed()) {
			Logger.info("Guest Not Found :(");
		}
		else {
			Logger.info(searchresults.size()+" Guests found with search text: "+str);
			posUtils.webElementWithIndexStringReplaceXpath(guestfound, num, guestnumfound,"xxxx", str).click();
		}
	}

	public void addGuest2Chek(String str,int num) throws IOException, InterruptedException {
		addGuestButton.click();
		searchGuestandClick(str,num);
		posUtils.waitUntilElementDisplayed(removeGuest);
		if(removeGuest.isDisplayed()) {
			Logger.info("Guest added Succesfully");
		}
	}

	private String guestIconNum="(//XCUIElementTypeButton[@name=\"iconDiscardDark\"])[";
	private String guestName="]/../XCUIElementTypeStaticText";

	public void removeGuest4mcheck(int num) {
		try {
			Logger.info("You are removing the "+posUtils.webElementWithDynamicIndexXpath(guestIconNum, num, guestName).getAttribute("name")+" guest");
			posUtils.webElementWithDynamicIndexXpath(guestIconNum, num, "]").click();
		}
		catch(NoSuchElementException e) {
			e.printStackTrace();
		}
	}

	public void reOrderItem() {
		int num=posUtils.getRandomNumberInRange(1, noOfItemsSelected.size());
		posUtils.webElementWithDynamicIndexXpath(slctdItm, num, "]").click();
		String reItemName=posUtils.webElementWithDynamicIndexXpath(slctdItm, num,sltditmNam).getAttribute("name");
		reorder.click();
		posUtils.webElementWithDynamicIndexXpath(slctdItm, num, "]").click();
		if(reItemName.equalsIgnoreCase(itemName.getAttribute("name"))) {
			Logger.info("ReOrdered Item Name Matched");
		}
		else {
			Logger.info("ReOrdered Item Name not Matched");
		}
	}

	@iOSFindBy(xpath="//XCUIElementTypeButton[@name=\"CANCEL\"]/following-sibling::XCUIElementTypeButton")
	private WebElement authVoid;

	public void clickOnVoidReason(String str) {
		//		String str1="Why are you voiding this";
		//		posUtils.waitUntilElementDisplayed(ADR.findElement(By.xpath("//XCUIElementTypeStaticText[contains(@name,'"+str1+"')]")));
		//posUtils.waitUntilElementDisplayed(posUtils.webElementWithDynamicXpath(stctxt,"xxxx","Why are you voiding this"));
		ADR.findElement(By.xpath("//XCUIElementTypeStaticText[contains(@name,'"+str+"')]")).click();
		//posUtils.webElementWithDynamicXpath(stctxt,"xxxx",str).click();
	}

	public void confirmVoid() {
		authVoid.click();
		authVoid.click();
	}

	public void deleteItem(String voidreason) {
		int existItemNo=noOfItemsSelected.size();
		int num=posUtils.getRandomNumberInRange(1, existItemNo);
		MobileElement reitem=posUtils.webElementWithDynamicIndexXpath(slctdItm, num, sltditmNam);
		String reItemName=reitem.getAttribute("name");
		Logger.info("You are deleteing: "+reItemName);
		reitem.click();
		voidItem.click();
		clickOnVoidReason(voidreason);
		if(existItemNo==(noOfItemsSelected.size()+1)) {
			Logger.info("Item Deleted Successfully");
		}
	}

	private String splitcheck="(//XCUIElementTypeButton[starts-with(@name,'Split ')])[";
	private String itemSplitSelect="//XCUIElementTypeButton[@name=\"BackButton\"]/../XCUIElementTypeOther[1]/descendant::XCUIElementTypeCell[";
	@iOSFindBy(xpath="//XCUIElementTypeButton[@name=\"BackButton\"]/../XCUIElementTypeOther[1]/descendant::XCUIElementTypeCell")
	private List<WebElement> itemsSplit;

	public String getSplitChkNo() {
		String splt=posUtils.webElementWithDynamicIndexXpath(splitcheck, 1, "]").getAttribute("name");
		String []spltchk=splt.split("\\s");
		Logger.info("Splitting to new check: #"+spltchk[2]);
		return spltchk[2];
	}

	public void clickOnSplitChk() {
		posUtils.webElementWithDynamicIndexXpath(splitcheck, 2, "]").click();
		Logger.info("clicking on split check button");
	}

	public void splitItems() {
		int noOfItemsSplit=itemsSplit.size();
		for(int num=1;num<=((int)Math.floor(noOfItemsSplit/2));num++) {
			int remainNo=itemsSplit.size();
			posUtils.webElementWithDynamicIndexXpath(itemSplitSelect, posUtils.getRandomNumberInRange(1, remainNo), "]").click();
		}
		Logger.info("Items Moved to another check");
	}

	private String selctchk2merge="//XCUIElementTypeStaticText[@name=\"Tap a destination check above.\"]/preceding::XCUIElementTypeCell/XCUIElementTypeStaticText[contains(@name,'xxxx')]";

	public void selectChek2Merge(String str){		
		while((posUtils.webElementSWithDynamicXpath(selctchk2merge, "xxxx", str).size())==0) {
			posUtils.ScrollDown();
			try {
				if(posUtils.webElementWithDynamicXpath(selctchk2merge, "xxxx", str).isDisplayed()) {
					break;
				}
			}
			catch(NoSuchElementException e) {
				Logger.info("Check Not found! Scrolling down.");
			}
		}
		while(!posUtils.webElementSWithDynamicXpath(selctchk2merge, "xxxx", str).get(0).isDisplayed()){
			posUtils.ScrollDown();
			try {
				if(posUtils.webElementSWithDynamicXpath(selctchk2merge, "xxxx", str).get(0).isDisplayed()) {
					break;
				}
				else {
					Logger.info("Check Not found! Scrolling down.");
				}
			}
			catch(NoSuchElementException e) {
				Logger.info("Check Not found! Scrolling down.");
			}
		}
		if(posUtils.webElementSWithDynamicXpath(selctchk2merge, "xxxx", str).get(0).isDisplayed()) {
			posUtils.webElementSWithDynamicXpath(selctchk2merge, "xxxx", str).get(0).click();
		}

	}

	@iOSFindBy(id="Merge Checks")
	private WebElement mergecheckbutton;

	public void clickOnMergeButton() {
		mergecheckbutton.click();
	}

	@iOSFindBy(id="BackButton")
	private WebElement backbutton;

	public void clickOnBackButton(){
		backbutton.click();
	}

	@iOSFindBy(id="X")
	private WebElement clear;

	@iOSFindBy(xpath="//XCUIElementTypeButton[@name=\"$\"]/following::XCUIElementTypeTextField")
	private WebElement gratuityTextField;

	public void enterGratuityPercentage(double dbl) {
		if(!gratuityTextField.getAttribute("value").equalsIgnoreCase("percent")) {
			Logger.info("existing value: "+gratuityTextField.getAttribute("value"));
			clear.click();
		}
		String str=posUtils.num2Str((int)(dbl*100));
		posUtils.enterNumber(str);
		ADR.findElementById(prop.getProperty("doneKey")).click();
	}

	@iOSFindBy(id="No Gratuity")
	private WebElement nogratuity;

	public void removeGratuity() {
		nogratuity.click();
	}

	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"Subtotal\"]/../following::XCUIElementTypeOther[1]/XCUIElementTypeStaticText")
	private List<WebElement> gratuityfileds;

	public void verifyGratuity() {
		if(gratuityfileds.size()==2) {
			if(posUtils.webElementWithDynamicXpath(alter, "xxxx", "Gratuity").isDisplayed()) {
				Logger.info("Gratuity is displayed");
				Assert.assertEquals(true, true);
			}
			else {
				Logger.info("Under Subtotal "+gratuityfileds.get(0).getText() +" is displayed");
				Assert.assertEquals(true, false);
			}
		}
	}

	private String stctxtflwgstctxt="//XCUIElementTypeStaticText[contains(@name,'xxxx')]/following::XCUIElementTypeStaticText[1]";


	public void verifyGratuityAmount(float ft) {
		String grtAmt=posUtils.webElementWithDynamicXpath(alter+"/following::XCUIElementTypeStaticText[1]", "xxxx", "Gratuity").getText();
		String subAmt=posUtils.webElementWithDynamicXpath(stctxtflwgstctxt, "xxxx", "Subtotal").getAttribute("value");
		float subAmtf=posUtils.str2float(subAmt);
		String calGrtAmt=String.valueOf((float)(Math.round((subAmtf*(ft/100))*100))/100);
		if(grtAmt.equals(calGrtAmt)) {
			Logger.info("Gratuity Amount Matched");
		}
		else {
			Logger.error("Gratuity Amount not Matched");
		}
	}
	private String alter="//XCUIElementTypeStaticText[contains(@name,'Subtotal')]/following::XCUIElementTypeStaticText[contains(@name,'xxxx')]"; 
	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"Total\"]/../preceding::XCUIElementTypeStaticText[1]")
	private WebElement tax;

	public void verifyTotal() {
		float subAmt= posUtils.str2float(posUtils.webElementWithDynamicXpath(stctxtflwgstctxt, "xxxx", "Subtotal").getAttribute("value"));
		float grtAmt=(float) 0.0;
		float discAmt= (float) 0.0;
		float taxAmt= (float) 0.0;
		try {
			if(posUtils.webElementWithDynamicXpath(alter, "xxxx", "Gratuity").isDisplayed()) {
				grtAmt=posUtils.str2float(posUtils.webElementWithDynamicXpath(alter+"/following::XCUIElementTypeStaticText[1]", "xxxx", "Gratuity").getText());
			}
		}
		catch(NoSuchElementException e) {
			Logger.info("Gratuity not found");
		}
		try {
			if(posUtils.webElementWithDynamicXpath(alter, "xxxx", "Discounts").isDisplayed()) {
				discAmt=posUtils.str2float(posUtils.webElementWithDynamicXpath(alter+"/following::XCUIElementTypeStaticText[1]", "xxxx", "Discounts").getText().substring(2));
			}
		}
		catch(NoSuchElementException e) {
			Logger.info("Discounts not found");
		}
		taxAmt=posUtils.str2float(tax.getAttribute("value"));
		String total= posUtils.webElementWithDynamicXpath(stctxtflwgstctxt, "xxxx", "Total").getAttribute("value");
		if(total.contains(String.valueOf((subAmt+grtAmt-discAmt+taxAmt)))){
			Logger.info("Total Amount is matched with the sum of Subtotal and others");
		}
		else {
			Logger.warn("Total Amount is not matched with the sum of Subtotal and others");
		}
	}

	public String checkTotal() {
		String total=posUtils.webElementWithDynamicXpath(stctxtflwgstctxt, "xxxx", "Total").getAttribute("value");
		Logger.info("Total Check Bill: "+total);
		return total;
	}

	@iOSFindBy(id="ADD NOTE")
	private WebElement addNote;

	public void applyDiscount(String str) {
		posUtils.waitUntilElementDisplayed(posUtils.webElementWithDynamicXpath(stctxt, "xxxx", "SELECT DISCOUNT"));
		posUtils.webElementWithDynamicXpath(stctxt, "xxxx", "Comp").click();
		posUtils.waitUntilElementDisplayed(addNote,3);
		try {
			if(addNote.isDisplayed()) {
				posUtils.webElementWithDynamicXpath(stctxt+"/following::XCUIElementTypeTextField", "xxxx", "ADD DISCOUNT").sendKeys("Discount added for testing");
				addNote.click();
			}
		}catch(NoSuchElementException e) {
			Logger.info("Add Note is not displayed");
		}
	}

	public void verifyDiscount() {
		if(gratuityfileds.size()==2) {
			if(gratuityfileds.get(0).getText().contains("Discounts")) {
				Logger.info("Discounts is displayed");
				Assert.assertEquals(true, true);
			}
			else {
				Logger.info("Under Subtotal "+gratuityfileds.get(0).getText() +" is displayed");
				Assert.assertEquals(true, false);
			}
		}
	}

	public void removeDiscount() {
		posUtils.waitUntilElementDisplayed(posUtils.webElementWithDynamicXpath(stctxt, "xxxx", "SELECT DISCOUNT"));
		removeItemDiscount.click();
	}

	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"Total\"]/following-sibling::XCUIElementTypeButton")
	private WebElement pay;

	public void clickOnPay() {
		if(posUtils.isEnabled(pay)) {
			Logger.info("Clicking on PAY Button");
			pay.click();
		}
	} 

	@iOSFindBy(id="+ Other Payments")
	private WebElement otherPayments;

	public void clickOnOtherPayments() {
		if(posUtils.isEnabled(otherPayments)) {
			Logger.info("Clicking on Other Payments Button");
			otherPayments.click();
		}
	}

}
