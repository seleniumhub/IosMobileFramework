package salido.pos.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Parameters;

import com.beust.jcommander.Parameter;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.IOSMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServerHasNotBeenStartedLocallyException;
import io.appium.java_client.service.local.AppiumServiceBuilder;




public class PosBaseClass {

	public static WebDriver driver;
	public static Properties prop;
	public static  AppiumDriver ADR;
	public static IOSDriver IODR;
	public static DesiredCapabilities DC;
	public static AppiumDriverLocalService server;
	public static String home=System.getProperty("user.home");
	
	public  PosBaseClass() throws IOException{
		try {
			prop = new Properties();
//			FileInputStream ip = new FileInputStream(home+ "/Desktop/POS_Automation/SalidoPosFramework/src/main/java/salido/pod/config/config.properties");
			FileInputStream ip = new FileInputStream(home+"/Documents/GitHub/pos-qa-scripts/SalidoPosFramework/src/main/java/salido/pod/config/config.properties");
			prop.load(ip);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		};	
	}

	public void terminalRelease() throws InterruptedException 
	{
		System. setProperty("webdriver.chrome.driver", "/Users/Himanshu/Downloads/chromedriver");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://ss-platform-stg.herokuapp.com/sign-in");
		driver.findElement(By.name("session[email]")).sendKeys("Arjun.gupta@salido.com");
		driver.findElement(By.name("session[password]")).sendKeys("Mind@1234");
		driver.findElement(By.xpath("//button[@class='btn bgm-black']")).click();
		//driver.findElement(By.name("sign in")).click();
		Thread.sleep(6000);
		driver.findElement(By.className("dashboard-topbar--mobile-menu")).click();
		Thread.sleep(6000);
		driver.findElement(By.xpath("//div[text()='Dashboard']")).click();
		Thread.sleep(6000);
		System.out.println("dashboard print");
		driver.close();
	}

	public static void weblauched() throws MalformedURLException
	{
		DC = new DesiredCapabilities();
		DC.setCapability("platformName",prop.getProperty("platformName"));
		DC.setCapability("platformversion",prop.getProperty("platformversion"));
		DC.setCapability("deviceName", prop.getProperty("deviceName"));
		DC.setCapability("FullReset",prop.getProperty("noReset"));
		DC.setCapability("automationName",prop.getProperty("automationName"));
		DC.setCapability("udid", prop.getProperty("udid"));
		DC.setCapability("browserName", prop.getProperty("Browser"));
		ADR = new IOSDriver<WebElement>(new URL (prop.getProperty("url")),DC);
		ADR.get("http://wwww.google.com");
	}
	public void launchiOSSettingsApp() {
		DC = new DesiredCapabilities();
		DC.setCapability("platformName",prop.getProperty("platformName"));
		DC.setCapability("platformVersion",prop.getProperty("platformVersion"));
		DC.setCapability("deviceName", prop.getProperty("deviceName"));
		DC.setCapability("NoReset",prop.getProperty("noReset"));
		DC.setCapability("newCommandTimeout", 6000);
		DC.setCapability("app", "Settings"); 
		DC.setCapability(IOSMobileCapabilityType.BUNDLE_ID, "com.apple.Preferences");
		DC.setCapability("automationName",prop.getProperty("automationName1"));
		DC.setCapability("udid","00008027-001C04E022E3002E");
		DC.setCapability("toggleSoftwareKeyboard", true);
		DC.setCapability("useNewWDA", false);
		DC.setCapability("usePrebuiltWDA", true);
		DC.setCapability("agentPath", prop.getProperty("agentPath"));
		DC.setCapability("bootstrapPath", prop.getProperty("bootstrapPath"));
		try {
			ADR = new IOSDriver<WebElement>(new URL(prop.getProperty("url")),DC);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		
	}

	public void launchiPadSafari()  {
		DC = new DesiredCapabilities();
		DC.setCapability("platformName",prop.getProperty("platformName"));
		DC.setCapability("platformVersion",prop.getProperty("platformVersion"));
		DC.setCapability("deviceName", prop.getProperty("deviceName"));
		DC.setCapability("NoReset",prop.getProperty("noReset"));
		DC.setCapability("newCommandTimeout", 6000);
		DC.setCapability("automationName",prop.getProperty("automationName1"));
		DC.setCapability("udid","00008027-001C04E022E3002E");
		DC.setCapability("toggleSoftwareKeyboard", true);
		DC.setCapability("useNewWDA", false);
		DC.setCapability("usePrebuiltWDA", true);
		DC.setCapability("agentPath", prop.getProperty("agentPath"));
		DC.setCapability("bootstrapPath", prop.getProperty("bootstrapPath"));
//		DC.setCapability("browserName", "Safari");
		DC.setBrowserName("Safari");
		DC.setCapability("startIWDP", true);
		DC.setCapability("locationServicesEnabled", true);
		DC.setCapability("locationServicesAuthorized", true);
		DC.setCapability("wdaLaunchTimeout", 30000);
		DC.setCapability("autoWebview", true);
//		DC.setCapability("safariInitialUrl", "https://ss-platform-stg.herokuapp.com");
		DC.setCapability("autoAcceptAlerts", true);
		try {
			ADR = new IOSDriver<WebElement>(new URL(prop.getProperty("url")),DC);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Set<String> contextNames = ADR.getContextHandles();
		for (String contextName : contextNames) {
		    System.out.println(contextName); //prints out something like NATIVE_APP \n WEBVIEW_1
		}
		ADR.context((String)contextNames.toArray()[1]);
	}
	public static void Appiuminitialization() {
//		AppiumServiceBuilder serviceBuilder = new AppiumServiceBuilder();
		DC = new DesiredCapabilities();
		DC.setCapability(CapabilityType.PLATFORM_NAME,prop.getProperty("platformName"));
		DC.setCapability(MobileCapabilityType.PLATFORM_VERSION,prop.getProperty("platformVersion"));
		DC.setCapability(MobileCapabilityType.DEVICE_NAME, prop.getProperty("deviceName"));
		DC.setCapability(MobileCapabilityType.NO_RESET,prop.getProperty("noReset"));
		DC.setCapability("newCommandTimeout", 6000);
//		DC.setCapability("app", prop.getProperty("applicationpath1")); 
		DC.setCapability(IOSMobileCapabilityType.BUNDLE_ID, "com.salido.ios.v2.staging.PointOfSale");
		DC.setCapability("automationName",prop.getProperty("automationName1"));
		DC.setCapability("udid",prop.getProperty("simUdid"));
		DC.setCapability("toggleSoftwareKeyboard", true);
		DC.setCapability("useNewWDA", false);
		DC.setCapability("usePrebuiltWDA", true);
//		DC.setCapability("agentPath", prop.getProperty("agentPath"));
//		DC.setCapability("bootstrapPath", prop.getProperty("bootstrapPath"));
		try {
			ADR = new IOSDriver<WebElement>(new URL(prop.getProperty("url")),DC);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		HashMap<String, String> environment = new HashMap();
//		environment.put("PATH", "/usr/local/bin:"+System.getenv("PATH"));
//		serviceBuilder = new AppiumServiceBuilder().usingDriverExecutable(new File("/usr/local/bin/node")).withAppiumJS(new File("/usr/local/lib/node_modules/appium/build/lib/main.js")).usingAnyFreePort();
//		serviceBuilder.withEnvironment(environment);
//		server = AppiumDriverLocalService.buildService(serviceBuilder);
//		server.stop();
//		server.start();
//		ADR = new IOSDriver<WebElement>(server.getUrl(),DC);
		ADR.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	protected static AppiumDriverLocalService serviceBuilder;
	public static void Appiuminitialization(String wda,String udid,String deviceName,String port) {
		
		serviceBuilder = new AppiumServiceBuilder().usingPort(Integer.valueOf(port)).build();
//		serviceBuilder.stop();
		serviceBuilder.start();
		if(serviceBuilder == null || serviceBuilder.isRunning()) {
			throw new AppiumServerHasNotBeenStartedLocallyException("Appium Server node is not started");
		}
		
		DC = new DesiredCapabilities();
		DC.setCapability(CapabilityType.PLATFORM_NAME,prop.getProperty("platformName"));
		DC.setCapability(MobileCapabilityType.PLATFORM_VERSION,prop.getProperty("platformVersion"));
		DC.setCapability(MobileCapabilityType.DEVICE_NAME, deviceName);
		DC.setCapability(MobileCapabilityType.NO_RESET,prop.getProperty("noReset"));
		DC.setCapability("newCommandTimeout", 6000);
//		DC.setCapability("app", prop.getProperty("applicationpath1")); 
		DC.setCapability(IOSMobileCapabilityType.BUNDLE_ID, "com.salido.ios.v2.staging.PointOfSale");
		DC.setCapability("automationName",prop.getProperty("automationName1"));
		DC.setCapability("udid",udid);
		DC.setCapability(IOSMobileCapabilityType.WDA_LOCAL_PORT, wda);
		DC.setCapability("toggleSoftwareKeyboard", true);
		DC.setCapability("useNewWDA", false);
		DC.setCapability("usePrebuiltWDA", true);
		DC.setCapability("agentPath", prop.getProperty("agentPath"));
		DC.setCapability("bootstrapPath", prop.getProperty("bootstrapPath"));
		ADR = new IOSDriver<WebElement>(serviceBuilder.getUrl(),DC);
		ADR.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
} 