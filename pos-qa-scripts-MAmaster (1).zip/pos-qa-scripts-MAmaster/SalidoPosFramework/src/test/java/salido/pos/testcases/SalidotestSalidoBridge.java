package salido.pos.testcases;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import io.appium.java_client.ios.IOSDriver;
import salido.pos.base.PosBaseClass;
import salido.pos.logger.Logger;
import salido.pos.page.PosDashBoardPage;
import salido.pos.page.SalidoBridgePage;
import salido.pos.utils.PosUtilClass;


public class SalidotestSalidoBridge extends PosBaseClass{

	PosUtilClass posUtils=new PosUtilClass();
	public SalidotestSalidoBridge() throws IOException {
		super();
		
	}

	@Test (enabled =true,priority=101)
	public void bridge_01_02_03_04() throws IOException {
		PosDashBoardPage DBPage=new PosDashBoardPage((IOSDriver<WebElement>) ADR);
		DBPage.clickOnDashBoard();
		DBPage.displaySalidoBridge();
		SalidoBridgePage sbPage=new SalidoBridgePage();
		sbPage.clickOnSalidoBridge();
		// LogOut
		sbPage.clickOnChecks();
		sbPage.clickOnClose();
		Dimension windowSize = ADR.manage().window().getSize();
		Logger.info(windowSize);
		posUtils.tapByCoordinates(windowSize.getWidth()-30, 30); 
		posUtils.waitForSec(5);
		WebElement logout = ADR.findElement(By.xpath("//XCUIElementTypeStaticText[@name=\"Logout\"]"));
		org.openqa.selenium.Point logOutPoint = logout.getLocation();
		posUtils.tapByCoordinates(logOutPoint.getX()+5, logOutPoint.getY()); // 1010, 133
		sbPage.verifySignOut();
		// Login
		sbPage.login("govindarao.x@mphasis.com", "Super6");
		sbPage.exitSalidoBridge();
		DBPage.clickFloor();
	}

}
