package salido.pos.page;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;
import salido.pos.base.PosBaseClass;
import salido.pos.logger.Logger;
import salido.pos.utils.PosUtilClass;

public class SalidoBridgePage extends PosBaseClass{
	
	PosUtilClass posUtils=new PosUtilClass();
	public SalidoBridgePage() throws IOException {
		super();
		PageFactory.initElements(new AppiumFieldDecorator(ADR), this);
	}

	@iOSFindBy(id="Checks")
	private WebElement checks;
	@iOSFindBy(id="CLOSE")
	private WebElement close;
	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"SALIDO Bridge\"]")
	private WebElement salidoBridge;
	@iOSFindBy(xpath="//XCUIElementTypeButton[@name=\"Exit\"]")
	private WebElement exitSalidoBridge;
	@iOSFindBy(xpath="//XCUIElementTypeTextField")
	private WebElement emailTextField;
	@iOSFindBy(xpath="//XCUIElementTypeSecureTextField")
	private WebElement passwordTextField;
	@iOSFindBy(id="sign in")
	private WebElement signIn;
	@iOSFindBy(xpath="//XCUIElementTypeOther[@name=\"banner\"]/XCUIElementTypeOther[1]/XCUIElementTypeOther[4]/descendant::XCUIElementTypeLink[1]")
	private WebElement userInfo;
	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"Logout\"]")
	private WebElement logout;
	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"You successfully signed out.\"]")
	private WebElement signedOutSuccess;
	@iOSFindBy(id="Next")
	private WebElement next;
	public void clickOnSalidoBridge() {
		posUtils.waitUntilElementDisplayed(salidoBridge);
		salidoBridge.click();
		Logger.info("Clicked on SalidoBridge");
	}
	
	public void clickOnChecks() {
		posUtils.waitUntilElementDisplayed(checks);
		checks.click();
		Logger.info("Clicked on Checks");
	}
	
	public void clickOnClose() {
		posUtils.waitUntilElementDisplayed(close);
		close.click();
		Logger.info("Clicked on CLOSE");
	}
	
	public void verifySignOut() {
		if(signedOutSuccess.isDisplayed())
			Logger.info("User Signed Out Successfully");
		else
			Logger.info("User is not Signed Out");
	}
	
	public void exitSalidoBridge() {
		exitSalidoBridge.click();
		Logger.info("Clicked on EXIT");
	}
	
	public void login(String email,String password) {
		posUtils.waitUntilElementDisplayed(emailTextField);
		emailTextField.sendKeys(email+"\t");
		passwordTextField.sendKeys(password,Keys.ENTER);
		posUtils.waitUntilElementDisplayed(checks);
	}
	
}
