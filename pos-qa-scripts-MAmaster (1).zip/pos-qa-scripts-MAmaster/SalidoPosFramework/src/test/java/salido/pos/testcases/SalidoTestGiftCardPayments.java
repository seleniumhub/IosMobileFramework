package salido.pos.testcases;

import java.io.IOException;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.appium.java_client.ios.IOSDriver;
import salido.pos.base.PosBaseClass;
import salido.pos.dataProvider.DataProviderClass;
import salido.pos.logger.Logger;
import salido.pos.page.POSPaymentPage;
import salido.pos.page.PosChecksPage;
import salido.pos.page.PosDashBoardPage;
import salido.pos.page.PosGiftCardPage;
import salido.pos.page.PosLoginPage;
import salido.pos.page.PosNewChkPage;
import salido.pos.utils.PosUtilClass;

public class SalidoTestGiftCardPayments extends PosBaseClass{

	PosUtilClass posUtils=new PosUtilClass();
	public SalidoTestGiftCardPayments() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}

	@BeforeClass
	public void launchSalidoApp() throws IOException {
//		Appiuminitialization();
		ADR.launchApp();
		PosLoginPage loginPage=new PosLoginPage((IOSDriver<WebElement>)ADR);
		loginPage.unlock();
	}
	
	@Test (priority=61,enabled=true,dataProvider = "GiftCard", dataProviderClass = DataProviderClass.class)
	public void GCPayEditExisting_TC_68(String gcnum) throws IOException {
		PosDashBoardPage DBPage=new PosDashBoardPage((IOSDriver<WebElement>) ADR);
		PosNewChkPage NChkPage=new PosNewChkPage((IOSDriver<WebElement>) ADR);
		PosGiftCardPage gfPage= new PosGiftCardPage((IOSDriver<WebElement>)ADR);
		POSPaymentPage PCPage=new POSPaymentPage((IOSDriver<WebElement>) ADR);
		PosChecksPage PChPage=new PosChecksPage((IOSDriver<WebElement>) ADR);
		String checkNo="";
		try {
			DBPage.clickOnDashBoard();
			DBPage.clickOnGiftCard();
			posUtils.enterNumber(gcnum);
			gfPage.clickOnLookUP();
			gfPage.preserveGiftCardAmount();
			gfPage.clickOnGCBackButton();
			DBPage.clickFloor();
			checkNo=NChkPage.CreateCheck();
			String chkTotal=NChkPage.checkTotal();
			NChkPage.clickOnPay();
			NChkPage.clickOnOtherPayments();
			gfPage.selectGiftCardPayment();
			posUtils.enterNumber(gcnum);
			gfPage.clickOnADDbutton();
			if(gfPage.check4AUTH()) {
				gfPage.clickOnAuth();
			}
			PCPage.editPayment((float)12.00, (float)0.12);
			gfPage.ChargeAmount();
			DBPage.clickOnDashBoard();
			DBPage.clickOnDashBoard();
			DBPage.clickOnGiftCard();
			posUtils.enterNumber(gcnum);
			gfPage.clickOnLookUP();
			gfPage.verifyGiftCardAmountAdded((float) -12.12);
			gfPage.preserveGiftCardAmount();
			gfPage.clickOnGCBackButton();
		}finally {
			try {
				DBPage.checkChecksMenu();
				String chkstate = PChPage.searchAndOpenCheck(checkNo);
				if(chkstate.equalsIgnoreCase("closed"))
					PChPage.reOpenCheck();
				PCPage.clickOnPay();
				PCPage.refundGiftCard();
				Logger.info("Refunding the GiftCard test case is covered here");
				PCPage.checkVoid("Test");
				Logger.info("Voiding check test case is covered here");
				PCPage.back2Checks();
				DBPage.clickOnDashBoard();
				DBPage.clickOnGiftCard();
				posUtils.enterNumber(gcnum);
				gfPage.clickOnLookUP();
				gfPage.verifyGiftCardAmountAdded((float) 12.12);
				gfPage.clickOnGCBackButton();
			} catch(NoSuchElementException e) {
				Logger.info("Check# "+checkNo+" not voided. Please void manually");
				try {
					DBPage.clickOnDashBoard();
				} catch(NoSuchElementException e1) {
					Logger.info("DashBoardIcon is not displayed");
				}
			}
			DBPage.clickFloor();
		}
	
	}
	
	
	@Test (priority=61,enabled=true,dataProvider = "GiftCard", dataProviderClass = DataProviderClass.class)
	public void GCPaySplit_TC_16(String gcnum) throws IOException {
		PosDashBoardPage DBPage=new PosDashBoardPage((IOSDriver<WebElement>) ADR);
		PosNewChkPage NChkPage=new PosNewChkPage((IOSDriver<WebElement>) ADR);
		PosGiftCardPage gfPage= new PosGiftCardPage((IOSDriver<WebElement>)ADR);
		POSPaymentPage PCPage=new POSPaymentPage((IOSDriver<WebElement>) ADR);
		PosChecksPage PChPage=new PosChecksPage((IOSDriver<WebElement>) ADR);
		String checkNo="";
		float totalBill=(float)0.0;
		try {
			DBPage.clickOnDashBoard();
			DBPage.clickOnGiftCard();
			posUtils.enterNumber(gcnum);
			gfPage.clickOnLookUP();
			gfPage.preserveGiftCardAmount();
			gfPage.clickOnGCBackButton();
			DBPage.clickFloor();
			checkNo=NChkPage.CreateCheck();
			String chkTotal=NChkPage.checkTotal();
			NChkPage.clickOnPay();
			NChkPage.clickOnOtherPayments();
			gfPage.selectGiftCardPayment();
			posUtils.enterNumber(gcnum);
			gfPage.clickOnADDbutton();
			totalBill=PCPage.toatlBill();
			String []spltbil=PCPage.splitbill(totalBill);
			gfPage.editAmountb4Auth(spltbil[0]);
			PCPage.updatePayment();
			if(gfPage.check4AUTH()) {
				gfPage.clickOnAuth();
			}
			NChkPage.clickOnOtherPayments();
			gfPage.selectGiftCardPayment();
			posUtils.enterNumber(gcnum);
			gfPage.clickOnADDbutton();
			gfPage.gcAmnt2Redeem(spltbil[1]);
			gfPage.clickOnAuth();
			DBPage.clickOnDashBoard();
			DBPage.clickOnDashBoard();
			DBPage.clickOnGiftCard();
			posUtils.enterNumber(gcnum);
			gfPage.clickOnLookUP();
			gfPage.verifyGiftCardAmountAdded((float) -totalBill);
			gfPage.preserveGiftCardAmount();
			gfPage.clickOnGCBackButton();
		}finally {
			try {
				DBPage.checkChecksMenu();
				String chkstate = PChPage.searchAndOpenCheck(checkNo);
				if(chkstate.equalsIgnoreCase("closed"))
					PChPage.reOpenCheck();
				PCPage.clickOnPay();
				PCPage.refundGiftCard();
				Logger.info("Refunding the GiftCard test case is covered here");
				PCPage.checkVoid("Test");
				Logger.info("Voiding check test case is covered here");
				PCPage.back2Checks();
				DBPage.clickOnDashBoard();
				DBPage.clickOnGiftCard();
				posUtils.enterNumber(gcnum);
				gfPage.clickOnLookUP();
				gfPage.verifyGiftCardAmountAdded((float) totalBill);
				gfPage.clickOnGCBackButton();
			} catch(NoSuchElementException e) {
				Logger.info("Check# "+checkNo+" not voided. Please void manually");
				try {
					DBPage.clickOnDashBoard();
				} catch(NoSuchElementException e1) {
					Logger.info("DashBoardIcon is not displayed");
				}
			}
			DBPage.clickFloor();
		}
	
	}
	
}
