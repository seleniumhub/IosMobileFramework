package salido.pos.page;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import salido.pos.logger.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import io.appium.java_client.MobileElement;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;
import salido.pos.base.PosBaseClass;
import salido.pos.utils.PosUtilClass;

public class PosChecksPage extends PosBaseClass {

	PosUtilClass posUtils=new PosUtilClass();
//	static Logger Logger = Logger.getLogger(PosChecksPage.class);
	public PosChecksPage(IOSDriver<WebElement> driver) throws IOException {
		super();
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@iOSFindBy(id="SEARCH CHECKS")
	private WebElement searchCheck;
	
	@iOSFindBy(id="Search today's checks by guest name or check number")
	private WebElement enterCheckNo;
	
	private String Requiredcheck = "(//XCUIElementTypeStaticText[@name=\"xxxx\"])[last()]";
	
	private String checkstatus = "(//XCUIElementTypeStaticText[@name=\"xxxx\"])[last()]/following-sibling::XCUIElementTypeStaticText[1]";
	private String imageX_statictext="//XCUIElementTypeImage[@name=\"xxxx\"]//following-sibling::XCUIElementTypeStaticText";

	private WebElement webElementWithDynamicXpath (String xpathValue, String oldstring, String substitutionValue ) {
	        return ADR.findElement(By.xpath(xpathValue.replace(oldstring, substitutionValue)));
	}

	public String searchAndOpenCheck(String checkNo) {
		searchCheck.click();
		enterCheckNo.click();
		enterCheckNo.clear();
		enterCheckNo.sendKeys(checkNo);
		posUtils.waitUntilElementDisplayed(webElementWithDynamicXpath(Requiredcheck,"xxxx",checkNo));
		String chkstate=webElementWithDynamicXpath(checkstatus,"xxxx",checkNo).getAttribute("value");
//		String guestName="Guest "+checkNo;
		webElementWithDynamicXpath(Requiredcheck,"xxxx",checkNo).click();
		return chkstate;
	}
	
	@iOSFindBy(id="Close")
	private WebElement close;

	@iOSFindBy(accessibility="REOPEN CHECK")
	private WebElement reopencheck;
	
	public void reOpenCheck() {
		reopencheck.click();
	}
	
	@iOSFindBy(accessibility="iconFloorPlanActive")
	private WebElement floorplan;
	
	@iOSFindBy(accessibility="iconAllChecks")
	private WebElement allChksIcon;
	
	public void clickOnFloorPlan() {
		try {
			if(floorplan.isDisplayed()) {
				Logger.info("Floor Plan Icon is displayed");
				floorplan.click();
				posUtils.waitUntilElementDisplayed(allChksIcon);
			}
		}
		catch(NoSuchElementException e) {
			e.printStackTrace();
		}
	}
	
	public void clickOnAllChecksIcon() {
		allChksIcon.click();
	}
	
	@iOSFindBy(xpath="//XCUIElementTypeImage[@name=\"iconServerActive\"]/..")
	private WebElement employee;
	
	public void employee() {
		if(employee.isDisplayed()) {
			String empName=webElementWithDynamicXpath(imageX_statictext,"xxxx","iconServerActive").getAttribute("value");
			Logger.info("Currently showing the details of Employee: "+empName);
		}
	}
	private String selectEmp="//XCUIElementTypeStaticText[@name=\"All Employees\"]/parent::XCUIElementTypeCell/following::XCUIElementTypeCell/XCUIElementTypeStaticText[contains(@name,'xxxx')]";
	
	@iOSFindBy(id="EMPLOYEES")
	private WebElement empMenu;
	
	private String emplist1 = "//XCUIElementTypeButton[@name=\"Close\"]/following-sibling::XCUIElementTypeCollectionView/XCUIElementTypeCell[";
	private String emplist2 = "]/XCUIElementTypeStaticText";
	@iOSFindBy(xpath="//XCUIElementTypeButton[@name=\"Close\"]/following-sibling::XCUIElementTypeCollectionView/XCUIElementTypeCell")
	private List<WebElement> noOfIcons;

	private WebElement webElementWithDynamicIndexXpath (String subStr1, int val, String subStr2 ) {
        return ADR.findElement(By.xpath(subStr1+val+subStr2));
	}

	public void buttonList() {
		int iconCnt=noOfIcons.size();
		for(int cnt=1;cnt<=iconCnt;cnt++) {
			String iConValue=webElementWithDynamicIndexXpath(emplist1,cnt,emplist2).getAttribute("value");
			Logger.info("Button "+cnt+" has the value: "+iConValue);
		}
	}
	public String selectEmployee(String slctEmpName) {
		employee.click();
		posUtils.waitUntilElementDisplayed(empMenu);
		buttonList();
		String empName=webElementWithDynamicXpath(selectEmp,"xxxx",slctEmpName).getAttribute("value");
		Logger.info("You are selecting Employee: "+empName);
		webElementWithDynamicXpath(selectEmp,"xxxx",slctEmpName).click();
		return empName;
	}
	@iOSFindBy(xpath="//XCUIElementTypeOther[@name=\"LABEL / GUEST\"]/following-sibling::XCUIElementTypeCell")
	private List<WebElement> noOfChecks;
	private String checkOwner1="//XCUIElementTypeOther[@name=\"LABEL / GUEST\"]/following-sibling::XCUIElementTypeCell[";
	private String checkOwner2="]/XCUIElementTypeStaticText[contains(@name,'$')]/preceding::XCUIElementTypeStaticText[1]";
	
	public boolean employeeChecks(String empName) {
		int checkslNo=noOfChecks.size();
		Logger.info("Total number of checks of available are: "+checkslNo);
		boolean SingleOwner=true;
		for(int slNo=1;slNo<=checkslNo;slNo++) {
			String chkOwnr=webElementWithDynamicIndexXpath(checkOwner1,slNo,checkOwner2).getAttribute("value");
			if(empName.equalsIgnoreCase(chkOwnr)) {
				Logger.info("Check "+slNo+" belongs to "+chkOwnr);
			}
			else {
				Logger.info("Employee selected is: " +empName+" but found the check of another employee: "+chkOwnr);
				SingleOwner=false;
				return SingleOwner;
			}
		}
		if(SingleOwner) {
			Logger.info("All Checks are belongs to employee:"+empName);
		}
		return SingleOwner;
	}
	@iOSFindBy(xpath="//XCUIElementTypeStaticText[contains(@name,'All')]")
	private WebElement selectAll;
	public void selectEmployeeAll() {
		employee.click();
		posUtils.waitUntilElementDisplayed(empMenu);
		Logger.info("Selecting All Employees Option.");
		selectAll.click();
	}
	@iOSFindBy(xpath="//XCUIElementTypeImage[@name=\"orderTypeIcon\"]/..")
	private WebElement orderType;
	@iOSFindBy(id="ORDER TYPES")
	private WebElement orderMenu;
	public void clickOnOrderType() {
		orderType.click();
		posUtils.waitUntilElementDisplayed(orderMenu);
	}
	private String selectorderType="//XCUIElementTypeStaticText[@name=\"All\"]/parent::XCUIElementTypeCell/following::XCUIElementTypeCell/XCUIElementTypeStaticText[contains(@name,'xxxx')]";
	public String selectOrderType(String str) {
		buttonList();
		String slctdorderType=webElementWithDynamicXpath(selectorderType,"xxxx",str).getAttribute("value");
		Logger.info("You are selecting OrderType: "+slctdorderType);
		webElementWithDynamicXpath(selectorderType,"xxxx",str).click();
		return slctdorderType;
	}
	private String OrderType2="]/XCUIElementTypeStaticText[contains(@name,'$')]/preceding::XCUIElementTypeStaticText[2]";	
	public boolean verifyOrderTypeChecks(String str) {
		int checkslNo=noOfChecks.size();
		Logger.info("Total number of checks of available are: "+checkslNo);
		boolean SingleType=true;
		for(int slNo=1;slNo<=checkslNo;slNo++) {
			String chkodrTp=webElementWithDynamicIndexXpath(checkOwner1,slNo,OrderType2).getAttribute("value");
			if(str.equalsIgnoreCase(chkodrTp)) {
				Logger.info("Check "+slNo+" belongs to "+chkodrTp);
			}
			else {
				Logger.info("OrderType selected is: " +str+" but found the check of another OrderType: "+chkodrTp);
				SingleType=false;
				return SingleType;
			}
		}
		if(SingleType) {
			Logger.info("All Checks are belongs to OrderType:"+str);
		}
		return SingleType;
	}
	public void selectOrderTypeAll() {
		orderType.click();
		posUtils.waitUntilElementDisplayed(orderMenu);
		Logger.info("Selecting All OrderTypes.");
		selectAll.click();
	}
	@iOSFindBy(xpath="//XCUIElementTypeImage[@name=\"iconCheckStatus\"]/..")
	private WebElement checkStatus;
	@iOSFindBy(id="CHECK STATUS")
	private WebElement chkOdrMenu;
	public void clickOnStatusType() {
		checkStatus.click();
		posUtils.waitUntilElementDisplayed(chkOdrMenu);
	}
	private String selectStausType="//XCUIElementTypeButton[@name=\"Close\"]/following-sibling::XCUIElementTypeCollectionView/descendant::XCUIElementTypeCell/XCUIElementTypeStaticText[contains(@name,'xxxx')]";
	public String selectChkStatusType(String str) {
		WebElement chkStatusTypele=webElementWithDynamicXpath(selectStausType,"xxxx",str);
		String slctStatusType=chkStatusTypele.getAttribute("value");
		Logger.info("You are selecting Status Type: "+slctStatusType);
		chkStatusTypele.click();
		int checkslNo=noOfChecks.size();
		Logger.info("Total number of checks of available are: "+checkslNo);
		return slctStatusType;
	}
	
	public void selectChkStatusTypeOpen() {
		clickOnStatusType();
		webElementWithDynamicXpath(selectStausType,"xxxx","Open").click();
	}
	private String staticTextxpath = "//XCUIElementTypeStaticText[contains(@name,'Guest xxxx')]";
	
	@iOSFindBy(id="REVENUE CENTER")
	private WebElement revenueCenterMenu;
	
	@iOSFindBy(xpath="//XCUIElementTypeButton[@name=\"iconFloorPlanActive\"]/../preceding::XCUIElementTypeButton")
	private WebElement curntRevenueCenter;
	
	public void listRevenueCenters() {
		curntRevenueCenter.click();
		posUtils.waitUntilElementDisplayed(revenueCenterMenu);
		buttonList();
		close.click();
	}
	
	public String selectRevenueCenter(String revenueCenterpartName) {
		Logger.info("Now currently showing the Revenue center: "+curntRevenueCenter.getAttribute("name"));
		curntRevenueCenter.click();
		posUtils.waitUntilElementDisplayed(revenueCenterMenu);
		WebElement revenueCenter= webElementWithDynamicXpath(staticTextxpath,"Guest xxxx",revenueCenterpartName);
		String revenueCenterName=revenueCenter.getAttribute("value");
		revenueCenter.click();
		Logger.info("Revenue Center "+revenueCenterName+" is Selected");
//		Logger.info("Now currently showing the Revenue center: "+curntRevenueCenter.getAttribute("name"));
		Assert.assertEquals(revenueCenterName, curntRevenueCenter.getAttribute("name"));
		Logger.info("Selected Revenue is matching with Shown revenue");
		return revenueCenterName;
	}
	
	public void verifyRCChecks(String revenueCenterName) {
		if(revenueCenterName.equalsIgnoreCase(curntRevenueCenter.getAttribute("name"))) {
			int checkslNo=noOfChecks.size();
			Logger.info("Total number of checks of available are: "+checkslNo);
		}
		else {
			Logger.info("Selected Revenue Center is not matching with Currently showing Revenue Center");
		}
	}
	
	private String checkNo1="//XCUIElementTypeTable/descendant::XCUIElementTypeCell[";
	private String checkNo2="]/XCUIElementTypeStaticText[contains(@name,'h ')][1]/preceding::XCUIElementTypeStaticText[1]";
	
	@iOSFindBy(accessibility="addCheckFAB")
	private WebElement newCheck;
	
	public void clickOncreateNewCheck() {
		posUtils.waitUntilElementDisplayed(newCheck);
		newCheck.click();
		Logger.info("Creating New check");
	} 
	
	@iOSFindBy(id="BackButton")
	private WebElement backbutton;

	public void clickOnBackButton(){
		backbutton.click();
	}
	


}
