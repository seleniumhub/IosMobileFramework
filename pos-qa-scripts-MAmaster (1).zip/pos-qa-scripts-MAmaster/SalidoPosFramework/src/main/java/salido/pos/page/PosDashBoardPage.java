package salido.pos.page;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;
import salido.pos.base.PosBaseClass;
import salido.pos.logger.Logger;
import salido.pos.utils.PosUtilClass;

public class PosDashBoardPage extends PosBaseClass{
	PosUtilClass posUtils=new PosUtilClass();
	public PosDashBoardPage(IOSDriver<WebElement> driver) throws IOException {
		super();
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	@iOSFindBy(id="DashboardButtonNormal")
	private WebElement dashboardMenu;

	@iOSFindBy(accessibility="Floor Plan")
	private WebElement floorMenu;

	@iOSFindBy(accessibility="Floor View")
	private WebElement floorView;

	@iOSFindBy(accessibility="Checks")
	private WebElement clickChecks;

	@iOSFindBy(accessibility="Gift Cards")
	private WebElement giftCardIcon;

	@iOSFindBy(accessibility="SEARCH CHECKS")
	private WebElement searchChecks;

	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"Manage Bank\"]")
	private WebElement manageBank;

	@iOSFindBy(xpath="//XCUIElementTypeStaticText[contains(@name,'Bank: $')]")
	private WebElement bankAmt;

	@iOSFindBy(xpath="//XCUIElementTypeButton[contains(@name,'Bank')]")
	private WebElement openrcloseBank;

	@iOSFindBy(xpath="//XCUIElementTypeButton[@name=\"Pay In\"]")
	private WebElement payin;

	@iOSFindBy(accessibility="Guests")
	private WebElement guests;

	@iOSFindBy(xpath="//XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeButton")
	private WebElement NewGuest;

	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"Status & Reports\"]")
	private WebElement statusnReports;

	@iOSFindBy(accessibility="Daily Summary")
	private WebElement statusnreportsDailySummary;

	@iOSFindBy(accessibility="Settings")
	private WebElement iconSettings;

	@iOSFindBy(accessibility="Prep Profiles")
	private WebElement prepProfile;

	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"SALIDO Bridge\"]")
	private WebElement salidoBridge;

	@iOSFindBy(xpath="//XCUIElementTypeButton[@name=\"Exit\"]")
	private WebElement exitsalidoBridge;

	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"Manage Menu\"]")
	private WebElement manageMenu;

	@iOSFindBy(accessibility="Select an Item")
	private WebElement selectItem;

	@iOSFindBy(xpath="//XCUIElementTypeButton[@name=\"Support\"]")
	private WebElement support;

	@iOSFindBy(accessibility="Pop Drawer")
	private WebElement popdrawer;

	@iOSFindBy(accessibility="Shift Report")
	private WebElement shiftReport;

	@iOSFindBy(accessibility="Take Break")
	private WebElement takeBreak;

	@iOSFindBy(accessibility="Clock Out")
	private WebElement clockOut;

	@iOSFindBy(accessibility="LockScreenButtonNormal")
	private WebElement lockuser;

	public void clickOnDashBoard() {
		posUtils.waitUntilElementDisplayed(dashboardMenu);
		ADR.findElementByXPath("//XCUIElementTypeButton[@name=\"DashboardButtonNormal\"]").click();
	}

	public void displayChecks() {
		if(clickChecks.isDisplayed())
			Logger.info("Checks Menu is displayed");
	}

	public void displayBank() {
		if(manageBank.isDisplayed())
			Logger.info("Manage Bank Menu is displayed");
	}
	public void clickOnBank() {
		manageBank.click();
	}
	public void displayFloor() {
		if(floorMenu.isDisplayed())
			Logger.info("Floor Menu is displayed");
	}

	public void displayGuest() {
		if(guests.isDisplayed())
			Logger.info("Guests is displayed");
	}

	public void displayStatusnReport() {
		if(statusnReports.isDisplayed())
			Logger.info("Status & Reports is displayed");
	}

	public void displaySettings() {
		if(iconSettings.isDisplayed())
			Logger.info("Settings is displayed");
	}

	public void displaySalidoBridge() {
		if(salidoBridge.isDisplayed())
			Logger.info("Salido Bridge is displayed");
	}

	public void displayManageMenu() {
		if(manageMenu.isDisplayed())
			Logger.info("Manage Menu is displayed");
	}

	public void displayGiftCard() {
		if(giftCardIcon.isDisplayed())
			Logger.info("Gift Card is displayed");
	}

	public void clickFloor() {
		posUtils.waitUntilElementDisplayed(floorMenu, 10);
		floorMenu.click();
	}

	public void checkFloor() {
		clickFloor();
		if(floorView.isDisplayed())
			Logger.info("Floor Menu is working");
	}
	
	public void checkChecksMenu() {
		posUtils.waitUntilElementDisplayed(clickChecks,10);
		clickChecks.click();
		if(searchChecks.isDisplayed())
			Logger.info("Check Button is working in DashBoard");
	}
	public String checkMangeBank() {
		manageBank.click();
		if(openrcloseBank.isDisplayed() )
			Logger.info("Manage Bank is working in DashBoard");
		String bank=openrcloseBank.getAttribute("name");
		try {
			if(bank.contains("pen"))
				Logger.info("Bank is not yet opened. Please Open the Bank for Payment.");
		}
		catch(NullPointerException e) {
			e.printStackTrace();
			if(bank.contains("lose")) {
				Logger.info("Bank is already opened. You are eligibel for payment by cash method.");
				Logger.info(bankAmt.getText());
			}
		}
		return bank;
	}
	public void checkGuests() {
		guests.click();
		if(NewGuest.isDisplayed() )
			Logger.info("Guests is working in DashBoard");
	}
	public void checkStatusnReports() {
		statusnReports.click();
		if(statusnreportsDailySummary.isDisplayed())
			Logger.info("Status&Report is working in DashBoard");
	}
	public void checkSettings() {
		iconSettings.click();
		if(prepProfile.isDisplayed())
			Logger.info("Settings is working in DashBoard");
	}
	public void checkSalidoBridge() {
		salidoBridge.click();
		posUtils.waitUntilElementDisplayed(exitsalidoBridge);
		if(exitsalidoBridge.isDisplayed()) {
			exitsalidoBridge.click();
			Logger.info("Salido Bridge is working in DashBoard");
		}
	}
	public void checkManageMenu() {
		manageMenu.click();
		if(selectItem.isDisplayed())
			Logger.info("Manage Menu is working in DashBoard");
	}

	@iOSFindBy(id="backIconBlack")
	private WebElement gcBackButton;

	public void clickOnGiftCard() throws IOException {
		posUtils.waitUntilElementDisplayed(giftCardIcon,25);
		giftCardIcon.click();
	}
	public void clickOnGCbackButton() {
		gcBackButton.click();
	}
	public void checkGiftCard() throws IOException {
		clickOnGiftCard();
		if(gcBackButton.isDisplayed())
			Logger.info("GiftCard is working in DashBoard");
		clickOnGCbackButton();
	}
	public void displayLockUser() {
		if(lockuser.isDisplayed())
		{
			Logger.info("Lock screen is displayed");
		}
	}
	public void displaySupport() {
		if(support.isDisplayed())
		{
			Logger.info("Support Icon is displayed");
		}
	}
	public void displayPopDrawer() {
		if(popdrawer.isDisplayed())
		{
			Logger.info("Pop Drawer Icon is displayed");
		}
	}
	public void displayShiftReport() {
		if(shiftReport.isDisplayed())
		{
			Logger.info("Shift Drawer Icon is displayed");
		}
	}
	public void displayTakeBreak() {
		if(takeBreak.isDisplayed())
		{
			Logger.info("Take Break Icon is displayed");
		}
	}
	public void displayClockOut() {
		if(clockOut.isDisplayed())
		{
			Logger.info("Clock Out Icon is displayed");
		}
	}
}
