package salido.pos.testcases;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import io.appium.java_client.ios.IOSDriver;
import salido.pos.base.PosBaseClass;
import salido.pos.page.PosDashBoardPage;

public class SalidoTestPosMenu extends PosBaseClass{

	public SalidoTestPosMenu() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}
	@Test(enabled=true, priority=2)//, dependsOnGroups= {"login"}
	public static void displayPOSMenu_01() throws IOException {
		PosDashBoardPage DBPage=new PosDashBoardPage((IOSDriver<WebElement>) ADR);
		DBPage.clickOnDashBoard();
		
		DBPage.displayFloor();
		DBPage.displayChecks();
		DBPage.displayBank();

		DBPage.displayGuest();
		DBPage.displayStatusnReport();
		DBPage.displaySettings();
		
		DBPage.displaySalidoBridge();
		DBPage.displayManageMenu();
		DBPage.displayGiftCard();
		
		DBPage.clickFloor();
	}
	
	@Test(enabled=true, priority=5)
	public static void checkDashBoard_02() throws IOException, InterruptedException {
		PosDashBoardPage DBPage=new PosDashBoardPage((IOSDriver<WebElement>) ADR);
		//fllorPlan
		DBPage.clickOnDashBoard();
		DBPage.checkFloor();
		// Check
		DBPage.clickOnDashBoard();
		DBPage.checkChecksMenu();
		//Manage Bank
		DBPage.clickOnDashBoard();
		DBPage.checkMangeBank();
		//Guest
		DBPage.clickOnDashBoard();
		DBPage.checkGuests();
		//Status and Reports
		DBPage.clickOnDashBoard();
		DBPage.checkStatusnReports();		
		//Settings
		DBPage.clickOnDashBoard();
		DBPage.checkSettings();
		//Salido Bridge
		DBPage.clickOnDashBoard();
		DBPage.checkSalidoBridge();
		//Manage menu
//		DBPage.clickOnDashBoard();
		DBPage.checkManageMenu();
		//GiftCards
		DBPage.clickOnDashBoard();
		DBPage.checkGiftCard();
	}
	
	@Test(enabled=true, priority=4)
	public static void checkHeader_03() throws IOException {
		PosDashBoardPage DBPage=new PosDashBoardPage((IOSDriver<WebElement>) ADR);
		DBPage.clickOnDashBoard();
		DBPage.displayLockUser();
		DBPage.clickFloor();
		System.out.println("Completed Header check of POS_Menu");
	}
	
	@Test(enabled=true, priority=3)
	public static void checkFooter_04() throws IOException {
		PosDashBoardPage DBPage=new PosDashBoardPage((IOSDriver<WebElement>) ADR);
		DBPage.clickOnDashBoard();
		DBPage.displaySupport();
		DBPage.displayPopDrawer();
		DBPage.displayShiftReport();
		DBPage.displayTakeBreak();
		DBPage.displayClockOut();
		DBPage.clickFloor();
		System.out.println("Completed Footer check of POS_Menu");
	}
}
