package salido.pos.page;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.MobileElement;

import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;
import salido.pos.base.PosBaseClass;
import salido.pos.logger.Logger;
import salido.pos.utils.PosUtilClass;

public class ManageMenuPage extends PosBaseClass {

	public ManageMenuPage(IOSDriver<WebElement> driver) throws IOException {
		super();
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	@iOSFindBy(accessibility="DashboardButtonNormal")
	private MobileElement dashboardMenu;

	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"Manage Menu\"]")
	private MobileElement manageMenu;

	@iOSFindBy(accessibility="Select an Item")
	private MobileElement selectItemText;

	@iOSFindBy(xpath="//XCUIElementTypeButton[@label=\"Breakfast\"]")
	private MobileElement clickSelectMenu1;

	@iOSFindBy(id="Breakfast")
	private MobileElement selectBreakfast;

	@iOSFindBy(accessibility="SELECT MENU")
	private MobileElement selectMenu;

	@iOSFindBy(id="Lunch")
	private MobileElement selectLunch;


	@iOSFindBy(id="Dinner")
	private MobileElement selectDinner;

	@iOSFindBy(accessibility="Close")
	private MobileElement closeSelectMenu;

	@iOSFindBy(accessibility="BEVERAGES")
	private MobileElement beverages;

	@iOSFindBy(accessibility="Italian Meatbal")
	private MobileElement italianMeatbal;
	
	@iOSFindBy(accessibility="Turkey Burger")
	private MobileElement turkeyBurger;
	
	@iOSFindBy(accessibility="Alcohol")
	private MobileElement alcohol;
	
	@iOSFindBy(accessibility="Small")
	private MobileElement small;

	@iOSFindBy(id="Medium ")
	private MobileElement medium;

	@iOSFindBy(accessibility="Large")
	private MobileElement large;

	@iOSFindBy(id="Red wine")
	private MobileElement redwine;
	
	@iOSFindBy(id="Veg Lasagne")
	private MobileElement vegLasagne;
	
	@iOSFindBy(accessibility="CANCEL")
	private MobileElement canceleditcount;
	
	PosUtilClass posUtils=new PosUtilClass();
	
	public void clickOnDashBoard() {
		posUtils.waitUntilElementDisplayed(dashboardMenu);
		Logger.info("Dashboard Menu button is displayed");
		ADR.findElementByXPath("//XCUIElementTypeButton[@name=\"DashboardButtonNormal\"]").click();
	}

	public void clickOnMangeMenu() {
		posUtils.waitUntilElementDisplayed(manageMenu,25);
		Logger.info("Manage Menu button is displayed");
		manageMenu.click();
		posUtils.waitUntilElementDisplayed(selectItemText,25);
		Logger.info("Select Item Text is displayed");
	}

	public void clickOnSelectMenu() {
		clickSelectMenu1.click();
		WebDriverWait wait=new WebDriverWait(ADR,30);
		wait.until(ExpectedConditions.visibilityOf(selectMenu));
		if(displaySelectMenu()) {
			displayBreakfast();
			displayLunch();
			displayDinner();
			closeSelectMenu();
		}
	}
	public boolean displaySelectMenu() {
		posUtils.waitUntilElementDisplayed(selectMenu, 10);
		if(selectMenu.isDisplayed()) {
			Logger.info("SelectMenu is Displayed");
			return true;
		}
		return false;
	}
	public void displayBreakfast() {
		if(selectBreakfast.isDisplayed()) {
			Logger.info("Breakfast is Displayed");
		}
	}
	public void selectBreakfast() {
		if(selectBreakfast.isDisplayed()) {
			selectBreakfast.click();
			Logger.info("Breakfast is Selected");
		}
	}
	public void displayLunch() {
		if(selectLunch.isDisplayed()) {
			Logger.info("Lunch is Displayed");
		}
	}
	public void selectLunch() {
		if(selectLunch.isDisplayed()) {
			selectLunch.click();
			Logger.info("Lunch is Selected");
		}
	}
	public void displayDinner() {
		if(selectDinner.isDisplayed()) {
			Logger.info("Dinner is Displayed");
		}
	}
	public void selectDinner() {
		if(selectDinner.isDisplayed()) {
			selectDinner.click();
			Logger.info("Dinner is Selected");
		}
	}
	public void closeSelectMenu() {
		closeSelectMenu.click();
	}
	public void check4Items() {
		clickOnBeverages();
		if(italianMeatbal.isDisplayed()) {
			italianMeatbal.click();
			displaySmall();
			displayMedium();
			displayLarge();
		}
		else {
			Logger.info("Italian Meatbal is not displayed");
		}
		small.click();
		posUtils.waitForSec(1);
		canceleditcount.click();
		posUtils.waitForSec(1);
		if(redwine.isDisplayed()) {
			Logger.info("Red Wine is displayed");
		}
	}
	
	public void clickOnBeverages() {
		beverages.click();
	}
	
	public String clickOnMeatbal() {
		italianMeatbal.click();
		return italianMeatbal.getAttribute("value");
	}
	
	public String clickOnBurger() {
		turkeyBurger.click();
		return turkeyBurger.getAttribute("value");
	}

	public String clickOnAlcohol() {
		alcohol.click();
		return alcohol.getAttribute("value");
	}
	
	public String selectVegLasagne() {
		vegLasagne.click();
		return vegLasagne.getAttribute("value");
	}
	
	public String selectRedWine() {
		redwine.click();
		return redwine.getAttribute("value");
	}
	
	public void displaySmall() {
		if(small.isDisplayed())
			Logger.info("Small is displayed");
	}
	
	public String selectSmall() {
		String str=small.getAttribute("name");
		small.click();
		Logger.info("Small is selected");
		return str;
	}
	
	public void displayMedium() {
		if(medium.isDisplayed())
			Logger.info("Medium is displayed");
	}
	
	public String selectMedium() {
		String str=medium.getAttribute("name");
		medium.click();
		Logger.info("Medium is Selected");
		return str;
	}
	
	public void displayLarge() {
		if(large.isDisplayed())
			Logger.info("Large is displayed");
	}
	
	public String selectLarge() {
		String str=large.getAttribute("name");
		large.click();
		Logger.info("Large is selected");
		return str;
	}
	
	@iOSFindBy(accessibility="86")
	private MobileElement none;

	@iOSFindBy(accessibility="∞")
	private MobileElement full;

	@iOSFindBy(xpath="//XCUIElementTypeTextField")
	private MobileElement editnum;

	@iOSFindBy(accessibility="SAVE")
	private MobileElement save;

	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"Italian Meatball Pizza Small\"]")
	private MobileElement smallPizza;

	@iOSFindBy(xpath="//XCUIElementTypeStaticText[contains(@label,'Pizza Small')]/following-sibling::XCUIElementTypeStaticText")
	private MobileElement count;

	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"Italian Meatball Pizza Large\"]")
	private MobileElement LargePizza;

	@iOSFindBy(xpath="//XCUIElementTypeStaticText[contains(@label,'Pizza Large')]/following-sibling::XCUIElementTypeStaticText")
	private MobileElement LPcount;
	
	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"Red wine Regular\"]")
	private MobileElement redwinereg;
	
	@iOSFindBy(xpath="//XCUIElementTypeStaticText[contains(@label,'wine Regular')]/following-sibling::XCUIElementTypeStaticText")
	private MobileElement RWRcount;
	
	@iOSFindBy(accessibility="Reset ALL Item Counts")
	private MobileElement resetallitemscount;
	
	@iOSFindBy(accessibility="Yes")
	private MobileElement confirmresetall;
	
	public void editItemsCount() {
		beverages.click();
		clickOnElements(italianMeatbal,small);
		//Italian Meatbal Pizza Small set count to 5 and verify
		editCountnCheck(5,smallPizza,count);
		//Italian Meatbal Pizza Large set count to 5 and verify
		clickOnElements(italianMeatbal,large);
		editCountnCheck(0,LargePizza,LPcount);
		//Italian Meatbal Pizza Large set count to infinity
		String element=LargePizza.getAttribute("value");
		LargePizza.click();
		full.click();
		save.click();
		try {
			if(LargePizza.isDisplayed()) {
				Logger.error(element+" is not set to infinity");
			}
		}
		catch(Exception e) {
			Logger.info(element+" is set to infinity");
			e.printStackTrace();
		}
		//Red Wine Regular set count to none
		clickOnElements(redwine,none);
		save.click();
	}
	
	public void clickOnElements(MobileElement elmnt1,MobileElement elmnt2)  {
		if(elmnt1.isDisplayed()) {
			elmnt1.click();
			posUtils.waitForSec(1);
			elmnt2.click();
		}
	}
	
	public void editCountnCheck(int cntval,MobileElement elmnt1,MobileElement elmnt2)  {
		String valstr= (new Integer(cntval)).toString();
		ADR.findElement(By.xpath(prop.getProperty(valstr))).click();
		save.click();
		WebDriverWait wait=new WebDriverWait(ADR,10);
		wait.until(ExpectedConditions.visibilityOf(elmnt1));
		String elmnt1val=elmnt1.getAttribute("value");
			Logger.info(elmnt1val +" count was edited");
		String valuecount = elmnt2.getAttribute("value");
		if(cntval==0) {
			if(valuecount.equalsIgnoreCase("86'ed"))
				Logger.info("Entered count is matchng with the shown count");
			else 
				Logger.info("Entered count is not matching with the entered value");
		}
		else {
			String[] strary = valuecount.split("\\s");
			if(cntval==Integer.parseInt(strary[0]))
				Logger.info("Entered count is matchng with the shown count");
			else 
				Logger.info("Entered count is not matching with the entered value");
		}
	}
	public void ResetAllItems() {
		if(redwinereg.isDisplayed()||smallPizza.isDisplayed()) {
			resetallitemscount.click();
			WebDriverWait wait= new WebDriverWait(ADR,60);
			wait.until(ExpectedConditions.visibilityOf(confirmresetall));
			confirmresetall.click();
//			wait.until(ExpectedConditions.invisibilityOf(smallPizza));
		}
		else {
			Logger.info("Edited Items not found");
		}
	}
	
	@iOSFindBy(id="LockScreenButtonNormal")
	private MobileElement lockscreen;
	
	public void locknunlock() throws IOException {
		lockscreen.click();
		WebDriverWait wait=new WebDriverWait(ADR,60);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(prop.getProperty("1"))));
		PosLoginPage login=new PosLoginPage((IOSDriver<WebElement>)ADR);
		login.unlock();
	}

}
