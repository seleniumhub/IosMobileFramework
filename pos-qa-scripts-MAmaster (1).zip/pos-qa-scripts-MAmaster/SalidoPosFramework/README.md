POS Automation script guide
