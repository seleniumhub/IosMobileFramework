package salido.pos.utils;

import java.io.IOException;
import java.text.DecimalFormat;
import java.time.Duration;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import io.appium.java_client.MobileElement;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.touch.TapOptions;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import salido.pos.base.PosBaseClass;
import salido.pos.logger.Logger;

public class PosUtilClass extends PosBaseClass{
	 
	public PosUtilClass() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public String num2Str(int num) {
		String str=String.valueOf(num);
		return str;
	}
	
	public int str2num(String str) {
		int num=Integer.parseInt(str);
		return num;
	}
	
	public void waitForSec(int num) {
		try {
			Thread.sleep(num*1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		Logger.info("waiting for "+num+" seconds");
	}
	
	public void waitUntilElementDisplayed(MobileElement element) {
		WebDriverWait wait=new WebDriverWait(ADR,35);
		try {
		wait.until(ExpectedConditions.visibilityOf(element));
		}
		catch(Exception e) {
			Logger.info("Waiting for the Element: "+element+"Max time is 35 sec");
		}
	}
	
	public void waitUntilElementDisplayed(WebElement element) {
		WebDriverWait wait=new WebDriverWait(ADR,35);
		try {
		wait.until(ExpectedConditions.visibilityOf(element));
		}
		catch(Exception e) {
			Logger.info("Waiting for the Element: "+element+"Max time is 35 sec");
		}
	}
	
	public void waitUntilElementDisplayed(MobileElement element,int timeout) {
		WebDriverWait wait=new WebDriverWait(ADR,timeout);
		try {
			wait.until(ExpectedConditions.visibilityOf(element));
		}
		catch(Exception e) {
			Logger.info("Waiting for the Element: "+element+"Max time is "+timeout+" sec");
		}
	}
	
	public void waitUntilElementDisplayed(WebElement element,int timeout) {
		WebDriverWait wait=new WebDriverWait(ADR,timeout);
		try {
			wait.until(ExpectedConditions.visibilityOf(element));
		}
		catch(Exception e) {
			Logger.info("Waiting for the Element: "+element+"Max time is "+timeout+" sec");
		}
	}
	
	public void waitUntilElementDisappear(MobileElement element,int timeout) {
		WebDriverWait wait=new WebDriverWait(ADR,timeout);
		try {
		wait.until(ExpectedConditions.invisibilityOf(element));
		}
		catch(Exception e) {
			Logger.info("Waiting for the Element to disappear: "+element+"Max time is "+timeout+" sec");
		}
	}
	
	public void fluentWaitforElement(MobileElement ele) {
		FluentWait<IOSDriver> wait = new FluentWait<IOSDriver>((IOSDriver) ADR).pollingEvery(500, TimeUnit.MILLISECONDS).withTimeout(60, TimeUnit.SECONDS).ignoring(NoSuchElementException.class);
		try {
			wait.until(ExpectedConditions.visibilityOf(ele));
		}
		catch(Exception e) {
			Logger.info("Fluent Wait: waited for :"+ele);
		}
	}
	
	public void fluentWaitforElement(WebElement ele) {
		FluentWait<IOSDriver> wait = new FluentWait<IOSDriver>((IOSDriver) ADR).pollingEvery(500, TimeUnit.MILLISECONDS).withTimeout(60, TimeUnit.SECONDS).ignoring(NoSuchElementException.class);
		try {
			wait.until(ExpectedConditions.visibilityOf(ele));
		}
		catch(Exception e) {
			Logger.info("Fluent Wait: waited for :"+ele);
		}
	}
	
	public void fluentWaitforElement(MobileElement ele,int timeout) {
		try {
			FluentWait<IOSDriver> wait = new FluentWait<IOSDriver>((IOSDriver) ADR).pollingEvery(250, TimeUnit.MILLISECONDS).withTimeout(timeout, TimeUnit.SECONDS).ignoring(NoSuchElementException.class);
			wait.until(ExpectedConditions.visibilityOf(ele));
		}
		catch(TimeoutException e) {
			Logger.info("Fluent Wait: waiting for :"+ele);
		}
	}
	
	public void fluentWaitforElement(WebElement ele,int timeout) {
		try {
			FluentWait<IOSDriver> wait = new FluentWait<IOSDriver>((IOSDriver) ADR).pollingEvery(250, TimeUnit.MILLISECONDS).withTimeout(timeout, TimeUnit.SECONDS).ignoring(NoSuchElementException.class);
			wait.until(ExpectedConditions.visibilityOf(ele));
		}
		catch(TimeoutException e) {
			Logger.info("Fluent Wait: waiting for :"+ele);
		}
	}
	
	public MobileElement webElementWithDynamicXpath (String xpathValue, String oldstring, String substitutionValue ) {
        return (MobileElement) ADR.findElement(By.xpath(xpathValue.replace(oldstring, substitutionValue)));
	}

	public List<MobileElement> webElementSWithDynamicXpath (String xpathValue, String oldstring, String substitutionValue ) {
        return  ADR.findElements(By.xpath(xpathValue.replace(oldstring, substitutionValue)));
	}
	
	public MobileElement webElementWithIndexStringReplaceXpath (String xpathValue, int num, String str,  String oldstring, String substitutionValue) {
        return (MobileElement) ADR.findElement(By.xpath(xpathValue+num+str.replace(oldstring, substitutionValue)));
	}
	
	public MobileElement webElementWithDynamicIndexXpath (String subStr1, int val, String subStr2 ) {
        return (MobileElement) ADR.findElement(By.xpath(subStr1+val+subStr2));
	}

	public String float2str(float ft) {
		DecimalFormat df = new DecimalFormat("#,###.##");
	    return  df.format(ft); 
	}
	
	public int float2int(float ft) {
		return (int)(Math.round(ft*100));
	}
	
	public float price2float(String str) {
		float bill=(float) 0.0;
		String billAmount=str.split("\\$")[1];
		if(billAmount.length()>6) {
			String []thpls=billAmount.split(",");
			String thbil="";
			for(int stl=0;stl<thpls.length;stl++) {
				thbil=thbil+thpls[stl];
			}
			bill=Float.parseFloat(thbil);
		}
		else {
			bill=Float.parseFloat(billAmount);
		}
		return bill;
	}
	
	public float str2float(String str) {
		return Float.parseFloat(str);
	}
	
	public void enterNumber(String str) {
		Logger.info("Entering Number: "+str);
		char []num=str.toCharArray();
		for(int ns=0;ns<str.length();ns++) {
			String chstr=Character.toString(num[ns]);
			ADR.findElement(By.id(prop.getProperty(chstr))).click();
		}
	}
	
	public int getRandomNumberInRange(int min, int max) {
		if (min >= max) {
			throw new IllegalArgumentException("max must be greater than min");
		}
		Random r = new Random();
		return r.nextInt((max - min) + 1) + min;
	}
	
	public void ScrollDown() {
		Dimension dimen= ADR.manage().window().getSize();
		Double startHeight=dimen.getHeight()*0.7;
		int startScroll=startHeight.intValue();
		Double endHeight=dimen.getHeight()*0.35;
		int endScroll=endHeight.intValue();
		new TouchAction((PerformsTouchActions) ADR)
		.press(PointOption.point(400, startScroll))
		.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1)))
		.moveTo(PointOption.point(400,endScroll))
		.release().perform();
	}
	
	public void ScrollDown(int strtX,int endX,double startHigt,double endHigt) {
		Dimension dimen= ADR.manage().window().getSize();
		Double startHeight=dimen.getHeight()*startHigt;
		int startScroll=startHeight.intValue();
		Double endHeight=dimen.getHeight()*endHigt;
		int endScroll=endHeight.intValue();
		new TouchAction((PerformsTouchActions) ADR)
		.press(PointOption.point(strtX, startScroll))
		.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1)))
		.moveTo(PointOption.point(endX,endScroll))
		.release().perform();
	}
	
	public void scrollUntilElementVisible(List<MobileElement> ele) {
		while((ele.size())==0) {
			ScrollDown();
		}
		while(!ele.get(0).isDisplayed()) {
			ScrollDown();
		}
	}
	
	public void scrollUntilElementVisible(MobileElement ele) {
		JavascriptExecutor js = (JavascriptExecutor) ADR;
		js.executeScript("arguments[0].scrollIntoView();", ele);

	}
	
	public void tapByCoordinates(int xPoint,int yPoint) {
		TouchAction touchAction=new TouchAction(ADR);
		touchAction.tap(new PointOption().withCoordinates(xPoint, yPoint)).perform();
	}
	
	//Use this method for only StaticText element
	public boolean isDisplayed(MobileElement ele) {
		try {
			if(ele.isDisplayed()) {
				Logger.info(ele.getText()+" is displayed");
				return true;
			}
		}
		catch(NoSuchElementException e) {
			Logger.info(ele.getText() +" is not displayed");
		}
		catch(WebDriverException e) {
			Logger.info(ele.getText() +" is not displayed");
		}
		return false;
	}
	
	public boolean isDisplayed(WebElement ele) {
		try {
			if(ele.isDisplayed()) {
				Logger.info(ele.getText()+" is displayed");
				return true;
			}
		}
		catch(NoSuchElementException e) {
			Logger.info(ele.getText() +" is not displayed");
		}
		catch(WebDriverException e) {
			Logger.info(ele.getText() +" is not displayed");
		}
		return false;
	}
	//Use this method for only StaticText element
	public boolean isEnabled(MobileElement ele) {
		try {
			if(ele.isDisplayed()) {
				Logger.info(ele.getText()+" is Enabled");
				return true;
			}
		}
		catch(WebDriverException e) {
			Logger.info(ele.getText() +" is not Enabled");
		}
		return false;
	}
	
	public boolean isEnabled(WebElement ele) {
		try {
			if(ele.isDisplayed()) {
				Logger.info(ele.getText()+" is Enabled");
				return true;
			}
		}
		catch(WebDriverException e) {
			Logger.info(ele.getText() +" is not Enabled");
		}
		return false;
	}
	
	//Use this method for only StaticText element
	public boolean isSlected(MobileElement ele) {
		try {
			if(ele.isSelected()) {
				Logger.info(ele.getText()+" is Selected");
				return true;
			}
		}
		catch(WebDriverException e) {
			Logger.info(ele.getText() +" is not Selected");
		}
		return false;
	}
	public boolean isSlected(WebElement ele) {
		try {
			if(ele.isSelected()) {
				Logger.info(ele.getText()+" is Selected");
				return true;
			}
		}
		catch(WebDriverException e) {
			Logger.info(ele.getText() +" is not Selected");
		}
		return false;
	}
}
