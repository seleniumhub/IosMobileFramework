package salido.pos.testcases;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import io.appium.java_client.ios.IOSDriver;
import java.io.IOException;
import java.net.MalformedURLException;

import salido.pos.base.PosBaseClass;
import salido.pos.logger.Logger;
import salido.pos.page.POSPaymentPage;
import salido.pos.page.PosChecksPage;
import salido.pos.page.PosDashBoardPage;
import salido.pos.page.PosGiftCardPage;
import salido.pos.page.PosLoginPage;
import salido.pos.page.PosManageBankPage;
import salido.pos.page.PosNewChkPage;
import salido.pos.utils.PosUtilClass;

// somasekhar meeniga
public class SalidoTestGiftcard extends PosBaseClass {


	public SalidoTestGiftcard() throws IOException {
		super();
	}

//	@BeforeTest
//	public void initialiseApp() throws IOException {
//		Appiuminitialization();
//	}
//
//	@BeforeClass
//	public void launchLockPage() throws InterruptedException, IOException {
//		ADR.launchApp();
//		PosLoginPage poslogin=new PosLoginPage((IOSDriver<WebElement>)ADR);
//		poslogin.unlock();
//	}

	@Test (priority=41,enabled=true)//, dependsOnGroups= {"login"}
	public void displayFiledsGC_01() throws IOException {
		PosGiftCardPage gfPage= new PosGiftCardPage((IOSDriver<WebElement>)ADR);
		PosDashBoardPage pdPage=new PosDashBoardPage((IOSDriver<WebElement>)ADR);
		try {
			pdPage.clickOnDashBoard();
			pdPage.clickOnGiftCard();
			gfPage.displayGCBackButton();
			gfPage.displayGCHash();
			gfPage.displayGCTextField();
			gfPage.displayNumberKeypad();
			gfPage.displayGCLookUp();
			//		gfPage.displayGCImage();
		}finally {
			gfPage.clickOnGCBackButton();
			pdPage.clickFloor();
		}
	}

	@DataProvider(name="GiftCard")
	public Object[][] giftCardNumber(){
		return new Object[][] {
			{"2073220100145802"}
		};
	}
	
	@Test (dataProvider="GiftCard",priority=42, enabled=true)//,dependsOnMethods= {"displayFiledsGC_01"}
	public void verifyTextFiledGC_02_VerifyLookUP_03(String gcnum) throws IOException, InterruptedException {
		PosGiftCardPage gfPage= new PosGiftCardPage((IOSDriver<WebElement>)ADR);
		PosDashBoardPage pdPage=new PosDashBoardPage((IOSDriver<WebElement>)ADR);
		try {
			pdPage.clickOnDashBoard();
			pdPage.clickOnGiftCard();
			gfPage.VerifyGCTextField(gcnum);
			Assert.assertEquals(true, gfPage.displayGCLookUp());
		}finally {
			gfPage.clickOnGCBackButton();
			pdPage.clickFloor();
		}
	}

//	@Test (dataProvider="GiftCard",priority=43,enabled=true) //,dependsOnMethods= {"displayFiledsGC_01"}
	public void verifyLookUpGC_03(String gcnum) throws IOException, InterruptedException {
		PosGiftCardPage gfPage= new PosGiftCardPage((IOSDriver<WebElement>)ADR);
		PosDashBoardPage pdPage=new PosDashBoardPage((IOSDriver<WebElement>)ADR);
		try {
			pdPage.clickOnDashBoard();
			pdPage.clickOnGiftCard();
			PosUtilClass posUtils=new PosUtilClass();
			posUtils.enterNumber(gcnum);
			// test case 3 
			Assert.assertEquals(true, gfPage.displayGCLookUp());
		}finally {
			gfPage.clickOnGCBackButton();
			pdPage.clickFloor();
		}
	}

	@Test (dataProvider="GiftCard",priority=44,enabled=true)
	public void AddValue_04(String gcnum) throws IOException, InterruptedException {
		// Just Checking whether user is able to add money using add value button 
		PosGiftCardPage gfPage= new PosGiftCardPage((IOSDriver<WebElement>)ADR);
		PosDashBoardPage pdPage=new PosDashBoardPage((IOSDriver<WebElement>)ADR);
		try {
			pdPage.clickOnDashBoard();
			pdPage.clickOnGiftCard();
			PosUtilClass posUtils=new PosUtilClass();
			posUtils.enterNumber(gcnum);
			gfPage.clickOnLookUP();
			if(gfPage.displaygcAddValue()) {
				gfPage.verifygcID(gcnum);
				gfPage.clickOnAddValue();
			}
			gfPage.checkSuggestedAmount();
			// The minimum amount to add to gift card is $10 
			gfPage.AddAmount2GiftCard((float)13.34);
			gfPage.clickOnADDbutton();
			Logger.info("User is able to add money to Gift card successfully ");
		}finally {
			gfPage.clickOnGCBackButton();
			pdPage.clickFloor();
		}
	}

	@Test (dataProvider="GiftCard",priority=44,enabled=true)
	public void minimumRuleCheck_09_MaximumRuleCheck_10(String gcnum) throws IOException, InterruptedException {
		// Just Checking whether user is able to add money using add value button 
		PosGiftCardPage gfPage= new PosGiftCardPage((IOSDriver<WebElement>)ADR);
		PosDashBoardPage pdPage=new PosDashBoardPage((IOSDriver<WebElement>)ADR);
		try {
			pdPage.clickOnDashBoard();
			pdPage.clickOnGiftCard();
			PosUtilClass posUtils=new PosUtilClass();
			posUtils.enterNumber(gcnum);
			gfPage.clickOnLookUP();
			gfPage.clickOnAddValue();
			gfPage.AddAmount2GiftCard((float)9.34);
			gfPage.clickOnADDbutton();
			gfPage.byCash();
			gfPage.AddAmount2GiftCard((float)13.34);
			gfPage.check4Minimum();
			// Maximum Rule check starts
			gfPage.clickOnBACK();
			gfPage.clickOnBACK();
			gfPage.clickOnBACK();
			gfPage.clickOnAddValue();
			gfPage.AddAmount2GiftCard((float)109.34);
			gfPage.clickOnADDbutton();
			gfPage.byCash();
			gfPage.AddAmount2GiftCard((float)113.34);
			gfPage.check4Maximum();
		}finally {
			gfPage.clickOnGCBackButton();
			pdPage.clickFloor();
		}
	}
//	@Test (dataProvider="GiftCard",priority=44,enabled=true)
	public void MaximumRuleCheck_10(String gcnum) throws IOException, InterruptedException {
		// Just Checking whether user is able to add money using add value button 
		PosGiftCardPage gfPage= new PosGiftCardPage((IOSDriver<WebElement>)ADR);
		PosDashBoardPage pdPage=new PosDashBoardPage((IOSDriver<WebElement>)ADR);
		try {
			pdPage.clickOnDashBoard();
			pdPage.clickOnGiftCard();
			PosUtilClass posUtils=new PosUtilClass();
			posUtils.enterNumber(gcnum);
			gfPage.clickOnLookUP();
			if(gfPage.displaygcAddValue()) {
				gfPage.verifygcID(gcnum);
				gfPage.clickOnAddValue();
			}
			gfPage.AddAmount2GiftCard((float)109.34);
			gfPage.clickOnADDbutton();
			gfPage.byCash();
			gfPage.AddAmount2GiftCard((float)113.34);
			if(gfPage.displayGCContinue()) {
				gfPage.check4Maximum();
			}
		}finally {
			gfPage.clickOnGCBackButton();
			pdPage.clickFloor();
		}
	}
	
	@Test (dataProvider="GiftCard",priority=45,enabled=true)
	public void AddValue_Bank_05(String gcnum) throws IOException, InterruptedException {
		PosGiftCardPage gfPage= new PosGiftCardPage((IOSDriver<WebElement>)ADR);
		PosDashBoardPage pdPage=new PosDashBoardPage((IOSDriver<WebElement>)ADR);
		try {
			pdPage.clickOnDashBoard();
			pdPage.clickOnBank();
			gfPage.preserveBankAmount();
			pdPage.clickOnDashBoard();
			pdPage.clickOnGiftCard();
			PosUtilClass posUtils=new PosUtilClass();
			posUtils.enterNumber(gcnum);
			gfPage.clickOnLookUP();
//			if(gfPage.displaygcAddValue()) {
//				gfPage.verifygcID(gcnum);
				gfPage.clickOnAddValue();
//			}
//			gfPage.checkSuggestedAmount();
			// The minimum amount to add to gift card is $10 
			gfPage.AddAmount2GiftCard((float)13.34);
			gfPage.clickOnADDbutton();
			gfPage.byCash();
			gfPage.AddAmount2GiftCard((float)13.34);
//			if(gfPage.displayGCContinue()) {
				gfPage.clickOnContinue();
//			}
			gfPage.clickOnDone();
			//Verification of Amount added or not in GiftCard
			//		pdPage.clickOnGiftCard();
			posUtils.enterNumber(gcnum);
			gfPage.clickOnLookUP();
//			if(gfPage.displaygcAddValue()) {
				gfPage.verifyGiftCardAmountAdded((float)13.34);
//			}
			gfPage.clickOnGCBackButton();
			//Verification of Amount added or not to the Bank
			pdPage.clickOnBank();
			gfPage.verifyBankAmountAdded((float)13.34);
			pdPage.clickOnDashBoard();
		}finally {
			try {
					gfPage.clickOnGCBackButton();
			} catch(NoSuchElementException e) {

			}
			pdPage.clickFloor();
		}
	}

	@Test (dataProvider="GiftCard",priority=46,enabled=false, dependsOnMethods= {"AddValue_Bank_05"})
	public void cancelLastTransaction_06(String gcnum) throws IOException, InterruptedException {
		PosGiftCardPage gfPage= new PosGiftCardPage((IOSDriver<WebElement>)ADR);
		PosDashBoardPage pdPage=new PosDashBoardPage((IOSDriver<WebElement>)ADR);
		pdPage.clickOnDashBoard();
		pdPage.clickOnBank();
		gfPage.preserveBankAmount();
		pdPage.clickOnDashBoard();
		pdPage.clickOnGiftCard();
		PosUtilClass posUtils=new PosUtilClass();
		posUtils.enterNumber(gcnum);
		gfPage.clickOnLookUP();
//		if(gfPage.displaygcAddValue()) {
//			gfPage.verifygcID(gcnum);
			gfPage.cancelLastTransaction();
//		}
		//Verification of Amount deducted or not in GiftCard
		posUtils.enterNumber(gcnum);
		gfPage.clickOnLookUP();
//		if(gfPage.displaygcAddValue()) {
			gfPage.verifyGiftCardAmountAdded((float) -13.34);
//		}
		gfPage.clickOnGCBackButton();
		//Verification of Amount deducted or not to the Bank
		pdPage.clickOnBank();
		gfPage.verifyBankAmountAdded((float) -13.34);
		pdPage.clickOnDashBoard();
	}

	@DataProvider(name="GiftCardCC")
	public Object[][] GiftCardVisa(){
		return new Object[][] {
			{"2073220100145802","4761739001010119","1222","201"}
		};
	}

	@Test (dataProvider="GiftCardCC",priority=46,enabled=true)
	public void AddValue_CC_07(String gcnum,String ccNum,String ccexp,String ccpin) throws IOException, InterruptedException {
		PosGiftCardPage gfPage= new PosGiftCardPage((IOSDriver<WebElement>)ADR);
		PosDashBoardPage pdPage=new PosDashBoardPage((IOSDriver<WebElement>)ADR);
		try {
			pdPage.clickOnDashBoard();
			pdPage.clickOnGiftCard();
			PosUtilClass posUtils=new PosUtilClass();
			posUtils.enterNumber(gcnum);
			gfPage.clickOnLookUP();
//			if(gfPage.displaygcAddValue()) {
//				gfPage.verifygcID(gcnum);
				gfPage.clickOnAddValue();
//			}
//			gfPage.checkSuggestedAmount();
			// The minimum amount to add to gift card is $10 
			gfPage.AddAmount2GiftCard((float)13.34);
			gfPage.clickOnADDbutton();
			gfPage.verifyEnteredAmount((float)13.34);
			gfPage.byCredit();
			gfPage.enterCCdetails(ccNum, ccexp, ccpin);
//			if(gfPage.displayGCCharge()) {
				gfPage.clickOnCharge();
//			}
			gfPage.clickOnDone();
			//Verification of Amount added or not in GiftCard
			//		pdPage.clickOnGiftCard();
			posUtils.enterNumber(gcnum);
			gfPage.clickOnLookUP();
//			if(gfPage.displaygcAddValue()) {
				gfPage.verifyGiftCardAmountAdded((float)13.34);
//			}
		}finally {
			try {
					gfPage.clickOnGCBackButton();
			}catch(NoSuchElementException e) {

			}
			pdPage.clickFloor();
		}
	}

	@Test(dataProvider="GiftCard", priority=47,enabled=true)
	public void redeem_GiftCard_08(String gcnum) throws IOException {
		PosDashBoardPage DBPage=new PosDashBoardPage((IOSDriver<WebElement>) ADR);
		PosNewChkPage NChkPage=new PosNewChkPage((IOSDriver<WebElement>) ADR);
		PosGiftCardPage gfPage= new PosGiftCardPage((IOSDriver<WebElement>)ADR);
		try {
			DBPage.clickOnDashBoard();
			DBPage.clickOnGiftCard();
			PosUtilClass posUtils=new PosUtilClass();
			posUtils.enterNumber(gcnum);
			gfPage.clickOnLookUP();
//			if(gfPage.displaygcAddValue()) {
				gfPage.preserveGiftCardAmount();
//			}
			gfPage.clickOnGCBackButton();
			DBPage.clickFloor();
			NChkPage.CreateCheck();
			String chkTotal=NChkPage.checkTotal();
			NChkPage.clickOnPay();
			NChkPage.clickOnOtherPayments();
			gfPage.selectGiftCardPayment();
			posUtils.enterNumber(gcnum);
			gfPage.clickOnADDbutton();
			if(gfPage.check4AUTH()) {
				gfPage.verifyGCAmountShown();
				gfPage.gcAmnt2Redeem();
				gfPage.verifyDueBalance();
			}
			gfPage.clickOnAuth();
			gfPage.verifyDueBalance();
			gfPage.clickOnCloseCheck();
			DBPage.clickOnDashBoard();
			DBPage.clickOnGiftCard();
			posUtils.enterNumber(gcnum);
			gfPage.clickOnLookUP();
//			if(gfPage.displaygcAddValue()) {
				gfPage.verifyGiftCardAmountAdded((float) -(posUtils.price2float(chkTotal)));
//			}
		}finally {
			try {
					gfPage.clickOnGCBackButton();
			}catch(NoSuchElementException e) {
				Logger.info("GiftCardBackButton is not displayed");
				try {
					DBPage.clickOnDashBoard();
				}catch(NoSuchElementException e1) {
					Logger.info("DashBoardIcon is not displayed");
				}
			}
			DBPage.clickFloor();
		}
	}

	@DataProvider(name="GiftCardActDe")
	public Object[][] DeActivateGiftCard(){
		return new Object[][] {
			{"2073189230243156"}
		};
	}

	@Test(dataProvider="GiftCardActDe",priority=48,enabled=true)
	public void ActivateGiftCard_11_DeactivateGiftCard_12(String gcnum) throws IOException {
		PosGiftCardPage gfPage= new PosGiftCardPage((IOSDriver<WebElement>)ADR);
		PosDashBoardPage pdPage=new PosDashBoardPage((IOSDriver<WebElement>)ADR);
		try {
			pdPage.clickOnDashBoard();
			pdPage.clickOnBank();
			gfPage.preserveBankAmount();
			pdPage.clickOnDashBoard();
			pdPage.clickOnGiftCard();
			PosUtilClass posUtils=new PosUtilClass();
			posUtils.enterNumber(gcnum);
//			if(gfPage.displayGCLookUp()) {
				gfPage.clickOnLookUP();
//			}
			gfPage.activateGC((float)13.34);
			gfPage.check4gcActivation(gcnum);
			gfPage.cancelLastTransaction();
			posUtils.enterNumber(gcnum);
			gfPage.clickOnLookUP();
			if(gfPage.check4gcInactivity()) {
				Logger.info("Gift Card: "+gcnum+" is successfully deactivated.");
			}
			gfPage.clickOnGCBackButton();
			//Verification of Amount deducted or not to the Bank
			pdPage.clickOnBank();
			gfPage.verifyBankAmountAdded((float) 0.0);
			pdPage.clickOnDashBoard();
			
		}finally {
			try {
					gfPage.clickOnGCBackButton();
			}catch(NoSuchElementException e) {

			}
			pdPage.clickFloor();
		}
	}

//	@Test(dataProvider="GiftCardActDe",priority=49,enabled=true,dependsOnMethods= {"ActivateGiftCard_11"})
	public void DeactivateGiftCard_12(String gcnum) throws IOException {
		PosGiftCardPage gfPage= new PosGiftCardPage((IOSDriver<WebElement>)ADR);
		PosDashBoardPage pdPage=new PosDashBoardPage((IOSDriver<WebElement>)ADR);
		try {
			pdPage.clickOnDashBoard();
			pdPage.clickOnBank();
			gfPage.preserveBankAmount();
			pdPage.clickOnDashBoard();
			pdPage.clickOnGiftCard();
			PosUtilClass posUtils=new PosUtilClass();
			posUtils.enterNumber(gcnum);
			gfPage.clickOnLookUP();
//			if(gfPage.displaygcAddValue()) {
//				gfPage.verifygcID(gcnum);
				gfPage.cancelLastTransaction();
//			}
			//Verification of Amount deducted or not in GiftCard
			posUtils.enterNumber(gcnum);
			gfPage.clickOnLookUP();
			if(gfPage.check4gcInactivity()) {
				Logger.info("Gift Card: "+gcnum+" is successfully deactivated.");
			}
			gfPage.clickOnGCBackButton();
			//Verification of Amount deducted or not to the Bank
			pdPage.clickOnBank();
			gfPage.verifyBankAmountAdded((float) -13.34);
			pdPage.clickOnDashBoard();
		}finally {
			try {
					gfPage.clickOnGCBackButton();
			}catch(NoSuchElementException e) {

			}
			pdPage.clickFloor();
		}
	}

}
