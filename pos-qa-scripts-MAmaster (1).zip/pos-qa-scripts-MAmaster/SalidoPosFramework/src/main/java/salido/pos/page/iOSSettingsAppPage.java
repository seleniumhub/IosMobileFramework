package salido.pos.page;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;
import salido.pos.base.PosBaseClass;
import salido.pos.utils.PosUtilClass;

public class iOSSettingsAppPage extends PosBaseClass{

	PosUtilClass posUtils=new PosUtilClass();
	public iOSSettingsAppPage(IOSDriver<WebElement> driver) throws IOException {
		super();
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@iOSFindBy(xpath="//XCUIElementTypeCell[@name=\"Safari\"]")
	private List<WebElement> safari;
	
	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"Clear History and Website Data\"]")
	private List<WebElement> clearHistory;
	
	@iOSFindBy(id="Clear")
	private WebElement clear;
	
	public void selectSafari() {
//		while((safari.size())==0) {
//			posUtils.ScrollDown(100,100,0.7,.05);
//		}
		while(!safari.get(0).isDisplayed()) {
			posUtils.ScrollDown(100,100,0.7,.05);
		}
		safari.get(0).click();
	}

	public void clearSafariHistory() {
//		while((clearHistory.size())==0) {
//			posUtils.ScrollDown(500,500,0.7,.05);
//		}
		while(!clearHistory.get(0).isDisplayed()) {
			posUtils.ScrollDown(500,500,0.7,.05);
		}
		clearHistory.get(0).click();
		posUtils.waitUntilElementDisplayed(clear);
		clear.click();
	}
	
}
