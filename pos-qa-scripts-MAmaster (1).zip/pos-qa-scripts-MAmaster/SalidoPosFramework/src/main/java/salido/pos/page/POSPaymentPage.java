package salido.pos.page;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;
import salido.pos.base.PosBaseClass;
import salido.pos.logger.Logger;
import salido.pos.utils.PosUtilClass;

public class POSPaymentPage extends PosBaseClass{
	PosUtilClass posUtils=new PosUtilClass();
	public POSPaymentPage(IOSDriver<WebElement> driver) throws IOException {
		super();
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"Total\"]/following-sibling::XCUIElementTypeButton")
	private WebElement payTotal;
	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"Total\"]/following-sibling::XCUIElementTypeStaticText")
	private WebElement totalBill;
	@iOSFindBy(id="PAY")
	private WebElement pay;
	@iOSFindBy(id="+ Cash")
	private WebElement byCash;
	@iOSFindBy(id="ADD")
	private WebElement add;
	@iOSFindBy(id="PRINT")
	private WebElement print;
	@iOSFindBy(id="POP DRAWER")
	private WebElement popDrawer;
	@iOSFindBy(id="CLOSE")
	private WebElement close;
	@iOSFindBy(xpath="(//XCUIElementTypeButton[@name=\"CLOSE CHECK\"])[last()]")
	private WebElement closeCheck;
	@iOSFindBy(id="BackButton")
	private WebElement backbutton;
	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"TIP\"]/following-sibling::XCUIElementTypeTextField")
	private WebElement tipFiled;
	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"TIP\"]/preceding::XCUIElementTypeTextField")
	private WebElement amountFiled;
	@iOSFindBy(xpath="(//XCUIElementTypeButton[@name=\"iconEditFloor\"])[last()]")
	private WebElement editPayment;
	@iOSFindBy(id="UPDATE")
	private WebElement updatePayment;
	@iOSFindBy(xpath="(//XCUIElementTypeButton[@name=\"+ Manual CC\"])[last()]")
	private WebElement manualCC;
	@iOSFindBy(id="Custom")
	private WebElement custom;
	@iOSFindBy(id="Pre-Auth Credit Card")
	private WebElement preAuthOPtion;
	@iOSFindBy(id="AUTH")
	private WebElement auth;
	@iOSFindBy(xpath="//XCUIElementTypeStaticText[contains(@name,'INV ACCT NUM')]")
	private WebElement errorInvalid;
	@iOSFindBy(id="backIconBlack")
	private WebElement backCCButton;
	@iOSFindBy(xpath="//XCUIElementTypeStaticText[contains(@name,'expired')]")
	private WebElement expiredError;
	
	public void payByCash() {
		clickOnPay();
		pay.click();
		close.click();
	}

	public void selectPreAuth() {
		preAuthOPtion.click();
		Logger.info("Slecting PreAuth OPtion");
	}
	
	public void clickOnAuth() {
		posUtils.waitUntilElementDisplayed(auth);
		auth.click();
	}
	
	public void selectManualCC() {
		manualCC.click();
		Logger.info("Selected Manual CC");
	}
	
	public void selectCustom() {
		custom.click();
		Logger.info("Selected Custom Payment");
	}
	
	public void back2Checks() {
		backbutton.click();
	}

	public void byCashEnabled() {
		if(byCash.isEnabled()) {
			Logger.info("Payment by Cash is Enabled");
		} else {
			Logger.info("Payment by Cash is disabled");
			Assert.assertEquals(true, false);
		}
	}

	public void payPartialByCash(float bill,float tip) {
		byCash.click();
		if(bill>0)
			posUtils.enterNumber(posUtils.num2Str(posUtils.float2int(bill)));
		tipFiled.click();
		if(tip>0)
			posUtils.enterNumber(posUtils.num2Str(posUtils.float2int(tip)));
		add.click();
	}

	public void clickOnADD() {
		if(add.isDisplayed()) {
			add.click();
		}
	}
	
	public float toatlBill() {
		String billAmount=totalbill.getAttribute("value");
		Logger.info("Total Bill: "+ billAmount);
		return posUtils.price2float(billAmount);
	}

	public void clickOnPay() {
		try {
			if(payTotal.isDisplayed()) {
				payTotal.click();
			}
		}
		catch(NoSuchElementException e) {
			e.printStackTrace();
		}
	}

	public void editPayment(float tip) {
		//		posUtils.waitUntilElementDisplayed(editPayment);
		editPayment.click();
		posUtils.enterNumber(posUtils.num2Str(posUtils.float2int(tip)));
	}

	public void updatePayment() {
		updatePayment.click();
		posUtils.waitUntilElementDisplayed(discardIcon1);
	}

	public void editPayment(float amount,float tip) {
		//		posUtils.waitUntilElementDisplayed(editPayment);
		editPayment.click();
		amountFiled.click();
		if(amount>0)
			posUtils.enterNumber(posUtils.num2Str(posUtils.float2int(amount)));
		tipFiled.click();
		if(tip>0)
			posUtils.enterNumber(posUtils.num2Str(posUtils.float2int(tip)));
	}

	public void closeCheck() {
		posUtils.waitUntilElementDisplayed(closeCheck,10);
		closeCheck.click();
		Logger.info("Check Closed");
	}
	@iOSFindBy(xpath="//XCUIElementTypeButton[@name=\"iconDiscard\"]")
	private List<WebElement> discardIcons;

	@iOSFindBy(xpath="(//XCUIElementTypeButton[@name=\"iconDiscard\"])[last()]")
	private WebElement discardIcon1;

	@iOSFindBy(id="CONFIRM")
	private WebElement confirm;

	@iOSFindBy(id="OK")
	private WebElement okbutton;

	public void refundPayment() {
		int noOfsplit=discardIcons.size();
		for(int split=1;split<=noOfsplit;split++) {
			if(discardIcons.size()>1)
				discardIcon1.click();
			else
				discardIcons.get(0).click();
			confirm.click();
			posUtils.waitUntilElementDisplayed(okbutton);
			okbutton.click();
		}
	}

	public void refundGiftCard() {
		while(true) {
			int payments=discardIcons.size();
			if(payments==0) {
				break;
			} else if(payments>1) {
				discardIcon1.click();
				confirm.click();
				printerNotFound();
			}
			else if(payments==1) {
				discardIcons.get(0).click();
				confirm.click();
				printerNotFound();
			}
		}
	}
	
	public void refundCustom() {
		int noOfsplit=discardIcons.size();
		for(int split=1;split<=noOfsplit;split++) {
			if(split==noOfsplit)
				discardIcons.get(0).click();
			else
				discardIcon1.click();
			confirm.click();
		}
	}
	public void printerNotFound() {
		posUtils.waitUntilElementDisplayed(ADR.findElementByAccessibilityId("RETRY"),60);
		ADR.findElementByAccessibilityId(prop.getProperty("cancel")).click();
	}
	public void checkVoid(String str) throws IOException {
		PosNewChkPage newcheck= new PosNewChkPage((IOSDriver<WebElement>) ADR);
		newcheck.clikOnVoidChk();
		//		try {
		////			while(okbutton.isDisplayed()) {
		////				okbutton.click();
		////				refundPayment();
		////				newcheck.clikOnVoidChk();
		////			}
		//		}
		//		catch(NoSuchElementException e) {
		//			Logger.info("No Pending payments to refund");
		//		}
		newcheck.clickOnVoidReason(str);
		newcheck.confirmVoid();
	}

	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"Total\"]/following-sibling::XCUIElementTypeStaticText")
	private WebElement totalbill;

	public void splitPaybyCash() {
		float bill=toatlBill();
		String []bills = splitbill(bill);
		payTotal.click();
		for(int num=0; num<2;num++) {
			byCash.click();
			posUtils.enterNumber(bills[num]);
			add.click();
		}
		closeCheck.click();
	}
	public String[] splitbill(float bill) {
		String []bills= new String[2];
		float bill1=bill/2;
		bill1 = (float)Math.round(bill1 * 100) / 100;
		bills[0]=Integer.toString((int)(bill1*100));
		bill1=bill-bill1;
		posUtils.waitForSec(1);
		bills[1]=Integer.toString((int)(bill1*100));
		return bills;
	}

	private String txtfieldb4stctxt="//XCUIElementTypeStaticText[@name=\"xxxx\"]/preceding::XCUIElementTypeTextField[1]";
	public void enterCCdetails(String CCNum,String CCExp,String CCpin) {
		posUtils.webElementWithDynamicXpath(txtfieldb4stctxt, "xxxx", "CC #").click();
		posUtils.enterNumber(CCNum);
		posUtils.webElementWithDynamicXpath(txtfieldb4stctxt, "xxxx", "CVV").click();
		posUtils.enterNumber(CCExp);
		//		posUtils.webElementWithDynamicXpath(txtfieldb4stctxt, "xxxx", "GIFT CARD").click();
		//		posUtils.enterNumber(CCpin);
	}
	
	@iOSFindBy(xpath="//XCUIElementTypeButton[@name=\"AUTHORIZE\"]")
	private WebElement authorize;
	
	public void clickOnAuthorize() {
		authorize.click();
	}
	
	public boolean AuthoriseEnabled() {
		Logger.info("Authorize button Enabled: "+ authorize.isEnabled());
		return authorize.isEnabled();
	}
	public void clickAuthorize() {
		try {
			while(authorize.isEnabled()) {
				clickOnAuthorize();
				printerNotFound();
				if(editPayment.isDisplayed())
					break;
			}
		} catch(NoSuchElementException e) {

		}
	}
	
	@iOSFindBy(xpath="//XCUIElementTypeButton[@name=\"PRE-AUTH\"]")
	private WebElement preAuthButton;
	
	public void clickOnPreAuth() {
		if(preAuthButton.isEnabled()) {
			preAuthButton.click();
			posUtils.waitUntilElementDisplayed(discardIcon1);
		}
	}
	
	private String btnb4stctxt="//XCUIElementTypeStaticText[@name=\"xxxx\"]/preceding::XCUIElementTypeButton[1]";
	public void clickOnAmntB4Auth() {
		posUtils.webElementWithDynamicXpath(btnb4stctxt, "xxxx", "$").click();
	}
	
	public void invalidCrad() {
		posUtils.waitUntilElementDisplayed(errorInvalid,60);
		ADR.findElementByAccessibilityId(prop.getProperty("cancel")).click();
		backCCButton.click();
	}
	public void expiredCrad() {
		posUtils.waitUntilElementDisplayed(expiredError,60);
		ADR.findElementByAccessibilityId(prop.getProperty("cancel")).click();
		backCCButton.click();
	}
	public void clickOnBack() {
		backCCButton.click();
	}
	
}
