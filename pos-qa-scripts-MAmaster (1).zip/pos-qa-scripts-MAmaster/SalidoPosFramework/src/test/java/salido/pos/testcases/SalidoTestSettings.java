package salido.pos.testcases;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;

public class SalidoTestSettings {
	
	
	@Test (enabled =false)
	  public void Setting()
	  {
		 System.out.println("setting method"); 
	  }


}
