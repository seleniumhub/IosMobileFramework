package salido.pos.testcases;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.appium.java_client.ios.IOSDriver;
import salido.pos.base.PosBaseClass;
import salido.pos.logger.*;
import salido.pos.page.ManageMenuPage;

public class SalidoTestManageMenu extends PosBaseClass{
	
	public SalidoTestManageMenu() throws IOException {
		super();
		
	}
	@BeforeClass
	public void launchSalidoApp() {
		Logger.info("Launching the Salido App");
//		ADR.launchApp();
		
	}
	@Test (enabled =true, priority=12)
	  public void selectMenu_01() throws IOException
	  {
		 Logger.info("Starting Select Menu Method:");
		 ManageMenuPage MMPage=new ManageMenuPage((IOSDriver<WebElement>) ADR);
		 MMPage.clickOnDashBoard();
		 MMPage.clickOnMangeMenu();
		 MMPage.clickOnSelectMenu();
	  }

	@Test (enabled =true, priority=13)
	  public void checkMenuItems_02() throws IOException{
		 Logger.info("executing Check Menu Items under selected Menu"); 
		 ManageMenuPage MMPage=new ManageMenuPage((IOSDriver<WebElement>) ADR);
		 MMPage.clickOnDashBoard();
		 MMPage.clickOnMangeMenu();
		 MMPage.check4Items();
	  }
	
	@Test (enabled =true, priority=14)
	  public void checkeditItemCount_03() throws IOException{
		 Logger.info("executing Check Menu Items Count under selected Menu"); 
		 ManageMenuPage MMPage=new ManageMenuPage((IOSDriver<WebElement>) ADR);
		 MMPage.clickOnDashBoard();
		 MMPage.clickOnMangeMenu();
		 MMPage.editItemsCount();
	  }
	
	@Test (enabled =false, priority=15, dependsOnMethods= {"checkeditItemCount_03"})
	  public void checkResetItemsCount_04() throws IOException {
		 Logger.info("executing checkResetItemsCount_04"); 
		 ManageMenuPage MMPage=new ManageMenuPage((IOSDriver<WebElement>) ADR);
		 MMPage.clickOnDashBoard();
		 MMPage.clickOnMangeMenu();
		 MMPage.ResetAllItems();
	  }
	
	@Test (enabled =true, priority=16)
	  public void checkManageMenuHeader_05() throws IOException{
		 Logger.info("executing checkManageMenuHeader_05"); 
		 ManageMenuPage MMPage=new ManageMenuPage((IOSDriver<WebElement>) ADR);
		 MMPage.clickOnDashBoard();
		 MMPage.clickOnMangeMenu();
		 MMPage.locknunlock();
	  }
}
