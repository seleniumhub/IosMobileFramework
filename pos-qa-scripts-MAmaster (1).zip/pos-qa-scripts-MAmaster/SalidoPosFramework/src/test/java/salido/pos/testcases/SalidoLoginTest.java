package salido.pos.testcases;


import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.IOSMobileCapabilityType;
import salido.pos.logger.Logger;
import salido.pos.base.PosBaseClass;
import salido.pos.page.PosLoginPage;

public class SalidoLoginTest extends PosBaseClass{

	//	static Logger logger = Logger.getLogger(SalidoLoginTest.class);
	


	public SalidoLoginTest() throws IOException {
		super();

	}

	@BeforeSuite
	public void clearData() {
		String replaceString= "/target/ScreenShots/";
		File  folder=new File(System.getProperty("user.dir")+org.apache.commons.io.FilenameUtils.separatorsToSystem(replaceString));
		File[] files = folder.listFiles();
		if(files!=null) { //some JVMs return null for empty dirs
			for(File f: files) {
				f.delete();
			}
		}
		//		    folder.delete();		
	}
	@Parameters({"wda","udid","deviceName","port"})
	@BeforeTest
	public void setUp(String wda,String udid,String deviceName,String port) throws InterruptedException, IOException{
		Logger.info("Lauching SALIDO_POS ..........");
		Appiuminitialization(wda,udid,deviceName,port);	 
	}

	@BeforeMethod
	public void AppInfo() {
		Logger.info(ADR.getCapabilities());
	}
	
	@Test (priority =1 , enabled =true, groups= {"login"})
	public static void login() throws InterruptedException, IOException{
		PosLoginPage login = new PosLoginPage((IOSDriver<WebElement>) ADR);
		try {
			if(ADR.findElement(By.name("Swipe Left to Begin Setup")).isDisplayed()) {
				login.poslogin();
				login.organizationName("Auto_Org2");
				login.BrandName("Auto_Brand2");
				login.LocationName("Tower E");
				login.TerminalName("LOCAL AUTOMATION");  
			}
		}
		catch(NoSuchElementException excp) {
			Logger.info("User already Signed In. Unlocking the App.");
			login.unlock();
		}
		Logger.info("Logged in Successfully");
	}

	@AfterMethod
	public void quitDriver() throws MalformedURLException {
//		ADR.quit();
//		DC.setCapability("app","");
//		DC.setCapability(IOSMobileCapabilityType.BUNDLE_ID, "com.salido.ios.v2.staging.PointOfSale");
//		ADR = new IOSDriver<WebElement>(new URL (prop.getProperty("url")),DC);	
//		ADR.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//		Logger.info(ADR.getCapabilities());
	}


	@AfterTest
	public void tearDown(){
		Logger.info("After Test Print");
		//		ADR.getAppiumService().stop();
	}

	@AfterSuite
	public void killAppiumServer() {
		serviceBuilder.stop();
	}

}