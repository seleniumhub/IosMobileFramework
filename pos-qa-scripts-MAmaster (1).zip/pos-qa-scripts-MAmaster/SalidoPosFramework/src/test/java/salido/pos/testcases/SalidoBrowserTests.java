package salido.pos.testcases;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.appium.java_client.ios.IOSDriver;
import salido.pos.base.PosBaseClass;
import salido.pos.logger.Logger;
import salido.pos.page.BrowserLoginPage;
import salido.pos.page.iOSSettingsAppPage;
import salido.pos.utils.PosUtilClass;

public class SalidoBrowserTests extends PosBaseClass{

	PosUtilClass posUtils=new PosUtilClass();
	public SalidoBrowserTests() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}

//	@BeforeTest
	public void clearSafariHistory() throws IOException{
		launchiOSSettingsApp();
		iOSSettingsAppPage settings=new iOSSettingsAppPage((IOSDriver<WebElement>)ADR);
		settings.selectSafari();
		settings.clearSafariHistory();
		ADR.quit();
	}
	
	@BeforeClass
	public void browserInit() {
		launchiPadSafari();
	}

	@Test (priority=1)
	public void login() throws IOException {
		BrowserLoginPage login=new BrowserLoginPage();
		ADR.get("https://ss-platform-stg.herokuapp.com");
		login.enterLoginDetails("wchang+1@salido.com", "(43,8]Z2o#%_!ox");
		login.bridgeSwitch();
	}

	@Test (priority=2)
	public void downloadBuild() throws IOException {
		BrowserLoginPage login=new BrowserLoginPage();
		if(ADR.isAppInstalled("com.salido.ios.v2.staging.PointOfSale")) {
			boolean removedApp=ADR.removeApp("com.salido.ios.v2.staging.PointOfSale");
			if(removedApp) {
				Logger.info("App Uninstalled successfully");
			}
		}
		boolean downloading=login.downloadBuild();
		if(downloading) {
			while(!ADR.isAppInstalled("com.salido.ios.v2.staging.PointOfSale")) {
				posUtils.waitForSec(5);
			}
			Logger.info("App Successfully Downloaded");
		}
	}

	@Test(priority=9)
	public void logOut() throws IOException {
		BrowserLoginPage login=new BrowserLoginPage();
		login.logOut();
	}
}
