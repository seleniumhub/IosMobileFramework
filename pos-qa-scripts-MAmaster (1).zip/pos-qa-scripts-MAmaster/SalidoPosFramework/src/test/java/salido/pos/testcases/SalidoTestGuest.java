package salido.pos.testcases;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import io.appium.java_client.ios.IOSDriver;

import org.testng.annotations.Test;
import java.io.IOException;

import org.testng.annotations.Test;

import salido.pos.base.PosBaseClass;
import salido.pos.page.PosDashBoardPage;
import salido.pos.page.PosGuestPage;


import org.testng.annotations.Test;

public class SalidoTestGuest extends PosBaseClass{
	
	PosGuestPage gStPage = new PosGuestPage((IOSDriver<WebElement>) ADR);
	
	
	public SalidoTestGuest() throws IOException {
		super();
		
	}
	
	@Test(enabled = true, priority =2)
	public void creategStPage() throws IOException, InterruptedException
	{
		PosDashBoardPage DBPage=new PosDashBoardPage((IOSDriver<WebElement>) ADR);
		
		//gStPage
		DBPage.clickOnDashBoard();
		DBPage.checkGuests();
		gStPage.clickOnNewGuestIcon();
		gStPage.enterGuestData();
		gStPage.clickOnSAVE();
		gStPage.VerifyGuestcreation("AutoFirstName");
	}
	@Test(enabled = false, priority =2)
	public void gStPageCreate() throws IOException, InterruptedException
	{
		gStPage.Guests();
	 
	}

	@Test(enabled = false, priority =2)
	public void gStPageaddress() throws IOException, InterruptedException
	{
		gStPage.GuestAddress();
		
	}
	
	
	@Test(enabled = false, priority =3)
	public void gStPageaddressdelete() throws IOException, InterruptedException
	{
		
		gStPage.DeleteAddress();
	 
	}
	
	
}
